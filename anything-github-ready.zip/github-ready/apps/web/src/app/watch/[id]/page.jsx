"use client";
import { useState, useEffect, useCallback } from "react";
import useUser from "@/utils/useUser";
import {
  ArrowLeft,
  Play,
  Lock,
  BookOpen,
  Film,
  ChevronDown,
  Eye,
  CheckCircle,
  X,
  Star,
  Tv,
} from "lucide-react";

const LOGO_URL =
  "https://raw.createusercontent.com/83c42dc4-4b43-4e42-aded-b337415f50ea/";

const PAYPAL_LINK = "https://www.paypal.com/ncp/payment/RF5TALRF8C4Q6";
const MTN_NUMBER = "0799395838";
const AIRTEL_NUMBER = "0722461585";

const PROVIDERS = [
  { id: "paypal", label: "PayPal", icon: "🅿️", desc: "Pay via PayPal link" },
  {
    id: "stripe",
    label: "Card / Stripe",
    icon: "💳",
    desc: "Visa, Mastercard, Amex",
  },
  {
    id: "mtn",
    label: "MTN Mobile Money",
    icon: "📱",
    desc: `Send to: ${MTN_NUMBER}`,
  },
  {
    id: "airtel",
    label: "Airtel Money",
    icon: "📲",
    desc: `Send to: ${AIRTEL_NUMBER}`,
  },
];

function isYouTube(url) {
  return url && (url.includes("youtube.com") || url.includes("youtu.be"));
}

function getYouTubeEmbedUrl(url) {
  if (!url) return null;
  const shortMatch = url.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
  if (shortMatch)
    return `https://www.youtube.com/embed/${shortMatch[1]}?autoplay=1&rel=0`;
  const longMatch = url.match(/(?:v=|\/embed\/|\/v\/)([a-zA-Z0-9_-]{11})/);
  if (longMatch)
    return `https://www.youtube.com/embed/${longMatch[1]}?autoplay=1&rel=0`;
  return url;
}

function getStreamSite(url) {
  if (!url) return "Watch";
  if (isYouTube(url)) return "YouTube";
  if (url.includes("netfilm")) return "Netfilm";
  if (url.includes("moviebox")) return "MovieBox";
  if (url.includes("vimeo")) return "Vimeo";
  return "Stream";
}

function StreamPlayer({ url, title, siteName }) {
  const [showFallback, setShowFallback] = useState(false);
  const embedUrl = isYouTube(url) ? getYouTubeEmbedUrl(url) : url;

  useEffect(() => {
    if (!isYouTube(url)) {
      const t = setTimeout(() => setShowFallback(true), 12000);
      return () => clearTimeout(t);
    }
  }, [url]);

  return (
    <div className="w-full h-full relative bg-black flex items-center justify-center">
      <iframe
        src={embedUrl}
        className="w-full h-full border-0"
        allowFullScreen
        allow="autoplay; fullscreen; picture-in-picture; encrypted-media"
        title={title}
      />
      {showFallback && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-10">
          <div className="bg-black/90 border border-white/10 rounded-2xl px-5 py-3 flex items-center gap-3 backdrop-blur">
            <span className="text-xs text-gray-400">Video not loading?</span>
            <a
              href={url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-bold text-[#A78BFA] border border-[#7C3AED]/40 rounded-lg px-3 py-1.5 hover:bg-[#7C3AED]/20 transition-colors"
            >
              Open on {siteName} ↗
            </a>
          </div>
        </div>
      )}
    </div>
  );
}

export default function WatchPage({ params }) {
  const { id } = params;
  const { data: user, loading: userLoading } = useUser();

  const [content, setContent] = useState(null);
  const [episodes, setEpisodes] = useState([]);
  const [selectedEp, setSelectedEp] = useState(null);
  const [loading, setLoading] = useState(true);
  const [needsPurchase, setNeedsPurchase] = useState(false);
  const [paymentModal, setPaymentModal] = useState(false);
  const [payProvider, setPayProvider] = useState("stripe");
  const [phone, setPhone] = useState("");
  const [paying, setPaying] = useState(false);
  const [paySuccess, setPaySuccess] = useState(false);
  const [payError, setPayError] = useState(null);
  const [selectedSeason, setSelectedSeason] = useState(1);
  const [paypalPending, setPaypalPending] = useState(false);

  const fetchContent = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/content/${id}`);
      const data = await res.json();
      if (data.content) {
        setContent(data.content);
        setNeedsPurchase(data.needs_purchase);
        // Increment view
        if (!data.needs_purchase) {
          fetch(`/api/content/${id}`, { method: "POST" }).catch(() => {});
        }
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [id]);

  const fetchEpisodes = useCallback(async () => {
    if (!id) return;
    try {
      const res = await fetch(`/api/episodes?contentId=${id}`);
      const data = await res.json();
      const eps = data.episodes || [];
      setEpisodes(eps);
      if (eps.length > 0 && !selectedEp) setSelectedEp(eps[0]);
    } catch (err) {
      console.error(err);
    }
  }, [id]);

  useEffect(() => {
    fetchContent();
    fetchEpisodes();
  }, [fetchContent, fetchEpisodes]);

  // After Stripe redirect, record the purchase
  useEffect(() => {
    if (typeof window === "undefined") return;
    const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get("session_id");
    const contentIdParam = urlParams.get("content_id");
    if (sessionId && contentIdParam) {
      fetch("/api/purchases", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          stripe_session_id: sessionId,
          content_id: parseInt(contentIdParam),
        }),
      })
        .then(() => fetchContent())
        .catch(() => {});
    }
  }, []);

  const handleEpisodeSelect = (ep) => {
    setSelectedEp(ep);
    // track view
    fetch("/api/episodes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ episodeId: ep.id }),
    }).catch(() => {});
    if (typeof window !== "undefined")
      window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleStripeCheckout = async () => {
    setPaying(true);
    setPayError(null);
    try {
      const res = await fetch("/api/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contentId: parseInt(id),
          redirectURL:
            typeof window !== "undefined"
              ? window.location.origin + `/watch/${id}`
              : "",
        }),
      });
      const data = await res.json();
      if (data.url) {
        if (typeof window !== "undefined") window.location.href = data.url;
      } else {
        throw new Error(data.error || "Checkout failed");
      }
    } catch (err) {
      setPayError(err.message);
    } finally {
      setPaying(false);
    }
  };

  const handleMobileMoneyPay = async () => {
    if (!phone) {
      setPayError("Please enter your phone number");
      return;
    }
    setPaying(true);
    setPayError(null);
    try {
      const res = await fetch("/api/payment/mobile-money", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contentId: parseInt(id),
          phone,
          provider: payProvider,
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setPaySuccess(true);
        // Don't auto-unlock — owner must approve from Payments tab
        setTimeout(() => {
          setPaymentModal(false);
          setPaySuccess(false);
        }, 5000);
      } else {
        throw new Error(data.error || "Payment request failed");
      }
    } catch (err) {
      setPayError(err.message);
    } finally {
      setPaying(false);
    }
  };

  const handlePayPalPay = () => {
    setPaypalPending(true);
    window.open(PAYPAL_LINK, "_blank");
    // User will come back and confirm
  };

  const handlePayPalConfirm = async () => {
    setPaying(true);
    setPayError(null);
    try {
      const res = await fetch("/api/payment/mobile-money", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contentId: parseInt(id),
          phone: "paypal",
          provider: "airtel",
        }),
      });
      const data = await res.json();
      if (data.ok) {
        setPaySuccess(true);
        setTimeout(() => {
          setPaymentModal(false);
          fetchContent();
        }, 2000);
      } else throw new Error(data.error || "Failed");
    } catch (e) {
      setPayError(e.message);
    } finally {
      setPaying(false);
    }
  };

  const seasons = [...new Set(episodes.map((e) => e.season))].sort(
    (a, b) => a - b,
  );
  const currentSeasonEps = episodes.filter((e) => e.season === selectedSeason);
  const isEpisodic = episodes.length > 0;
  const watchUrl =
    isEpisodic && selectedEp ? selectedEp.file_url : content?.file_url;

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div
          className="h-8 w-8 rounded-full border-2 border-[#7C3AED] border-t-transparent"
          style={{ animation: "spin 1s linear infinite" }}
        />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!content) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center text-white">
        <div className="text-center">
          <p className="text-gray-400 mb-4">Content not found.</p>
          <a href="/" className="text-[#A78BFA] hover:underline">
            ← Back to home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white font-inter">
      {/* Payment Modal */}
      {paymentModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center px-4 bg-black/90 backdrop-blur-sm">
          <div className="bg-[#141420] border border-white/10 rounded-2xl p-6 max-w-md w-full relative">
            <button
              onClick={() => {
                setPaymentModal(false);
                setPayError(null);
                setPaySuccess(false);
              }}
              className="absolute top-4 right-4 text-gray-500 hover:text-white"
            >
              <X size={20} />
            </button>
            <h2 className="text-xl font-black mb-1">
              Unlock "{content.title}"
            </h2>
            <p className="text-3xl font-black text-[#FBBF24] mb-6">
              ${content.price}
            </p>

            {paySuccess ? (
              <div className="text-center py-6">
                <CheckCircle
                  size={48}
                  className="text-green-400 mx-auto mb-3"
                />
                {payProvider === "mtn" || payProvider === "airtel" ? (
                  <>
                    <p className="text-white font-bold text-lg">
                      Request Submitted! 📱
                    </p>
                    <p className="text-gray-400 text-sm mt-2 leading-relaxed">
                      Now send{" "}
                      <strong className="text-yellow-400">
                        ${content.price}
                      </strong>{" "}
                      to:
                      <br />
                      <strong className="text-white text-base">
                        {payProvider === "mtn" ? MTN_NUMBER : AIRTEL_NUMBER}
                      </strong>
                    </p>
                    <p className="text-gray-500 text-xs mt-2">
                      Owner will verify and grant you access ✓
                    </p>
                  </>
                ) : (
                  <>
                    <p className="text-white font-bold text-lg">
                      Payment received!
                    </p>
                    <p className="text-gray-400 text-sm mt-1">
                      Processing your access...
                    </p>
                  </>
                )}
              </div>
            ) : (
              <>
                {/* Payment method selection */}
                <div className="space-y-2 mb-5">
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">
                    Choose Payment Method
                  </p>
                  {PROVIDERS.map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => {
                        setPayProvider(p.id);
                        setPayError(null);
                      }}
                      className={`w-full flex items-center gap-3 p-4 rounded-xl border transition-all text-left ${payProvider === p.id ? "border-[#7C3AED] bg-[#7C3AED]/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
                    >
                      <span className="text-2xl">{p.icon}</span>
                      <div className="flex-1">
                        <p className="text-sm font-bold text-white">
                          {p.label}
                        </p>
                        <p className="text-xs text-gray-500">{p.desc}</p>
                      </div>
                      {payProvider === p.id && (
                        <CheckCircle size={16} className="text-[#A78BFA]" />
                      )}
                    </button>
                  ))}
                </div>

                {/* Mobile money instructions + phone input */}
                {(payProvider === "mtn" || payProvider === "airtel") && (
                  <div className="mb-4">
                    <div
                      style={{
                        padding: "12px 14px",
                        borderRadius: "12px",
                        background: "rgba(251,191,36,.07)",
                        border: "1px solid rgba(251,191,36,.25)",
                        marginBottom: "12px",
                      }}
                    >
                      <p
                        style={{
                          fontWeight: 900,
                          fontSize: "12px",
                          color: "#FBBF24",
                          margin: "0 0 5px",
                        }}
                      >
                        {payProvider === "mtn"
                          ? "📱 MTN MoMo"
                          : "📲 Airtel Money"}{" "}
                        — Send manually
                      </p>
                      <p
                        style={{
                          fontSize: "11px",
                          color: "#9ca3af",
                          margin: 0,
                          lineHeight: 1.7,
                        }}
                      >
                        Enter your number below, then send{" "}
                        <strong style={{ color: "#FBBF24" }}>
                          ${content.price}
                        </strong>{" "}
                        to:
                        <br />
                        <strong style={{ color: "white", fontSize: "14px" }}>
                          {payProvider === "mtn" ? MTN_NUMBER : AIRTEL_NUMBER}
                        </strong>
                        <br />
                        Owner verifies &amp; grants access ✓
                      </p>
                    </div>
                    <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider block mb-1.5">
                      Your {payProvider === "mtn" ? "MTN" : "Airtel"} Phone
                      Number
                    </label>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="e.g. 0781234567"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                    />
                  </div>
                )}

                {/* PayPal */}
                {payProvider === "paypal" && !paypalPending && (
                  <div
                    className="mb-4"
                    style={{
                      padding: "12px 14px",
                      borderRadius: "12px",
                      background: "rgba(124,58,237,.08)",
                      border: "1px solid rgba(124,58,237,.2)",
                    }}
                  >
                    <p
                      style={{
                        fontSize: "12px",
                        color: "#A78BFA",
                        margin: 0,
                        lineHeight: 1.6,
                      }}
                    >
                      Clicking Pay opens PayPal. Complete{" "}
                      <strong>${content.price}</strong>, then click "I've Paid"
                      to confirm access.
                    </p>
                  </div>
                )}
                {payProvider === "paypal" && paypalPending && (
                  <div
                    className="mb-4"
                    style={{
                      padding: "12px 14px",
                      borderRadius: "12px",
                      background: "rgba(74,222,128,.08)",
                      border: "1px solid rgba(74,222,128,.3)",
                    }}
                  >
                    <p
                      style={{
                        fontWeight: 900,
                        fontSize: "13px",
                        color: "#4ade80",
                        margin: 0,
                      }}
                    >
                      ✓ Paid on PayPal?
                    </p>
                    <p
                      style={{
                        fontSize: "11px",
                        color: "#9ca3af",
                        margin: "4px 0 0",
                      }}
                    >
                      Click confirm below to activate access.
                    </p>
                  </div>
                )}

                {/* Subscribe shortcut */}
                <div className="mb-4 text-center">
                  <a
                    href="/subscribe"
                    style={{
                      fontSize: "12px",
                      color: "#A78BFA",
                      textDecoration: "none",
                    }}
                  >
                    👑 Subscribe instead — watch ALL paid content
                  </a>
                </div>

                {payError && (
                  <div className="rounded-xl bg-red-500/10 border border-red-500/20 px-4 py-3 text-sm text-red-400 mb-4">
                    {payError}
                  </div>
                )}

                {/* CTA Button */}
                {payProvider === "paypal" && !paypalPending ? (
                  <button
                    onClick={() => {
                      setPaypalPending(true);
                      if (typeof window !== "undefined")
                        window.open(PAYPAL_LINK, "_blank");
                    }}
                    className="w-full bg-blue-700 hover:bg-blue-800 text-white rounded-xl py-3.5 font-black text-sm transition-colors"
                  >
                    🅿️ Pay ${content.price} with PayPal
                  </button>
                ) : payProvider === "paypal" && paypalPending ? (
                  <button
                    onClick={handlePayPalConfirm}
                    disabled={paying}
                    className="w-full bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white rounded-xl py-3.5 font-black text-sm transition-colors"
                  >
                    {paying ? "Confirming..." : "✓ I've Paid — Confirm Access"}
                  </button>
                ) : (
                  <button
                    onClick={
                      payProvider === "stripe"
                        ? handleStripeCheckout
                        : handleMobileMoneyPay
                    }
                    disabled={paying}
                    className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-50 text-white rounded-xl py-3.5 font-black text-sm transition-colors flex items-center justify-center gap-2"
                  >
                    {paying ? (
                      <>
                        <div
                          className="h-4 w-4 rounded-full border-2 border-white border-t-transparent"
                          style={{ animation: "spin 1s linear infinite" }}
                        />{" "}
                        Processing...
                      </>
                    ) : payProvider === "mtn" || payProvider === "airtel" ? (
                      `Submit Request — $${content.price}`
                    ) : (
                      `Pay $${content.price} with ${PROVIDERS.find((p) => p.id === payProvider)?.label}`
                    )}
                  </button>
                )}
              </>
            )}
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="border-b border-white/5 px-4 sm:px-8 py-4 flex items-center justify-between bg-[#0A0A0F]">
        <a href="/" className="flex items-center gap-3">
          <img
            src={LOGO_URL}
            alt="Intergalactic Dimensions"
            className="h-9 w-auto object-contain"
          />
          <div className="hidden sm:block">
            <div className="text-[10px] font-bold tracking-[0.2em] text-[#A78BFA]">
              INTERGALACTIC
            </div>
            <div className="text-[10px] font-bold tracking-[0.2em] text-white">
              DIMENSIONS
            </div>
          </div>
        </a>
        <a
          href="/"
          className="flex items-center gap-1.5 text-gray-400 hover:text-white text-sm transition-colors"
        >
          <ArrowLeft size={15} /> Back
        </a>
      </nav>

      <div className="max-w-screen-xl mx-auto px-4 sm:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Player/Content */}
          <div className="lg:col-span-2">
            {/* Currently Playing Info */}
            <div className="mb-4">
              <div className="flex items-center gap-2 mb-2">
                {content.type === "series" && selectedEp && (
                  <span className="text-xs font-bold text-[#A78BFA] bg-[#7C3AED]/10 rounded-full px-3 py-1">
                    S{selectedEp.season} E{selectedEp.episode_number}
                  </span>
                )}
                <span className="text-xs text-gray-500 uppercase tracking-wider">
                  {content.genre_name}
                </span>
                {content.is_free ? (
                  <span className="text-xs font-bold text-green-400 bg-green-500/10 rounded-full px-2 py-0.5">
                    FREE
                  </span>
                ) : (
                  <span className="text-xs font-bold text-[#FBBF24] bg-[#FBBF24]/10 rounded-full px-2 py-0.5">
                    ${content.price}
                  </span>
                )}
              </div>
              <h1 className="text-2xl sm:text-3xl font-black">
                {content.title}
                {selectedEp ? ` — "${selectedEp.title}"` : ""}
              </h1>
            </div>

            {/* Video / Content Player */}
            <div className="relative rounded-2xl overflow-hidden bg-black aspect-video mb-4">
              {needsPurchase || (!user && !content.is_free) ? (
                <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#1a0533] to-[#0d0d2b]">
                  {content.poster_url && (
                    <img
                      src={content.poster_url}
                      alt={content.title}
                      className="absolute inset-0 w-full h-full object-cover opacity-20"
                    />
                  )}
                  <div className="relative z-10 text-center p-8">
                    <div className="h-16 w-16 rounded-full bg-[#7C3AED]/20 flex items-center justify-center mx-auto mb-4">
                      <Lock size={28} className="text-[#A78BFA]" />
                    </div>
                    <h3 className="text-xl font-black mb-2">
                      This content is paid
                    </h3>
                    <p className="text-gray-400 text-sm mb-6">
                      Unlock for{" "}
                      <strong className="text-[#FBBF24]">
                        ${content.price}
                      </strong>
                    </p>
                    {user ? (
                      <div
                        style={{
                          display: "flex",
                          flexDirection: "column",
                          gap: 12,
                          alignItems: "center",
                        }}
                      >
                        <button
                          onClick={() => setPaymentModal(true)}
                          className="bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl px-8 py-3 font-black transition-colors"
                        >
                          Unlock for ${content.price}
                        </button>
                        <a
                          href="/subscribe"
                          className="text-[#A78BFA] text-sm hover:underline flex items-center gap-1"
                        >
                          👑 Or Subscribe — Watch All Paid Content
                        </a>
                      </div>
                    ) : (
                      <div className="flex flex-col gap-3 items-center">
                        <a
                          href="/account/signin"
                          className="bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl px-8 py-3 font-black transition-colors"
                        >
                          Sign In to Purchase
                        </a>
                        <a
                          href="/subscribe"
                          className="text-[#A78BFA] text-sm hover:underline"
                        >
                          👑 Subscribe — Watch Everything
                        </a>
                        <a
                          href="/account/signup"
                          className="text-gray-400 text-sm hover:text-white"
                        >
                          No account? Join free →
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              ) : !user && content.is_free ? (
                <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-[#1a0533] to-[#0d0d2b]">
                  {content.poster_url && (
                    <img
                      src={content.poster_url}
                      alt=""
                      className="absolute inset-0 w-full h-full object-cover opacity-20"
                    />
                  )}
                  <div className="relative z-10 text-center p-8">
                    <div className="h-16 w-16 rounded-full bg-[#7C3AED]/20 flex items-center justify-center mx-auto mb-4">
                      <Lock size={28} className="text-[#A78BFA]" />
                    </div>
                    <h3 className="text-xl font-black mb-2">
                      Sign in to watch
                    </h3>
                    <p className="text-gray-400 text-sm mb-6">
                      This content is free — just sign in to access it.
                    </p>
                    <a
                      href="/account/signin"
                      className="bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl px-8 py-3 font-black transition-colors"
                    >
                      Sign In Free
                    </a>
                  </div>
                </div>
              ) : watchUrl ? (
                <StreamPlayer
                  url={watchUrl}
                  title={selectedEp ? selectedEp.title : content.title}
                  siteName={getStreamSite(watchUrl)}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-[#141420]">
                  <p className="text-gray-500">No video available</p>
                </div>
              )}
            </div>

            {/* Episode description */}
            {selectedEp && (
              <div className="rounded-xl bg-[#141420] border border-white/5 p-4 mb-6">
                <p className="text-sm text-gray-300 leading-relaxed">
                  {selectedEp.description}
                </p>
                {selectedEp.duration && (
                  <p className="text-xs text-gray-600 mt-2">
                    Duration: {selectedEp.duration}
                  </p>
                )}
              </div>
            )}

            {/* Content info */}
            <div className="rounded-xl bg-[#141420] border border-white/5 p-5">
              <h3 className="font-bold text-lg mb-3">{content.title}</h3>
              <p className="text-sm text-gray-300 leading-relaxed mb-4">
                {content.description}
              </p>
              <div className="flex items-center gap-4 text-xs text-gray-500 flex-wrap">
                {content.owner_name && <span>By {content.owner_name}</span>}
                {content.genre_name && <span>• {content.genre_name}</span>}
                {(content.views || 0) > 0 && (
                  <span className="flex items-center gap-1">
                    <Eye size={10} /> {content.views} views
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Episodes Sidebar */}
          <div className="lg:col-span-1">
            {isEpisodic ? (
              <div>
                <h2 className="text-base font-black mb-4 flex items-center gap-2">
                  <Film size={16} className="text-[#A78BFA]" /> Episodes
                </h2>

                {/* Season tabs */}
                {seasons.length > 1 && (
                  <div className="flex gap-2 mb-4 flex-wrap">
                    {seasons.map((s) => (
                      <button
                        key={s}
                        onClick={() => setSelectedSeason(s)}
                        className={`rounded-full px-4 py-1.5 text-xs font-bold border transition-colors ${selectedSeason === s ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"}`}
                      >
                        Season {s}
                      </button>
                    ))}
                  </div>
                )}

                <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                  {currentSeasonEps.map((ep) => {
                    const isActive = selectedEp?.id === ep.id;
                    return (
                      <button
                        key={ep.id}
                        onClick={() => handleEpisodeSelect(ep)}
                        className={`w-full flex items-center gap-3 rounded-xl border p-3 text-left transition-all ${isActive ? "border-[#7C3AED] bg-[#7C3AED]/10" : "border-white/5 bg-[#141420] hover:border-white/20"}`}
                      >
                        <div
                          className={`flex-shrink-0 h-10 w-10 rounded-lg flex items-center justify-center font-black text-sm ${isActive ? "bg-[#7C3AED] text-white" : "bg-white/5 text-gray-400"}`}
                        >
                          {isActive ? (
                            <Play size={14} fill="white" />
                          ) : (
                            ep.episode_number
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-bold text-white truncate">
                            Ep {ep.episode_number}: {ep.title}
                          </p>
                          <p className="text-[10px] text-gray-500 mt-0.5">
                            {ep.duration || "22 min"}
                          </p>
                        </div>
                        {(ep.views || 0) > 0 && (
                          <span className="text-[9px] text-gray-600 flex items-center gap-0.5 flex-shrink-0">
                            <Eye size={8} /> {ep.views}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              /* Non-series: show poster */
              <div>
                {content.poster_url && (
                  <div className="rounded-xl overflow-hidden mb-4 aspect-[2/3]">
                    <img
                      src={content.poster_url}
                      alt={content.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                {!content.is_free && !needsPurchase && user && (
                  <div className="rounded-xl bg-green-500/10 border border-green-500/20 p-4 text-center">
                    <CheckCircle
                      size={24}
                      className="text-green-400 mx-auto mb-2"
                    />
                    <p className="text-sm text-green-400 font-bold">
                      You own this content
                    </p>
                  </div>
                )}
                {!content.is_free && needsPurchase && (
                  <button
                    onClick={() => setPaymentModal(true)}
                    className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl py-4 font-black text-sm transition-colors"
                  >
                    Unlock for ${content.price}
                  </button>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
