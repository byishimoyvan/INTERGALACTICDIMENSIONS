"use client";
import { useState, useEffect } from "react";
import useUser from "@/utils/useUser";
import { Crown, Check, ArrowLeft, Clock } from "lucide-react";

const LOGO_URL =
  "https://raw.createusercontent.com/83c42dc4-4b43-4e42-aded-b337415f50ea/";
const PAYPAL_LINK = "https://www.paypal.com/ncp/payment/RF5TALRF8C4Q6";
const MTN_NUMBER = "0799395838";
const AIRTEL_NUMBER = "0722461585";

const DEFAULT_PLANS = [
  {
    id: "monthly",
    label: "Monthly",
    price: 9.99,
    months: 1,
    popular: false,
    savings: null,
  },
  {
    id: "2month",
    label: "2 Months",
    price: 17.99,
    months: 2,
    popular: false,
    savings: "10%",
  },
  {
    id: "quarterly",
    label: "3 Months",
    price: 24.99,
    months: 3,
    popular: true,
    savings: "17%",
  },
  {
    id: "biannual",
    label: "6 Months",
    price: 44.99,
    months: 6,
    popular: false,
    savings: "25%",
  },
  {
    id: "yearly",
    label: "1 Year",
    price: 79.99,
    months: 12,
    popular: false,
    savings: "33%",
  },
];

const PERKS = [
  "Watch all paid movies, series & books",
  "Free content always included",
  "PayPal: instant activation",
  "MTN & Airtel: owner verifies & activates",
  "Cancel or switch plan anytime",
];

const centered = {
  minHeight: "100vh",
  background: "#030308",
  color: "white",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  padding: 24,
  textAlign: "center",
};

export default function SubscribePage() {
  const { data: user, loading: userLoading } = useUser();
  const [plans, setPlans] = useState(DEFAULT_PLANS);
  const [selectedPlan, setSelectedPlan] = useState("quarterly");
  const [payMethod, setPayMethod] = useState("paypal");
  const [phone, setPhone] = useState("");
  const [step, setStep] = useState("main");
  const [paying, setPaying] = useState(false);
  const [error, setError] = useState(null);
  const [currentSub, setCurrentSub] = useState(null);

  useEffect(() => {
    // Load owner-edited plan prices
    fetch("/api/subscriptions?plans=1")
      .then((r) => r.json())
      .then((d) => {
        if (d.plans) {
          const savings = {
            monthly: null,
            "2month": "10%",
            quarterly: "17%",
            biannual: "25%",
            yearly: "33%",
          };
          const popular = {
            monthly: false,
            "2month": false,
            quarterly: true,
            biannual: false,
            yearly: false,
          };
          const months = {
            monthly: 1,
            "2month": 2,
            quarterly: 3,
            biannual: 6,
            yearly: 12,
          };
          setPlans(
            Object.entries(d.plans).map(([id, p]) => ({
              id,
              label: p.label,
              price: p.price,
              months: months[id] || 1,
              popular: popular[id] || false,
              savings: savings[id] || null,
            })),
          );
        }
      })
      .catch(() => {});
    if (user) {
      fetch("/api/subscriptions")
        .then((r) => r.json())
        .then((d) => {
          if (d.active) setCurrentSub(d.subscription);
        })
        .catch(() => {});
    }
  }, [user]);

  const plan = plans.find((p) => p.id === selectedPlan) || DEFAULT_PLANS[2];

  const handlePayPal = () => {
    if (typeof window !== "undefined") window.open(PAYPAL_LINK, "_blank");
    setStep("paypal-confirm");
  };

  const handlePayPalConfirm = async () => {
    setPaying(true);
    setError(null);
    try {
      const res = await fetch("/api/subscriptions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          plan: selectedPlan,
          paymentMethod: "paypal",
          reference: `PAYPAL-${selectedPlan}-${Date.now()}`,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Failed to activate");
      setStep("success");
    } catch (e) {
      setError(e.message);
    } finally {
      setPaying(false);
    }
  };

  const handleMobileMoney = async () => {
    if (!phone) {
      setError("Please enter your phone number.");
      return;
    }
    setPaying(true);
    setError(null);
    try {
      const res = await fetch("/api/payment/mobile-money", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          subscriptionPlan: selectedPlan,
          phone,
          provider: payMethod,
        }),
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error || "Request failed");
      setStep("pending");
    } catch (e) {
      setError(e.message);
    } finally {
      setPaying(false);
    }
  };

  // ── NOT SIGNED IN ──
  if (!userLoading && !user) {
    return (
      <div style={centered}>
        <Crown size={44} style={{ color: "#A78BFA", marginBottom: 20 }} />
        <h1 style={{ fontSize: 28, fontWeight: 900, marginBottom: 12 }}>
          Subscribe to Watch Everything
        </h1>
        <p style={{ color: "#9ca3af", fontSize: 15, marginBottom: 32 }}>
          Sign in first, then choose your plan.
        </p>
        <div
          style={{
            display: "flex",
            gap: 12,
            flexWrap: "wrap",
            justifyContent: "center",
          }}
        >
          <a
            href="/account/signin"
            style={{
              padding: "13px 28px",
              borderRadius: 14,
              background: "linear-gradient(135deg,#7C3AED,#6D28D9)",
              color: "white",
              textDecoration: "none",
              fontWeight: 900,
            }}
          >
            Sign In
          </a>
          <a
            href="/account/signup"
            style={{
              padding: "13px 28px",
              borderRadius: 14,
              background: "rgba(255,255,255,.07)",
              border: "1px solid rgba(255,255,255,.12)",
              color: "white",
              textDecoration: "none",
              fontWeight: 900,
            }}
          >
            Join Free
          </a>
        </div>
      </div>
    );
  }

  // ── SUCCESS ──
  if (step === "success") {
    return (
      <div style={centered}>
        <div
          style={{
            height: 80,
            width: 80,
            borderRadius: "50%",
            background:
              "linear-gradient(135deg,rgba(74,222,128,.2),rgba(34,197,94,.1))",
            border: "2px solid rgba(74,222,128,.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 24,
          }}
        >
          <Check size={36} style={{ color: "#4ade80" }} />
        </div>
        <h1 style={{ fontSize: 28, fontWeight: 900, marginBottom: 12 }}>
          Subscription Active! 🎉
        </h1>
        <p style={{ color: "#9ca3af", fontSize: 15, marginBottom: 8 }}>
          You can now watch all paid content.
        </p>
        <p style={{ color: "#6b7280", fontSize: 13, marginBottom: 36 }}>
          Plan: <strong style={{ color: "#A78BFA" }}>{plan?.label}</strong> · $
          {plan?.price}
        </p>
        <a
          href="/"
          style={{
            padding: "14px 32px",
            borderRadius: 14,
            background: "linear-gradient(135deg,#7C3AED,#6D28D9)",
            color: "white",
            textDecoration: "none",
            fontWeight: 900,
            fontSize: 15,
          }}
        >
          Start Watching →
        </a>
      </div>
    );
  }

  // ── PENDING (MTN/Airtel manual) ──
  if (step === "pending") {
    const ownerNum = payMethod === "mtn" ? MTN_NUMBER : AIRTEL_NUMBER;
    const providerName =
      payMethod === "mtn" ? "MTN Mobile Money" : "Airtel Money";
    return (
      <div style={centered}>
        <div
          style={{
            height: 80,
            width: 80,
            borderRadius: "50%",
            background: "rgba(251,191,36,.12)",
            border: "2px solid rgba(251,191,36,.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 24,
            fontSize: 38,
          }}
        >
          {payMethod === "mtn" ? "📱" : "📲"}
        </div>
        <h1 style={{ fontSize: 26, fontWeight: 900, marginBottom: 12 }}>
          Request Submitted!
        </h1>
        <p
          style={{
            color: "#9ca3af",
            fontSize: 15,
            marginBottom: 20,
            maxWidth: 420,
          }}
        >
          Now send <strong style={{ color: "#FBBF24" }}>${plan?.price}</strong>{" "}
          to the owner's {providerName}:
        </p>
        <div
          style={{
            margin: "0 0 24px",
            padding: "20px 40px",
            borderRadius: 16,
            background: "rgba(251,191,36,.07)",
            border: "1px solid rgba(251,191,36,.3)",
          }}
        >
          <p
            style={{
              fontWeight: 900,
              fontSize: 28,
              color: "#FBBF24",
              margin: "0 0 4px",
            }}
          >
            {ownerNum}
          </p>
          <p style={{ color: "#9ca3af", fontSize: 13, margin: 0 }}>
            {providerName}
          </p>
        </div>
        <div
          style={{
            padding: "16px 24px",
            borderRadius: 14,
            background: "rgba(167,139,250,.07)",
            border: "1px solid rgba(167,139,250,.2)",
            maxWidth: 440,
            marginBottom: 28,
          }}
        >
          <p
            style={{
              fontSize: 13,
              color: "#A78BFA",
              margin: 0,
              lineHeight: 1.75,
            }}
          >
            <Clock
              size={12}
              style={{
                display: "inline",
                verticalAlign: "middle",
                marginRight: 4,
              }}
            />
            After sending the money, the owner will verify and activate your{" "}
            <strong>{plan?.label}</strong> subscription — usually within a few
            minutes.
          </p>
        </div>
        <a
          href="/"
          style={{
            padding: "12px 28px",
            borderRadius: 14,
            background: "rgba(255,255,255,.07)",
            border: "1px solid rgba(255,255,255,.12)",
            color: "white",
            textDecoration: "none",
            fontWeight: 700,
            fontSize: 14,
          }}
        >
          Back to Home
        </a>
      </div>
    );
  }

  // ── MAIN PAGE ──
  return (
    <div style={{ minHeight: "100vh", background: "#030308", color: "white" }}>
      {/* Ambient bg */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          pointerEvents: "none",
          zIndex: 0,
        }}
      >
        <div
          style={{
            position: "absolute",
            width: 800,
            height: 800,
            top: -300,
            left: -250,
            borderRadius: "50%",
            background:
              "radial-gradient(circle,rgba(124,58,237,.1) 0%,transparent 65%)",
          }}
        />
        <div
          style={{
            position: "absolute",
            width: 600,
            height: 600,
            bottom: 0,
            right: -200,
            borderRadius: "50%",
            background:
              "radial-gradient(circle,rgba(6,182,212,.06) 0%,transparent 65%)",
          }}
        />
      </div>

      {/* Nav */}
      <nav
        style={{
          position: "sticky",
          top: 0,
          zIndex: 50,
          borderBottom: "1px solid rgba(255,255,255,.05)",
          background: "rgba(3,3,8,.95)",
          backdropFilter: "blur(18px)",
          padding: "0 24px",
        }}
      >
        <div
          style={{
            maxWidth: 1100,
            margin: "0 auto",
            height: 64,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <a
            href="/"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              textDecoration: "none",
            }}
          >
            <img
              src={LOGO_URL}
              alt=""
              style={{ height: 34, objectFit: "contain" }}
            />
            <div>
              <div
                style={{
                  fontSize: "8.5px",
                  fontWeight: 900,
                  letterSpacing: ".26em",
                  color: "#A78BFA",
                }}
              >
                INTERGALACTIC
              </div>
              <div
                style={{
                  fontSize: "8.5px",
                  fontWeight: 900,
                  letterSpacing: ".26em",
                  color: "white",
                }}
              >
                DIMENSIONS
              </div>
            </div>
          </a>
          <a
            href="/"
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              color: "#9ca3af",
              textDecoration: "none",
              fontSize: 13,
            }}
          >
            <ArrowLeft size={14} /> Back to Home
          </a>
        </div>
      </nav>

      <div
        style={{
          position: "relative",
          zIndex: 10,
          maxWidth: 1100,
          margin: "0 auto",
          padding: "48px 24px 80px",
        }}
      >
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: 52 }}>
          <div
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 8,
              background: "rgba(124,58,237,.15)",
              border: "1px solid rgba(124,58,237,.3)",
              borderRadius: 20,
              padding: "6px 16px",
              marginBottom: 18,
            }}
          >
            <Crown size={13} style={{ color: "#A78BFA" }} />
            <span
              style={{
                fontSize: 11,
                fontWeight: 900,
                letterSpacing: ".2em",
                color: "#A78BFA",
                textTransform: "uppercase",
              }}
            >
              All Access Pass
            </span>
          </div>
          <h1
            style={{
              fontSize: "clamp(32px,5vw,52px)",
              fontWeight: 900,
              lineHeight: 1.05,
              letterSpacing: "-.02em",
              margin: "0 0 16px",
              background:
                "linear-gradient(140deg,#fff 0%,#c4b5fd 55%,#a78bfa 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}
          >
            Watch Everything,
            <br />
            Any Time.
          </h1>
          <p
            style={{
              color: "#9ca3af",
              fontSize: 15,
              maxWidth: 480,
              margin: "0 auto",
            }}
          >
            One subscription unlocks all paid movies, series & books. Free
            content always stays free.
          </p>
          {currentSub && (
            <div
              style={{
                display: "inline-block",
                marginTop: 16,
                padding: "10px 20px",
                borderRadius: 12,
                background: "rgba(74,222,128,.1)",
                border: "1px solid rgba(74,222,128,.3)",
              }}
            >
              <p
                style={{
                  margin: 0,
                  fontSize: 13,
                  color: "#4ade80",
                  fontWeight: 700,
                }}
              >
                ✓ Active subscription — expires{" "}
                {new Date(currentSub.ends_at).toLocaleDateString()}
              </p>
            </div>
          )}
        </div>

        <div className="sub-grid">
          {/* LEFT — Plans */}
          <div>
            <h2
              style={{
                fontSize: 16,
                fontWeight: 900,
                marginBottom: 18,
                color: "#d1d5db",
              }}
            >
              Choose Your Plan
            </h2>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {plans.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedPlan(p.id)}
                  style={{
                    position: "relative",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "16px 20px",
                    borderRadius: 16,
                    border: `2px solid ${selectedPlan === p.id ? "#7C3AED" : "rgba(255,255,255,.08)"}`,
                    background:
                      selectedPlan === p.id
                        ? "rgba(124,58,237,.12)"
                        : "rgba(255,255,255,.03)",
                    cursor: "pointer",
                    transition: "all .25s",
                    textAlign: "left",
                  }}
                >
                  {p.popular && (
                    <div
                      style={{
                        position: "absolute",
                        top: -10,
                        left: 20,
                        background: "linear-gradient(135deg,#7C3AED,#6D28D9)",
                        color: "white",
                        fontSize: 9,
                        fontWeight: 900,
                        padding: "3px 10px",
                        borderRadius: 10,
                        letterSpacing: ".1em",
                      }}
                    >
                      MOST POPULAR
                    </div>
                  )}
                  <div
                    style={{ display: "flex", alignItems: "center", gap: 12 }}
                  >
                    <div
                      style={{
                        height: 20,
                        width: 20,
                        borderRadius: "50%",
                        border: `2px solid ${selectedPlan === p.id ? "#7C3AED" : "rgba(255,255,255,.2)"}`,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                    >
                      {selectedPlan === p.id && (
                        <div
                          style={{
                            height: 10,
                            width: 10,
                            borderRadius: "50%",
                            background: "#7C3AED",
                          }}
                        />
                      )}
                    </div>
                    <div>
                      <p
                        style={{
                          margin: 0,
                          fontWeight: 900,
                          fontSize: 15,
                          color: "white",
                        }}
                      >
                        {p.label}
                      </p>
                      <p
                        style={{
                          margin: "2px 0 0",
                          fontSize: 12,
                          color: "#6b7280",
                        }}
                      >
                        {p.months} month{p.months > 1 ? "s" : ""}
                      </p>
                    </div>
                  </div>
                  <div style={{ textAlign: "right" }}>
                    <p
                      style={{
                        margin: 0,
                        fontWeight: 900,
                        fontSize: 18,
                        color: selectedPlan === p.id ? "#A78BFA" : "white",
                      }}
                    >
                      ${p.price}
                    </p>
                    {p.savings && (
                      <span
                        style={{
                          fontSize: 10,
                          fontWeight: 700,
                          color: "#4ade80",
                          background: "rgba(74,222,128,.1)",
                          padding: "2px 7px",
                          borderRadius: 8,
                        }}
                      >
                        Save {p.savings}
                      </span>
                    )}
                  </div>
                </button>
              ))}
            </div>

            {/* Perks */}
            <div
              style={{
                marginTop: 28,
                padding: 20,
                borderRadius: 16,
                background: "rgba(255,255,255,.03)",
                border: "1px solid rgba(255,255,255,.07)",
              }}
            >
              <p
                style={{
                  fontSize: 12,
                  fontWeight: 900,
                  color: "#A78BFA",
                  marginBottom: 14,
                  textTransform: "uppercase",
                  letterSpacing: ".15em",
                }}
              >
                What's included
              </p>
              {PERKS.map((perk, i) => (
                <div
                  key={i}
                  style={{
                    display: "flex",
                    alignItems: "flex-start",
                    gap: 10,
                    marginBottom: 10,
                  }}
                >
                  <div
                    style={{
                      height: 18,
                      width: 18,
                      borderRadius: "50%",
                      background: "rgba(74,222,128,.15)",
                      border: "1px solid rgba(74,222,128,.3)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      flexShrink: 0,
                      marginTop: 1,
                    }}
                  >
                    <Check size={10} style={{ color: "#4ade80" }} />
                  </div>
                  <p style={{ margin: 0, fontSize: 13, color: "#d1d5db" }}>
                    {perk}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* RIGHT — Payment */}
          <div>
            <h2
              style={{
                fontSize: 16,
                fontWeight: 900,
                marginBottom: 18,
                color: "#d1d5db",
              }}
            >
              Pay with
            </h2>

            {/* Method selector */}
            <div
              style={{
                display: "flex",
                flexDirection: "column",
                gap: 10,
                marginBottom: 24,
              }}
            >
              {[
                {
                  id: "paypal",
                  label: "PayPal",
                  icon: "🅿️",
                  desc: "Safe & instant · activate immediately",
                },
                {
                  id: "mtn",
                  label: "MTN Mobile Money",
                  icon: "📱",
                  desc: `Send to: ${MTN_NUMBER} · Owner activates manually`,
                },
                {
                  id: "airtel",
                  label: "Airtel Money",
                  icon: "📲",
                  desc: `Send to: ${AIRTEL_NUMBER} · Owner activates manually`,
                },
              ].map((m) => (
                <button
                  key={m.id}
                  onClick={() => {
                    setPayMethod(m.id);
                    setError(null);
                  }}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 14,
                    padding: "16px 20px",
                    borderRadius: 16,
                    border: `2px solid ${payMethod === m.id ? "#7C3AED" : "rgba(255,255,255,.08)"}`,
                    background:
                      payMethod === m.id
                        ? "rgba(124,58,237,.12)"
                        : "rgba(255,255,255,.03)",
                    cursor: "pointer",
                    transition: "all .25s",
                    textAlign: "left",
                  }}
                >
                  <span style={{ fontSize: 24 }}>{m.icon}</span>
                  <div style={{ flex: 1 }}>
                    <p
                      style={{
                        margin: 0,
                        fontWeight: 900,
                        fontSize: 14,
                        color: "white",
                      }}
                    >
                      {m.label}
                    </p>
                    <p
                      style={{
                        margin: "2px 0 0",
                        fontSize: 11,
                        color: "#6b7280",
                      }}
                    >
                      {m.desc}
                    </p>
                  </div>
                  {payMethod === m.id && (
                    <Check
                      size={16}
                      style={{ color: "#A78BFA", flexShrink: 0 }}
                    />
                  )}
                </button>
              ))}
            </div>

            {/* MTN/Airtel: instructions + phone */}
            {(payMethod === "mtn" || payMethod === "airtel") && (
              <div>
                <div
                  style={{
                    marginBottom: 16,
                    padding: "14px 18px",
                    borderRadius: 12,
                    background: "rgba(251,191,36,.07)",
                    border: "1px solid rgba(251,191,36,.25)",
                  }}
                >
                  <p
                    style={{
                      fontWeight: 900,
                      fontSize: 13,
                      color: "#FBBF24",
                      margin: "0 0 6px",
                    }}
                  >
                    {payMethod === "mtn" ? "📱 MTN MoMo" : "📲 Airtel Money"} —
                    How it works
                  </p>
                  <p
                    style={{
                      fontSize: 12,
                      color: "#9ca3af",
                      margin: 0,
                      lineHeight: 1.75,
                    }}
                  >
                    1. Enter your phone number &amp; click submit
                    <br />
                    2. Send{" "}
                    <strong style={{ color: "#FBBF24" }}>${plan?.price}</strong>{" "}
                    to the owner's number:{" "}
                    <strong style={{ color: "white" }}>
                      {payMethod === "mtn" ? MTN_NUMBER : AIRTEL_NUMBER}
                    </strong>
                    <br />
                    3. Owner verifies &amp; activates your subscription ✓
                  </p>
                </div>
                <div style={{ marginBottom: 20 }}>
                  <label
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: "#9ca3af",
                      textTransform: "uppercase",
                      letterSpacing: ".1em",
                      display: "block",
                      marginBottom: 8,
                    }}
                  >
                    Your {payMethod === "mtn" ? "MTN" : "Airtel"} Phone Number
                  </label>
                  <input
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="e.g. 0781234567"
                    style={{
                      width: "100%",
                      background: "rgba(255,255,255,.06)",
                      border: "1px solid rgba(255,255,255,.1)",
                      borderRadius: 12,
                      color: "white",
                      outline: "none",
                      padding: "12px 16px",
                      fontSize: 14,
                    }}
                  />
                </div>
              </div>
            )}

            {/* PayPal instructions */}
            {payMethod === "paypal" && step !== "paypal-confirm" && (
              <div
                style={{
                  marginBottom: 20,
                  padding: 16,
                  borderRadius: 12,
                  background: "rgba(124,58,237,.08)",
                  border: "1px solid rgba(124,58,237,.2)",
                }}
              >
                <p
                  style={{
                    margin: 0,
                    fontSize: 13,
                    color: "#A78BFA",
                    lineHeight: 1.6,
                  }}
                >
                  Click below → complete <strong>${plan?.price}</strong> on
                  PayPal → come back → click <em>"I've Paid — Activate Now"</em>
                  .
                </p>
              </div>
            )}
            {step === "paypal-confirm" && (
              <div
                style={{
                  marginBottom: 20,
                  padding: 16,
                  borderRadius: 12,
                  background: "rgba(74,222,128,.08)",
                  border: "1px solid rgba(74,222,128,.3)",
                }}
              >
                <p
                  style={{
                    margin: 0,
                    fontSize: 14,
                    color: "#4ade80",
                    fontWeight: 700,
                  }}
                >
                  ✓ PayPal payment completed?
                </p>
                <p
                  style={{ margin: "6px 0 0", fontSize: 12, color: "#9ca3af" }}
                >
                  Click below to activate your subscription immediately.
                </p>
              </div>
            )}

            {error && (
              <div
                style={{
                  marginBottom: 16,
                  padding: 14,
                  borderRadius: 12,
                  background: "rgba(239,68,68,.1)",
                  border: "1px solid rgba(239,68,68,.25)",
                  fontSize: 13,
                  color: "#f87171",
                }}
              >
                {error}
              </div>
            )}

            {/* Order summary */}
            <div
              style={{
                padding: "16px 20px",
                borderRadius: 14,
                background: "rgba(255,255,255,.04)",
                border: "1px solid rgba(255,255,255,.07)",
                marginBottom: 20,
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  marginBottom: 8,
                }}
              >
                <span style={{ fontSize: 13, color: "#9ca3af" }}>
                  {plan?.label} Plan
                </span>
                <span style={{ fontSize: 13, fontWeight: 700 }}>
                  ${plan?.price}
                </span>
              </div>
              {plan?.savings && (
                <div
                  style={{ display: "flex", justifyContent: "space-between" }}
                >
                  <span style={{ fontSize: 12, color: "#4ade80" }}>
                    Savings
                  </span>
                  <span
                    style={{ fontSize: 12, color: "#4ade80", fontWeight: 700 }}
                  >
                    {plan.savings} off
                  </span>
                </div>
              )}
              <div
                style={{
                  borderTop: "1px solid rgba(255,255,255,.07)",
                  marginTop: 12,
                  paddingTop: 12,
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <span style={{ fontSize: 15, fontWeight: 900 }}>Total</span>
                <span
                  style={{ fontSize: 18, fontWeight: 900, color: "#A78BFA" }}
                >
                  ${plan?.price}
                </span>
              </div>
            </div>

            {/* CTA */}
            {step === "paypal-confirm" ? (
              <button
                onClick={handlePayPalConfirm}
                disabled={paying}
                style={{
                  width: "100%",
                  padding: "16px 0",
                  borderRadius: 14,
                  background: "linear-gradient(135deg,#4ade80,#16a34a)",
                  color: "white",
                  border: "none",
                  fontWeight: 900,
                  fontSize: 15,
                  cursor: paying ? "default" : "pointer",
                  opacity: paying ? 0.7 : 1,
                }}
              >
                {paying ? "Activating..." : "✓ I've Paid — Activate Now"}
              </button>
            ) : payMethod === "paypal" ? (
              <button
                onClick={handlePayPal}
                style={{
                  width: "100%",
                  padding: "16px 0",
                  borderRadius: 14,
                  background: "linear-gradient(135deg,#0070ba,#003087)",
                  color: "white",
                  border: "none",
                  fontWeight: 900,
                  fontSize: 15,
                  cursor: "pointer",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 10,
                }}
              >
                🅿️ Pay ${plan?.price} with PayPal
              </button>
            ) : (
              <button
                onClick={handleMobileMoney}
                disabled={paying}
                style={{
                  width: "100%",
                  padding: "16px 0",
                  borderRadius: 14,
                  background: paying
                    ? "rgba(124,58,237,.4)"
                    : "linear-gradient(135deg,#7C3AED,#6D28D9)",
                  color: "white",
                  border: "none",
                  fontWeight: 900,
                  fontSize: 15,
                  cursor: paying ? "default" : "pointer",
                }}
              >
                {paying
                  ? "Submitting..."
                  : `Submit ${payMethod === "mtn" ? "MTN MoMo" : "Airtel Money"} Request — $${plan?.price}`}
              </button>
            )}

            <p
              style={{
                textAlign: "center",
                fontSize: 11,
                color: "#4b5563",
                marginTop: 14,
              }}
            >
              Free content is always accessible without a subscription.
            </p>
          </div>
        </div>
      </div>

      <style>{`.sub-grid{display:grid;grid-template-columns:1fr 1fr;gap:48px;align-items:start}@media(max-width:768px){.sub-grid{grid-template-columns:1fr}}`}</style>
    </div>
  );
}
