import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { contentId, redirectURL } = await request.json();
    if (!contentId) {
      return Response.json(
        { error: "Content ID is required" },
        { status: 400 },
      );
    }

    const content =
      await sql`SELECT * FROM content WHERE id = ${contentId} LIMIT 1`;
    if (!content[0]) {
      return Response.json({ error: "Content not found" }, { status: 404 });
    }

    if (content[0].is_free) {
      return Response.json({ error: "Content is free" }, { status: 400 });
    }

    const userId = session.user.id;
    const email = session.user.email;

    // Get or create stripe customer
    const userRows =
      await sql`SELECT stripe_id FROM auth_users WHERE id = ${userId}`;
    let stripeCustomerId = userRows[0]?.stripe_id;

    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({ email });
      stripeCustomerId = customer.id;
      await sql`UPDATE auth_users SET stripe_id = ${stripeCustomerId} WHERE id = ${userId}`;
    }

    const checkoutSession = await stripe.checkout.sessions.create({
      customer: stripeCustomerId,
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: "usd",
            product_data: {
              name: content[0].title,
              description: content[0].description,
              images: content[0].poster_url ? [content[0].poster_url] : [],
            },
            unit_amount: Math.round(content[0].price * 100),
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${redirectURL}?session_id={CHECKOUT_SESSION_ID}&content_id=${contentId}`,
      cancel_url: redirectURL,
      metadata: {
        userId,
        contentId,
      },
    });

    return Response.json({ url: checkoutSession.url });
  } catch (err) {
    console.error("POST /api/checkout error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
