import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const purchases = await sql`
      SELECT p.*, c.title, c.type, c.poster_url
      FROM purchases p
      JOIN content c ON p.content_id = c.id
      WHERE p.user_id = ${userId}
      ORDER BY p.created_at DESC
    `;
    return Response.json({ purchases });
  } catch (err) {
    console.error("GET /api/purchases error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { stripe_session_id, content_id } = await request.json();
    if (!stripe_session_id || !content_id) {
      return Response.json({ error: "Missing fields" }, { status: 400 });
    }

    const userId = session.user.id;

    // In a real app, we would verify with Stripe here, but for simplicity we'll just record it
    // Actually, let's just insert it.
    const content =
      await sql`SELECT price FROM content WHERE id = ${content_id}`;
    const amount = content[0]?.price || 0;

    const result = await sql`
      INSERT INTO purchases (user_id, content_id, amount, stripe_session_id)
      VALUES (${userId}, ${content_id}, ${amount}, ${stripe_session_id})
      ON CONFLICT DO NOTHING
      RETURNING *
    `;

    return Response.json({ purchase: result[0] });
  } catch (err) {
    console.error("POST /api/purchases error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
