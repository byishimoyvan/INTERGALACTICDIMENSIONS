import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET() {
  try {
    const rows =
      await sql`SELECT key, value FROM platform_settings ORDER BY key`;
    const settings = {};
    for (const row of rows) {
      settings[row.key] = row.value;
    }
    return Response.json({ settings });
  } catch (err) {
    console.error("GET /api/settings error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const session = await auth();
    if (!session?.user?.id)
      return Response.json({ error: "Unauthorized" }, { status: 401 });

    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner")
      return Response.json({ error: "Forbidden" }, { status: 403 });

    const body = await request.json();
    // body is { key: value, key2: value2, ... }
    const entries = Object.entries(body);
    if (entries.length === 0)
      return Response.json({ error: "No settings provided" }, { status: 400 });

    for (const [key, value] of entries) {
      await sql`
        INSERT INTO platform_settings (key, value, updated_at)
        VALUES (${key}, ${String(value)}, NOW())
        ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
      `;
    }

    return Response.json({ ok: true });
  } catch (err) {
    console.error("PATCH /api/settings error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
