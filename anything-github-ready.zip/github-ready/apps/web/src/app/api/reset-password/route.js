import sql from "@/app/api/utils/sql";
import argon2 from "argon2";

export async function POST(request) {
  try {
    const { token, password } = await request.json();
    if (!token || !password)
      return Response.json(
        { error: "Token and password are required" },
        { status: 400 },
      );
    if (password.length < 6)
      return Response.json(
        { error: "Password must be at least 6 characters" },
        { status: 400 },
      );

    const tokens = await sql`
      SELECT prt.*, au.id as auth_user_id, au.email
      FROM password_reset_tokens prt
      JOIN auth_users au ON prt.user_id = au.id
      WHERE prt.token = ${token} AND prt.used = false AND prt.expires_at > NOW()
    `;

    if (tokens.length === 0)
      return Response.json(
        { error: "Invalid or expired reset link. Please request a new one." },
        { status: 400 },
      );

    const resetToken = tokens[0];
    const hashedPassword = await argon2.hash(password);

    await sql.transaction([
      sql`UPDATE auth_accounts SET password = ${hashedPassword} WHERE "userId" = ${resetToken.auth_user_id} AND type = 'credentials'`,
      sql`UPDATE password_reset_tokens SET used = true WHERE token = ${token}`,
    ]);

    return Response.json({ ok: true });
  } catch (err) {
    console.error("reset-password error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
