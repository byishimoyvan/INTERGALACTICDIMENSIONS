import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

const OWNER_EMAILS = ["byishimoyvande@gmail.com", "declensen@gmail.com"];

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const rows =
      await sql`SELECT * FROM users_meta WHERE id = ${session.user.id} LIMIT 1`;
    return Response.json({ user: rows?.[0] || null });
  } catch (err) {
    console.error("GET /api/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { username, dob, isContributor } = body || {};

    if (!username || !dob) {
      return Response.json({ error: "Missing fields" }, { status: 400 });
    }

    let role = "user";
    let status = "approved";

    if (OWNER_EMAILS.includes(session.user.email)) {
      role = "owner";
      status = "approved";
    } else if (isContributor) {
      role = "contributor";
      status = "pending";
    }

    const result = await sql`
      INSERT INTO users_meta (id, username, dob, role, status)
      VALUES (${userId}, ${username}, ${dob}, ${role}, ${status})
      ON CONFLICT (id) DO UPDATE SET
        username = EXCLUDED.username,
        dob = EXCLUDED.dob,
        role = CASE 
          WHEN users_meta.role = 'owner' THEN 'owner'
          ELSE EXCLUDED.role
        END,
        status = CASE 
          WHEN users_meta.role = 'owner' THEN 'approved'
          ELSE EXCLUDED.status
        END
      RETURNING *
    `;

    return Response.json({ user: result[0] });
  } catch (err) {
    console.error("POST /api/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }
    const { userId, role, status } = await request.json();
    const result = await sql`
      UPDATE users_meta
      SET role   = COALESCE(${role ?? null}, role),
          status = COALESCE(${status ?? null}, status)
      WHERE id = ${userId}
      RETURNING *
    `;
    return Response.json({ user: result[0] });
  } catch (err) {
    console.error("PATCH /api/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
