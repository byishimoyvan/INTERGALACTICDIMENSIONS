// Resend test mode: can only send to account owner's verified email.
// Once you verify a domain at resend.com, remove OWNER_EMAIL override
// and change FROM_ADDRESS to your domain email.
const RESEND_KEY =
  process.env.RESEND_API_KEY || "re_S13givqH_82k3rmnHC1aAQAMMvngpzwEq";

const OWNER_EMAIL = "byishimoyvande@gmail.com";
const FROM_ADDRESS = "Intergalactic Dimensions <onboarding@resend.dev>";

export async function sendEmail({ to, from, subject, html, text }) {
  // Route all emails to owner (Resend test mode limitation)
  const actualTo = OWNER_EMAIL;
  const intendedFor = Array.isArray(to) ? to.join(", ") : to;
  const prefix =
    intendedFor !== OWNER_EMAIL
      ? `<div style="background:#1a0533;border:1px solid #7C3AED;border-radius:8px;padding:10px 14px;margin-bottom:16px;font-size:12px;color:#A78BFA;font-family:monospace;">📬 For: <strong>${intendedFor}</strong> — routed to owner (test mode)</div>`
      : "";
  const finalHtml = html ? prefix + html : undefined;

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${RESEND_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: from || FROM_ADDRESS,
      to: [actualTo],
      subject,
      html: finalHtml,
      text,
    }),
  });
  const data = await response.json();
  if (!response.ok) {
    throw new Error(data.message || "Failed to send email via Resend");
  }
  return { id: data.id };
}

export async function notifyOwnerPayment({
  username,
  userEmail,
  contentTitle,
  subscriptionPlan,
  amount,
  paymentMethod,
  reference,
}) {
  const isSubscription = !!subscriptionPlan;
  try {
    await sendEmail({
      to: OWNER_EMAIL,
      subject: `💰 New ${isSubscription ? "Subscription" : "Purchase"} — $${amount} via ${paymentMethod.toUpperCase()}`,
      html: `
        <div style="font-family:Arial,sans-serif;max-width:580px;margin:0 auto;background:#0A0A0F;color:#fff;border-radius:16px;overflow:hidden;">
          <div style="background:linear-gradient(135deg,#7C3AED,#4C1D95);padding:28px;text-align:center;">
            <h1 style="margin:0;font-size:26px;font-weight:900;">💰 New ${isSubscription ? "Subscription" : "Purchase"}!</h1>
          </div>
          <div style="padding:28px;">
            <div style="background:rgba(124,58,237,0.12);border:1px solid rgba(124,58,237,0.3);border-radius:12px;padding:20px;text-align:center;margin-bottom:20px;">
              <p style="font-size:40px;font-weight:900;margin:0;color:#4ade80;">$${amount}</p>
              <p style="color:#9ca3af;margin:4px 0 0;font-size:13px;">${paymentMethod.toUpperCase()}</p>
            </div>
            <table style="width:100%;border-collapse:collapse;">
              <tr style="border-bottom:1px solid rgba(255,255,255,0.07);">
                <td style="padding:10px 0;color:#6b7280;font-size:13px;">User</td>
                <td style="padding:10px 0;color:white;font-size:13px;text-align:right;font-weight:700;">${username || userEmail || "Unknown"}</td>
              </tr>
              ${contentTitle ? `<tr style="border-bottom:1px solid rgba(255,255,255,0.07);"><td style="padding:10px 0;color:#6b7280;font-size:13px;">Content</td><td style="padding:10px 0;color:white;font-size:13px;text-align:right;font-weight:700;">${contentTitle}</td></tr>` : ""}
              ${subscriptionPlan ? `<tr style="border-bottom:1px solid rgba(255,255,255,0.07);"><td style="padding:10px 0;color:#6b7280;font-size:13px;">Plan</td><td style="padding:10px 0;color:#A78BFA;font-size:13px;text-align:right;font-weight:700;">${subscriptionPlan}</td></tr>` : ""}
              ${reference ? `<tr><td style="padding:10px 0;color:#6b7280;font-size:13px;">Ref</td><td style="padding:10px 0;color:#4b5563;font-size:11px;text-align:right;font-family:monospace;">${reference}</td></tr>` : ""}
            </table>
            <div style="text-align:center;margin-top:24px;">
              <a href="${process.env.NEXT_PUBLIC_CREATE_APP_URL || ""}/owner" style="background:linear-gradient(135deg,#7C3AED,#6D28D9);color:white;text-decoration:none;padding:13px 26px;border-radius:12px;font-weight:900;font-size:13px;">View Dashboard →</a>
            </div>
          </div>
        </div>`,
    });
  } catch (e) {
    console.error("notifyOwnerPayment error:", e.message);
  }
}
