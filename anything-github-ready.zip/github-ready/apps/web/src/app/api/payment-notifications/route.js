import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function GET(request) {
  try {
    const session = await auth();
    if (!session?.user?.id)
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner")
      return Response.json({ error: "Forbidden" }, { status: 403 });

    const notifications = await sql`
      SELECT * FROM payment_notifications ORDER BY created_at DESC LIMIT 200
    `;
    const total =
      await sql`SELECT COALESCE(SUM(amount),0) as total FROM payment_notifications WHERE status = 'approved'`;
    const unread =
      await sql`SELECT COUNT(*) as cnt FROM payment_notifications WHERE is_read = false`;
    const pending =
      await sql`SELECT COUNT(*) as cnt FROM payment_notifications WHERE status = 'pending'`;

    return Response.json({
      notifications,
      totalRevenue: parseFloat(total[0]?.total || 0),
      unreadCount: parseInt(unread[0]?.cnt || 0),
      pendingCount: parseInt(pending[0]?.cnt || 0),
    });
  } catch (err) {
    console.error("GET /api/payment-notifications error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

// Approve a pending payment → grant access
export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id)
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner")
      return Response.json({ error: "Forbidden" }, { status: 403 });

    const { notificationId } = await request.json();
    if (!notificationId)
      return Response.json(
        { error: "notificationId required" },
        { status: 400 },
      );

    const [notif] =
      await sql`SELECT * FROM payment_notifications WHERE id = ${notificationId} LIMIT 1`;
    if (!notif) return Response.json({ error: "Not found" }, { status: 404 });
    if (notif.status === "approved")
      return Response.json({ ok: true, already: true });

    // Grant access based on type
    if (notif.notify_type === "purchase" && notif.content_id) {
      await sql`
        INSERT INTO purchases (user_id, content_id, amount, stripe_session_id)
        VALUES (${notif.user_id}, ${notif.content_id}, ${notif.amount}, ${notif.payment_reference})
        ON CONFLICT DO NOTHING
      `;
    } else if (notif.notify_type === "subscription") {
      // Determine months from plan label
      const months = notif.subscription_plan?.includes("Year")
        ? 12
        : notif.subscription_plan?.includes("6")
          ? 6
          : notif.subscription_plan?.includes("3")
            ? 3
            : notif.subscription_plan?.includes("2")
              ? 2
              : 1;
      const startsAt = new Date();
      const endsAt = new Date(startsAt);
      endsAt.setMonth(endsAt.getMonth() + months);

      await sql`UPDATE subscriptions SET status = 'expired' WHERE user_id = ${notif.user_id} AND status = 'active'`;
      await sql`
        INSERT INTO subscriptions (user_id, plan, amount, payment_method, payment_reference, starts_at, ends_at, status)
        VALUES (${notif.user_id}, ${notif.subscription_plan || "monthly"}, ${notif.amount}, ${notif.payment_method}, ${notif.payment_reference}, ${startsAt.toISOString()}, ${endsAt.toISOString()}, 'active')
      `;
    }

    // Mark as approved + read
    await sql`UPDATE payment_notifications SET status = 'approved', is_read = true WHERE id = ${notificationId}`;

    return Response.json({ ok: true });
  } catch (err) {
    console.error("POST /api/payment-notifications error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const session = await auth();
    if (!session?.user?.id)
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner")
      return Response.json({ error: "Forbidden" }, { status: 403 });

    await sql`UPDATE payment_notifications SET is_read = true WHERE is_read = false`;
    return Response.json({ ok: true });
  } catch (err) {
    console.error("PATCH /api/payment-notifications error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
