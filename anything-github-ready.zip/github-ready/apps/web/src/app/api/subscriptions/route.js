import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { notifyOwnerPayment } from "@/app/api/utils/send-email";

// Base plan definitions (durations). Prices are overridden by platform_settings.
const BASE_PLANS = {
  monthly: { label: "Monthly", months: 1, defaultPrice: 9.99 },
  "2month": { label: "2 Months", months: 2, defaultPrice: 17.99 },
  quarterly: { label: "3 Months", months: 3, defaultPrice: 24.99 },
  biannual: { label: "6 Months", months: 6, defaultPrice: 44.99 },
  yearly: { label: "1 Year", months: 12, defaultPrice: 79.99 },
};

async function getPlansFromSettings() {
  const rows =
    await sql`SELECT key, value FROM platform_settings WHERE key LIKE 'sub_plan_%'`;
  const s = {};
  for (const r of rows) s[r.key] = r.value;
  const plans = {};
  for (const [id, base] of Object.entries(BASE_PLANS)) {
    plans[id] = {
      ...base,
      label: s[`sub_plan_${id}_label`] || base.label,
      price: parseFloat(s[`sub_plan_${id}_price`] || base.defaultPrice),
    };
  }
  return plans;
}

export async function GET(request) {
  try {
    const session = await auth();

    // Return plans for the subscribe page (public)
    const { searchParams } = new URL(request.url);
    if (searchParams.get("plans") === "1") {
      const plans = await getPlansFromSettings();
      return Response.json({ plans });
    }

    if (!session?.user?.id)
      return Response.json({ active: false, subscription: null });

    const rows = await sql`
      SELECT * FROM subscriptions
      WHERE user_id = ${session.user.id}
        AND status = 'active'
        AND ends_at > NOW()
      ORDER BY ends_at DESC
      LIMIT 1
    `;
    const subscription = rows[0] || null;
    return Response.json({ active: !!subscription, subscription });
  } catch (err) {
    console.error("GET /api/subscriptions error", err);
    return Response.json({ active: false, subscription: null });
  }
}

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id)
      return Response.json({ error: "Unauthorized" }, { status: 401 });

    const { plan, paymentMethod, reference } = await request.json();
    const plans = await getPlansFromSettings();
    const chosen = plans[plan];

    if (!chosen)
      return Response.json({ error: "Invalid plan" }, { status: 400 });
    if (!paymentMethod)
      return Response.json(
        { error: "paymentMethod is required" },
        { status: 400 },
      );

    const startsAt = new Date();
    const endsAt = new Date(startsAt);
    endsAt.setMonth(endsAt.getMonth() + chosen.months);

    await sql`UPDATE subscriptions SET status = 'expired' WHERE user_id = ${session.user.id} AND status = 'active'`;

    const [sub] = await sql`
      INSERT INTO subscriptions (user_id, plan, amount, payment_method, payment_reference, starts_at, ends_at, status)
      VALUES (${session.user.id}, ${plan}, ${chosen.price}, ${paymentMethod}, ${reference || null}, ${startsAt.toISOString()}, ${endsAt.toISOString()}, 'active')
      RETURNING *
    `;

    const [userInfo] = await sql`
      SELECT au.email, um.username FROM auth_users au
      LEFT JOIN users_meta um ON um.id = au.id::text
      WHERE au.id = ${parseInt(session.user.id)} LIMIT 1
    `;

    await sql`
      INSERT INTO payment_notifications (user_id, username, user_email, subscription_plan, amount, payment_method, payment_reference, notify_type, status)
      VALUES (${session.user.id}, ${userInfo?.username || null}, ${userInfo?.email || null}, ${chosen.label}, ${chosen.price}, ${paymentMethod}, ${reference || null}, 'subscription', 'approved')
    `;

    await notifyOwnerPayment({
      username: userInfo?.username,
      userEmail: userInfo?.email,
      subscriptionPlan: chosen.label,
      amount: chosen.price,
      paymentMethod,
      reference,
    });

    return Response.json({ ok: true, subscription: sub });
  } catch (err) {
    console.error("POST /api/subscriptions error", err);
    return Response.json(
      { error: err.message || "Internal Server Error" },
      { status: 500 },
    );
  }
}
