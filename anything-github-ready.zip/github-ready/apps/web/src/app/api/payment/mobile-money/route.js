import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { notifyOwnerPayment } from "@/app/api/utils/send-email";

// MTN and Airtel: MANUAL APPROVAL by owner
// Owner phone numbers:
//   MTN:    0799395838
//   Airtel: 0722461585
// Users send money manually → request appears pending in Payments tab → owner approves → access granted.

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { contentId, subscriptionPlan, phone, provider } =
      await request.json();

    if (!phone || !provider) {
      return Response.json(
        { error: "phone and provider are required" },
        { status: 400 },
      );
    }
    if (!["mtn", "airtel"].includes(provider)) {
      return Response.json(
        { error: "provider must be 'mtn' or 'airtel'" },
        { status: 400 },
      );
    }

    // Get user info
    const [userInfo] = await sql`
      SELECT au.email, um.username FROM auth_users au
      LEFT JOIN users_meta um ON um.id = au.id::text
      WHERE au.id = ${parseInt(session.user.id)} LIMIT 1
    `;

    const externalId = `MANUAL-${provider.toUpperCase()}-${session.user.id}-${Date.now()}`;

    if (contentId) {
      // Per-content payment (manual)
      const contentRows =
        await sql`SELECT * FROM content WHERE id = ${contentId} LIMIT 1`;
      const content = contentRows[0];
      if (!content)
        return Response.json({ error: "Content not found" }, { status: 404 });
      if (content.is_free)
        return Response.json({ error: "Content is free" }, { status: 400 });

      const amount = parseFloat(content.price);

      // Create PENDING notification — owner must approve
      await sql`
        INSERT INTO payment_notifications (user_id, username, user_email, content_id, content_title, amount, payment_method, payment_reference, notify_type, status, is_read)
        VALUES (${session.user.id}, ${userInfo?.username || null}, ${userInfo?.email || null}, ${contentId}, ${content.title}, ${amount}, ${provider}, ${externalId}, 'purchase', 'pending', false)
      `;

      // Notify owner by email
      await notifyOwnerPayment({
        username: userInfo?.username,
        userEmail: userInfo?.email,
        contentTitle: content.title,
        amount,
        paymentMethod: `${provider.toUpperCase()} (MANUAL — PENDING APPROVAL)`,
        reference: `${externalId} · Sender phone: ${phone}`,
      }).catch(() => {});

      return Response.json({
        ok: true,
        pending: true,
        referenceId: externalId,
        provider,
        message: `Payment request submitted. The owner will confirm your payment and grant you access. Reference: ${externalId}`,
      });
    }

    if (subscriptionPlan) {
      // Subscription payment (manual)
      const PLANS = {
        monthly: { label: "Monthly", months: 1, price: 9.99 },
        "2month": { label: "2 Months", months: 2, price: 17.99 },
        quarterly: { label: "3 Months", months: 3, price: 24.99 },
        biannual: { label: "6 Months", months: 6, price: 44.99 },
        yearly: { label: "1 Year", months: 12, price: 79.99 },
      };
      const plan = PLANS[subscriptionPlan];
      if (!plan)
        return Response.json({ error: "Invalid plan" }, { status: 400 });

      // Create PENDING subscription notification
      await sql`
        INSERT INTO payment_notifications (user_id, username, user_email, subscription_plan, amount, payment_method, payment_reference, notify_type, status, is_read)
        VALUES (${session.user.id}, ${userInfo?.username || null}, ${userInfo?.email || null}, ${plan.label}, ${plan.price}, ${provider}, ${externalId}, 'subscription', 'pending', false)
      `;

      await notifyOwnerPayment({
        username: userInfo?.username,
        userEmail: userInfo?.email,
        subscriptionPlan: plan.label,
        amount: plan.price,
        paymentMethod: `${provider.toUpperCase()} (MANUAL — PENDING APPROVAL)`,
        reference: `${externalId} · Sender phone: ${phone}`,
      }).catch(() => {});

      return Response.json({
        ok: true,
        pending: true,
        referenceId: externalId,
        provider,
        message: `Subscription request submitted. The owner will confirm your payment and activate your subscription. Reference: ${externalId}`,
      });
    }

    return Response.json(
      { error: "contentId or subscriptionPlan required" },
      { status: 400 },
    );
  } catch (err) {
    console.error("POST /api/payment/mobile-money error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
