import { auth } from "@/auth";
import sql from "@/app/api/utils/sql";

const RESEND_KEY =
  process.env.RESEND_API_KEY || "re_S13givqH_82k3rmnHC1aAQAMMvngpzwEq";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    const { to, subject, body } = await request.json();
    if (!to || !subject || !body) {
      return Response.json(
        { error: "Missing fields: to, subject, body" },
        { status: 400 },
      );
    }

    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Intergalactic Dimensions <onboarding@resend.dev>",
        to: [to],
        subject,
        text: body,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background: #0A0A0F; color: #ffffff; padding: 32px; border-radius: 12px;">
            <div style="margin-bottom: 24px;">
              <h1 style="color: #A78BFA; font-size: 14px; letter-spacing: 0.3em; margin: 0;">INTERGALACTIC</h1>
              <h1 style="color: #ffffff; font-size: 14px; letter-spacing: 0.3em; margin: 0;">DIMENSIONS</h1>
            </div>
            <hr style="border: 1px solid #1f1f3a; margin-bottom: 24px;" />
            <div style="white-space: pre-wrap; color: #d1d5db; line-height: 1.7; font-size: 14px;">${body.replace(/\n/g, "<br/>")}</div>
            <hr style="border: 1px solid #1f1f3a; margin-top: 24px; margin-bottom: 16px;" />
            <p style="color: #6b7280; font-size: 11px;">Intergalactic Dimensions — Stories from across the multiverse.</p>
          </div>
        `,
      }),
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.message || "Failed to send email");
    }

    return Response.json({ ok: true, id: data.id });
  } catch (err) {
    console.error("POST /api/users/send-email error", err);
    return Response.json(
      { error: err.message || "Internal Server Error" },
      { status: 500 },
    );
  }
}
