import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";
import { sendEmail } from "@/app/api/utils/send-email";

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }
    const users = await sql`
      SELECT um.*, au.email 
      FROM users_meta um
      JOIN auth_users au ON um.id::text = au.id::text
      WHERE um.role != 'owner'
      ORDER BY 
        CASE um.status WHEN 'pending' THEN 0 ELSE 1 END,
        um.username ASC
    `;
    return Response.json({ users });
  } catch (err) {
    console.error("GET /api/users error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function PATCH(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }
    const { id, status, role, allowed_genres, allowed_tags } =
      await request.json();
    if (!id)
      return Response.json({ error: "Missing user id" }, { status: 400 });

    // Fetch user before update so we can email them
    const prevRows = await sql`
      SELECT um.username, um.status, au.email
      FROM users_meta um
      JOIN auth_users au ON um.id::text = au.id::text
      WHERE um.id = ${id} LIMIT 1
    `;
    const prevUser = prevRows[0];

    // Build dynamic update
    const updates = [];
    const values = [];
    let idx = 1;
    if (status !== undefined) {
      updates.push(`status = $${idx++}`);
      values.push(status);
    }
    if (role !== undefined) {
      updates.push(`role = $${idx++}`);
      values.push(role);
    }
    if (allowed_genres !== undefined) {
      updates.push(`allowed_genres = $${idx++}`);
      values.push(allowed_genres);
    }
    if (allowed_tags !== undefined) {
      updates.push(`allowed_tags = $${idx++}`);
      values.push(allowed_tags);
    }

    if (updates.length === 0)
      return Response.json({ error: "Nothing to update" }, { status: 400 });
    values.push(id);
    const result = await sql(
      `UPDATE users_meta SET ${updates.join(", ")} WHERE id = $${idx} RETURNING *`,
      values,
    );

    const siteUrl = process.env.NEXT_PUBLIC_CREATE_APP_URL || "";

    // Send approval email
    if (
      status === "approved" &&
      prevUser?.status === "pending" &&
      prevUser?.email
    ) {
      try {
        await sendEmail({
          to: prevUser.email,
          subject:
            "🎉 You're approved! Start uploading on Intergalactic Dimensions",
          html: `
            <div style="max-width:560px;margin:40px auto;background:#141420;border-radius:20px;border:1px solid rgba(124,58,237,0.3);font-family:Arial,sans-serif;overflow:hidden;">
              <div style="background:linear-gradient(135deg,#1a0533,#0d0d2b);padding:40px 32px;text-align:center;">
                <p style="margin:0 0 4px;font-size:10px;font-weight:700;letter-spacing:0.3em;color:#A78BFA;">INTERGALACTIC</p>
                <p style="margin:0 0 20px;font-size:10px;font-weight:700;letter-spacing:0.3em;color:#fff;">DIMENSIONS</p>
                <h1 style="margin:0;color:#fff;font-size:26px;font-weight:900;">You're Approved! ✦</h1>
              </div>
              <div style="padding:32px;">
                <p style="color:#d1d5db;font-size:15px;line-height:1.6;">Hi <strong style="color:#fff;">${prevUser.username}</strong>,</p>
                <p style="color:#d1d5db;font-size:15px;line-height:1.6;">The owner has <strong style="color:#A78BFA;">approved your contributor request</strong>. You can now upload movies, series, and story books!</p>
                <div style="text-align:center;margin:28px 0;">
                  <a href="${siteUrl}/contribute" style="display:inline-block;background:#7C3AED;color:#fff;font-size:15px;font-weight:700;text-decoration:none;padding:14px 36px;border-radius:12px;">Start Uploading →</a>
                </div>
              </div>
            </div>
          `,
          text: `Hi ${prevUser.username}, your contributor request has been approved! Visit ${siteUrl}/contribute to start uploading.`,
        });
      } catch (emailErr) {
        console.error("Approval email failed (non-fatal):", emailErr.message);
      }
    }

    // Send rejection email
    if (
      status === "rejected" &&
      prevUser?.status === "pending" &&
      prevUser?.email
    ) {
      try {
        await sendEmail({
          to: prevUser.email,
          subject:
            "Update on your Intergalactic Dimensions contributor request",
          html: `
            <div style="max-width:560px;margin:40px auto;background:#141420;border-radius:20px;border:1px solid rgba(239,68,68,0.2);font-family:Arial,sans-serif;overflow:hidden;">
              <div style="background:linear-gradient(135deg,#1a0533,#0d0d2b);padding:40px 32px;text-align:center;">
                <p style="margin:0 0 4px;font-size:10px;font-weight:700;letter-spacing:0.3em;color:#A78BFA;">INTERGALACTIC</p>
                <p style="margin:0 0 20px;font-size:10px;font-weight:700;letter-spacing:0.3em;color:#fff;">DIMENSIONS</p>
                <h1 style="margin:0;color:#fff;font-size:22px;font-weight:900;">Contributor Application Update</h1>
              </div>
              <div style="padding:32px;">
                <p style="color:#d1d5db;font-size:15px;line-height:1.6;">Hi <strong style="color:#fff;">${prevUser.username}</strong>,</p>
                <p style="color:#d1d5db;font-size:15px;line-height:1.6;">Thank you for applying to be a contributor on <strong style="color:#A78BFA;">Intergalactic Dimensions</strong>. After review, we are unable to approve your request at this time.</p>
                <p style="color:#d1d5db;font-size:15px;line-height:1.6;">You can still browse and enjoy all our content as a viewer. We may open applications again in the future.</p>
                <div style="text-align:center;margin:28px 0;">
                  <a href="${siteUrl}" style="display:inline-block;background:rgba(124,58,237,0.2);color:#A78BFA;border:1px solid rgba(124,58,237,0.4);font-size:15px;font-weight:700;text-decoration:none;padding:14px 36px;border-radius:12px;">Browse Content →</a>
                </div>
              </div>
              <div style="background:#080810;padding:16px;text-align:center;border-top:1px solid rgba(255,255,255,0.05);">
                <p style="color:#4b5563;font-size:11px;margin:0;">© 2026 Intergalactic Dimensions.</p>
              </div>
            </div>
          `,
          text: `Hi ${prevUser.username}, your contributor application was not approved at this time. You can still browse content at ${siteUrl}.`,
        });
      } catch (emailErr) {
        console.error("Rejection email failed (non-fatal):", emailErr.message);
      }
    }

    return Response.json({ user: result[0] });
  } catch (err) {
    console.error("PATCH /api/users error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }
    const ownerCheck =
      await sql`SELECT role FROM users_meta WHERE id = ${session.user.id}`;
    if (ownerCheck[0]?.role !== "owner") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }
    const { id } = await request.json();
    if (!id)
      return Response.json({ error: "Missing user id" }, { status: 400 });

    // Reset to regular user instead of full delete (preserve their account)
    await sql`
      UPDATE users_meta SET role = 'user', status = 'approved', allowed_genres = NULL, allowed_tags = NULL
      WHERE id = ${id}
    `;
    return Response.json({ ok: true });
  } catch (err) {
    console.error("DELETE /api/users error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
