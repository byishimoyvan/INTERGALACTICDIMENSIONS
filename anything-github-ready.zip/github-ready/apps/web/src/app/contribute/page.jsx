"use client";
import { useState, useEffect, useRef } from "react";
import useUser from "@/utils/useUser";
import { useUpload } from "@/utils/useUpload";
import {
  Upload,
  Film,
  BookOpen,
  ArrowLeft,
  Image as ImageIcon,
  CheckCircle,
  Lock,
  AlertCircle,
  Tv,
} from "lucide-react";

const LOGO_URL =
  "https://raw.createusercontent.com/83c42dc4-4b43-4e42-aded-b337415f50ea/";

function ProgressBar({ label, active, done }) {
  const [fakeProgress, setFakeProgress] = useState(0);
  const intervalRef = useRef(null);

  useEffect(() => {
    if (active) {
      setFakeProgress(5);
      intervalRef.current = setInterval(() => {
        setFakeProgress((p) => {
          if (p >= 90) {
            clearInterval(intervalRef.current);
            return 90;
          }
          return p + Math.random() * 8;
        });
      }, 400);
    } else if (done) {
      clearInterval(intervalRef.current);
      setFakeProgress(100);
    } else {
      clearInterval(intervalRef.current);
      setFakeProgress(0);
    }
    return () => clearInterval(intervalRef.current);
  }, [active, done]);

  if (!active && !done) return null;

  return (
    <div className="absolute inset-0 bg-black/85 flex flex-col items-center justify-center gap-3 p-5 z-10">
      <div className="w-full">
        <div className="flex justify-between text-xs text-white mb-2">
          <span>{done ? "Upload complete!" : label}</span>
          <span className="font-black text-[#A78BFA]">
            {Math.round(fakeProgress)}%
          </span>
        </div>
        <div className="w-full bg-white/20 rounded-full h-2.5">
          <div
            className="h-2.5 rounded-full transition-all duration-500"
            style={{
              width: `${fakeProgress}%`,
              background: done
                ? "#22c55e"
                : "linear-gradient(90deg, #7C3AED, #A78BFA)",
            }}
          />
        </div>
        {!done && (
          <p className="text-[10px] text-gray-400 mt-2 text-center">
            Please wait — do not close this page
          </p>
        )}
      </div>
    </div>
  );
}

export default function ContributePage() {
  const { data: user, loading: userLoading } = useUser();
  const [profile, setProfile] = useState(null);
  const [genres, setGenres] = useState([]);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState(null);

  const [uploadFile, { loading: uploadingFile }] = useUpload();
  const [uploadPoster, { loading: uploadingPoster }] = useUpload();

  const [posterDone, setPosterDone] = useState(false);
  const [fileDone, setFileDone] = useState(false);

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    type: "movie",
    genreId: "",
    fileUrl: "",
    posterUrl: "",
    price: 0,
    isFree: true,
    isPrivate: false,
  });

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchGenres();
    }
  }, [user]);

  const fetchProfile = async () => {
    try {
      const res = await fetch("/api/profile");
      if (!res.ok) {
        if (typeof window !== "undefined") window.location.href = "/";
        return;
      }
      const data = await res.json();
      const u = data.user;
      const canUpload =
        u?.role === "owner" ||
        (u?.role === "contributor" && u?.status === "approved");
      if (!canUpload) {
        if (typeof window !== "undefined") window.location.href = "/";
        return;
      }
      setProfile(u);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchGenres = async () => {
    try {
      const res = await fetch("/api/genres");
      const data = await res.json();
      setGenres(data.genres || []);
      if (data.genres?.length > 0) {
        setFormData((prev) => ({ ...prev, genreId: data.genres[0].id }));
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleFileUpload = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    setError(null);

    if (type === "poster") {
      setPosterDone(false);
      const result = await uploadPoster({ file });
      if (result?.error) {
        setError(`Poster upload failed: ${result.error}`);
        return;
      }
      if (result?.url) {
        setFormData((prev) => ({ ...prev, posterUrl: result.url }));
        setPosterDone(true);
      }
    } else {
      setFileDone(false);
      const result = await uploadFile({ file });
      if (result?.error) {
        setError(`File upload failed: ${result.error}`);
        return;
      }
      if (result?.url) {
        setFormData((prev) => ({ ...prev, fileUrl: result.url }));
        setFileDone(true);
      }
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.fileUrl) {
      setError("Please upload your content file first.");
      return;
    }
    if (!formData.genreId) {
      setError("Please select a genre.");
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (!res.ok)
        throw new Error(data.error || `Server error (${res.status})`);
      setSuccess(true);
      setFileDone(false);
      setPosterDone(false);
      setFormData({
        title: "",
        description: "",
        type: "movie",
        genreId: genres[0]?.id || "",
        fileUrl: "",
        posterUrl: "",
        price: 0,
        isFree: true,
        isPrivate: false,
      });
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (userLoading) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div
          className="h-8 w-8 rounded-full border-2 border-[#7C3AED] border-t-transparent"
          style={{ animation: "spin 1s linear infinite" }}
        />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div className="text-center text-white">
          <p className="mb-4 text-gray-400">
            You need to sign in to upload content.
          </p>
          <a
            href="/account/signin"
            className="bg-[#7C3AED] text-white px-6 py-2 rounded-lg font-semibold"
          >
            Sign In
          </a>
        </div>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white font-inter">
      <nav className="border-b border-white/5 px-4 sm:px-8 py-4 flex items-center justify-between">
        <a href="/" className="flex items-center gap-3">
          <img
            src={LOGO_URL}
            alt="Intergalactic Dimensions"
            className="h-9 w-auto object-contain"
          />
          <div className="hidden sm:block">
            <div className="text-[10px] font-bold tracking-[0.2em] text-[#A78BFA]">
              INTERGALACTIC
            </div>
            <div className="text-[10px] font-bold tracking-[0.2em] text-white">
              DIMENSIONS
            </div>
          </div>
        </a>
        <a
          href="/"
          className="flex items-center gap-1.5 text-gray-400 hover:text-white text-sm transition-colors"
        >
          <ArrowLeft size={15} /> Back to Browse
        </a>
      </nav>

      <div className="max-w-3xl mx-auto px-4 sm:px-8 py-12">
        <div className="mb-10">
          <h1 className="text-3xl font-black mb-2">Upload Your Creation</h1>
          <p className="text-gray-400">
            Share your movies, series, or storybooks with the multiverse.
          </p>
          {profile?.role === "contributor" && (
            <div className="mt-3 rounded-xl bg-[#A78BFA]/10 border border-[#A78BFA]/20 px-4 py-3 text-xs text-[#A78BFA]">
              ✦ As a contributor, your uploads go to the owner for review before
              going live.
            </div>
          )}
        </div>

        {success ? (
          <div className="rounded-2xl border border-green-500/20 bg-green-500/10 p-10 text-center">
            <CheckCircle size={48} className="text-green-400 mx-auto mb-4" />
            <h2 className="text-xl font-bold text-white mb-2">
              Upload Submitted!
            </h2>
            <p className="text-gray-400 mb-6">
              {profile?.role === "owner"
                ? "Your content is live on the platform."
                : "Submitted for owner review. You can still browse all content while waiting."}
            </p>
            <div className="flex gap-3 justify-center">
              <button
                onClick={() => setSuccess(false)}
                className="bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-lg px-6 py-2.5 font-semibold transition-colors"
              >
                Upload Another
              </button>
              <a
                href="/"
                className="border border-white/10 text-gray-300 hover:text-white rounded-lg px-6 py-2.5 font-semibold transition-colors"
              >
                Browse Content
              </a>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="rounded-xl bg-red-500/10 border border-red-500/20 px-4 py-3 text-sm text-red-400 flex items-start gap-2">
                <AlertCircle size={16} className="flex-shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            {/* Content Details */}
            <div className="rounded-2xl border border-white/10 bg-[#141420] p-6 space-y-5">
              <h2 className="text-sm font-bold text-[#A78BFA] uppercase tracking-widest">
                Content Details
              </h2>

              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    Title *
                  </label>
                  <input
                    required
                    type="text"
                    value={formData.title}
                    onChange={(e) =>
                      setFormData({ ...formData, title: e.target.value })
                    }
                    placeholder="Journey Beyond the Rift..."
                    className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    Type *
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { val: "movie", icon: Film, label: "Movie" },
                      { val: "series", icon: Tv, label: "Series" },
                      { val: "storybook", icon: BookOpen, label: "Book" },
                    ].map(({ val, icon: Icon, label }) => (
                      <button
                        key={val}
                        type="button"
                        onClick={() => setFormData({ ...formData, type: val })}
                        className={`flex flex-col items-center gap-1 rounded-xl border py-2.5 text-xs font-semibold transition-all ${formData.type === val ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"}`}
                      >
                        <Icon size={15} />
                        {label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Genre *
                </label>
                <div className="flex flex-wrap gap-2">
                  {genres.map((g) => (
                    <button
                      key={g.id}
                      type="button"
                      onClick={() =>
                        setFormData({ ...formData, genreId: g.id })
                      }
                      className={`rounded-full px-4 py-1.5 text-xs font-semibold border transition-colors ${formData.genreId === g.id ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED] hover:text-white"}`}
                    >
                      {g.name}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Description *
                </label>
                <textarea
                  required
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                  rows={4}
                  placeholder="Tell viewers what this is about..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors resize-none"
                />
              </div>
            </div>

            {/* Pricing */}
            <div className="rounded-2xl border border-white/10 bg-[#141420] p-6 space-y-5">
              <h2 className="text-sm font-bold text-[#A78BFA] uppercase tracking-widest">
                Access
              </h2>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() =>
                    setFormData({ ...formData, isFree: true, price: 0 })
                  }
                  className={`rounded-xl border p-4 text-left transition-all ${formData.isFree ? "border-green-500 bg-green-500/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
                >
                  <div className="text-green-400 font-bold mb-1">FREE</div>
                  <p className="text-xs text-gray-400">
                    Anyone can watch after signing in
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setFormData({
                      ...formData,
                      isFree: false,
                      price: 9.99,
                    })
                  }
                  className={`rounded-xl border p-4 text-left transition-all ${!formData.isFree ? "border-[#FBBF24] bg-[#FBBF24]/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
                >
                  <div className="text-[#FBBF24] font-bold mb-1">PAID</div>
                  <p className="text-xs text-gray-400">
                    Viewers pay via subscription or purchase
                  </p>
                </button>
              </div>
              {/* No price input — pricing is managed by the platform subscription system */}
              {profile?.role === "owner" && (
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      setFormData({
                        ...formData,
                        isPrivate: !formData.isPrivate,
                      })
                    }
                    className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${formData.isPrivate ? "bg-[#7C3AED]" : "bg-white/10"}`}
                  >
                    <div
                      className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${formData.isPrivate ? "translate-x-5" : "translate-x-0.5"}`}
                    />
                  </button>
                  <div>
                    <div className="text-sm font-semibold flex items-center gap-1.5">
                      <Lock size={13} className="text-gray-400" /> Private
                      (Owner Only)
                    </div>
                    <p className="text-xs text-gray-500">Only visible to you</p>
                  </div>
                </div>
              )}
            </div>

            {/* File Uploads */}
            <div className="rounded-2xl border border-white/10 bg-[#141420] p-6 space-y-5">
              <h2 className="text-sm font-bold text-[#A78BFA] uppercase tracking-widest">
                Upload Files
              </h2>
              <p className="text-xs text-gray-500 -mt-2">
                Large video files are supported. Do not close the page while
                uploading.
              </p>
              <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                {/* Poster */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    Poster Image
                  </label>
                  <div className="relative group">
                    <div className="aspect-[2/3] rounded-xl border-2 border-dashed border-white/10 group-hover:border-[#7C3AED]/50 bg-white/5 overflow-hidden flex flex-col items-center justify-center transition-all">
                      {formData.posterUrl ? (
                        <img
                          src={formData.posterUrl}
                          alt="Poster"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-center p-4">
                          <ImageIcon
                            size={32}
                            className="text-gray-600 mx-auto mb-2"
                          />
                          <p className="text-xs text-gray-500">
                            Click to upload poster
                          </p>
                          <p className="text-[10px] text-gray-600 mt-1">
                            JPG, PNG, WEBP
                          </p>
                        </div>
                      )}
                      <ProgressBar
                        label="Uploading poster..."
                        active={uploadingPoster}
                        done={posterDone && !uploadingPoster}
                      />
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload(e, "poster")}
                      disabled={uploadingPoster || uploadingFile}
                      className="absolute inset-0 cursor-pointer opacity-0 disabled:cursor-not-allowed"
                    />
                  </div>
                  {formData.posterUrl && !uploadingPoster && (
                    <p className="text-[10px] text-green-400 flex items-center gap-1">
                      <CheckCircle size={10} /> Poster uploaded
                    </p>
                  )}
                </div>

                {/* Main Content File */}
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    Main File *{" "}
                    {formData.type === "storybook" ? "(PDF)" : "(Video)"}
                  </label>
                  <div className="relative group">
                    <div className="aspect-[2/3] rounded-xl border-2 border-dashed border-white/10 group-hover:border-[#7C3AED]/50 bg-white/5 overflow-hidden flex flex-col items-center justify-center transition-all">
                      {formData.fileUrl ? (
                        <div className="text-center p-4">
                          {formData.type === "storybook" ? (
                            <BookOpen
                              size={40}
                              className="text-[#7C3AED] mx-auto mb-2"
                            />
                          ) : (
                            <Film
                              size={40}
                              className="text-[#7C3AED] mx-auto mb-2"
                            />
                          )}
                          <p className="text-xs text-green-400 font-semibold">
                            File uploaded!
                          </p>
                        </div>
                      ) : (
                        <div className="text-center p-4">
                          <Upload
                            size={32}
                            className="text-gray-600 mx-auto mb-2"
                          />
                          <p className="text-xs text-gray-500">
                            Click to upload
                          </p>
                          <p className="text-[10px] text-gray-600 mt-1">
                            {formData.type === "storybook"
                              ? "PDF"
                              : "MP4, MOV, AVI · any size"}
                          </p>
                        </div>
                      )}
                      <ProgressBar
                        label="Uploading video..."
                        active={uploadingFile}
                        done={fileDone && !uploadingFile}
                      />
                    </div>
                    <input
                      type="file"
                      accept={
                        formData.type === "storybook"
                          ? ".pdf"
                          : "video/*,.mp4,.mov,.avi"
                      }
                      onChange={(e) => handleFileUpload(e, "content")}
                      disabled={uploadingFile || uploadingPoster}
                      className="absolute inset-0 cursor-pointer opacity-0 disabled:cursor-not-allowed"
                    />
                  </div>
                  {formData.fileUrl && !uploadingFile && (
                    <p className="text-[10px] text-green-400 flex items-center gap-1">
                      <CheckCircle size={10} /> Content file uploaded
                    </p>
                  )}
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={
                loading ||
                uploadingFile ||
                uploadingPoster ||
                !formData.fileUrl ||
                !formData.genreId
              }
              className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl py-4 text-sm font-bold transition-colors flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div
                    className="h-4 w-4 rounded-full border-2 border-white border-t-transparent"
                    style={{ animation: "spin 1s linear infinite" }}
                  />{" "}
                  Publishing...
                </>
              ) : (
                <>
                  <Upload size={16} />{" "}
                  {profile?.role === "owner"
                    ? "Publish Content"
                    : "Submit for Review"}
                </>
              )}
            </button>
            {!formData.fileUrl && !uploadingFile && (
              <p className="text-center text-xs text-gray-600">
                Upload your content file first to enable submission
              </p>
            )}
          </form>
        )}
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
