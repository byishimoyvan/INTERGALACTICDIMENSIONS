"use client";
import useUser from "@/utils/useUser";
import { useUpload } from "@/utils/useUpload";
import { Film, Upload, Users, Settings, DollarSign } from "lucide-react";
import { Navigation } from "@/components/OwnerDashboard/Navigation";
import { DashboardHeader } from "@/components/OwnerDashboard/DashboardHeader";
import { StatsRow } from "@/components/OwnerDashboard/StatsRow";
import { TabNavigation } from "@/components/OwnerDashboard/TabNavigation";
import { ContentApprovalTab } from "@/components/OwnerDashboard/ContentApprovalTab";
import { ContributorsTab } from "@/components/OwnerDashboard/ContributorsTab";
import { OwnerUploadTab } from "@/components/OwnerDashboard/OwnerUploadTab";
import { SettingsTab } from "@/components/OwnerDashboard/SettingsTab";
import { PaymentsTab } from "@/components/OwnerDashboard/PaymentsTab";
import { useOwnerDashboard } from "@/hooks/useOwnerDashboard";

export default function OwnerDashboard() {
  const { data: user, loading: userLoading } = useUser();
  const {
    profile,
    contentRequests,
    contributorRequests,
    genres,
    newGenre,
    setNewGenre,
    loading,
    activeTab,
    setActiveTab,
    actionLoading,
    formData,
    setFormData,
    uploadLoading,
    uploadSuccess,
    setUploadSuccess,
    uploadError,
    setUploadError,
    contribForm,
    setContribForm,
    contribUploadLoading,
    contribSuccess,
    setContribSuccess,
    contribError,
    handleContentAction,
    handleUserAction,
    handleAddGenre,
    handleOwnerSubmit,
    handleContribSubmit,
    emailCompose,
    setEmailCompose,
    emailSending,
    emailSuccess,
    setEmailSuccess,
    openEmailCompose,
    sendEmail,
    editingItem,
    setEditingItem,
    editSaving,
    deleteContent,
    toggleVisibility,
    startEdit,
    cancelEdit,
    saveEdit,
    removeContributor,
    updateContributorPermissions,
    settings,
    settingsLoading,
    savingKeys,
    saveSetting,
    handleDeleteGenre,
    handleBulkContentAction,
  } = useOwnerDashboard(user);

  const [uploadFile, { loading: uploadingFile }] = useUpload();
  const [uploadPoster, { loading: uploadingPoster }] = useUpload();
  const [uploadTrailer, { loading: uploadingTrailer }] = useUpload();
  const [uploadContribFile, { loading: uploadingContribFile }] = useUpload();
  const [uploadContribPoster, { loading: uploadingContribPoster }] =
    useUpload();

  // Owner file upload handlers
  const handleOwnerFile = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadError(null);
    let result;
    if (type === "poster") result = await uploadPoster({ file });
    else if (type === "trailer") result = await uploadTrailer({ file });
    else result = await uploadFile({ file });
    if (result.error) {
      setUploadError("Upload failed. Please try again.");
      return;
    }
    if (result.url) {
      setFormData((prev) => ({
        ...prev,
        [type === "poster"
          ? "posterUrl"
          : type === "trailer"
            ? "trailerUrl"
            : "fileUrl"]: result.url,
      }));
    }
  };

  // Contributor file upload handlers
  const handleContribFile = async (e, type) => {
    const file = e.target.files[0];
    if (!file) return;
    const uploader =
      type === "poster" ? uploadContribPoster : uploadContribFile;
    const result = await uploader({ file });
    if (result.error) {
      return;
    }
    if (result.url) {
      setContribForm((prev) => ({
        ...prev,
        [type === "poster" ? "posterUrl" : "fileUrl"]: result.url,
      }));
    }
  };

  if (userLoading || !profile) {
    return (
      <div className="min-h-screen bg-[#0A0A0F] flex items-center justify-center">
        <div
          className="h-8 w-8 rounded-full border-2 border-[#7C3AED] border-t-transparent"
          style={{ animation: "spin 1s linear infinite" }}
        />
      </div>
    );
  }

  const pendingContribs = contributorRequests.filter(
    (u) => u.status === "pending",
  ).length;
  const pendingContent = contentRequests.filter(
    (c) => c.status === "pending",
  ).length;

  const tabs = [
    {
      id: "content",
      label: "Content Approval",
      icon: Film,
      badge: pendingContent,
    },
    {
      id: "contributors",
      label: "Contributors",
      icon: Users,
      badge: pendingContribs,
    },
    { id: "upload", label: "Upload Content", icon: Upload, badge: 0 },
    { id: "paid", label: "Payments", icon: DollarSign, badge: 0 },
    { id: "settings", label: "Settings", icon: Settings, badge: 0 },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white font-inter">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-8 py-10">
        <DashboardHeader username={profile.username} />

        <StatsRow
          contentRequests={contentRequests}
          contributorRequests={contributorRequests}
          genres={genres}
        />

        <TabNavigation
          tabs={tabs}
          activeTab={activeTab}
          setActiveTab={setActiveTab}
        />

        {activeTab === "content" && (
          <ContentApprovalTab
            loading={loading}
            contentRequests={contentRequests}
            actionLoading={actionLoading}
            handleContentAction={handleContentAction}
            deleteContent={deleteContent}
            toggleVisibility={toggleVisibility}
            startEdit={startEdit}
            cancelEdit={cancelEdit}
            saveEdit={saveEdit}
            editingItem={editingItem}
            setEditingItem={setEditingItem}
            editSaving={editSaving}
            genres={genres}
          />
        )}

        {activeTab === "contributors" && (
          <ContributorsTab
            loading={loading}
            contributorRequests={contributorRequests}
            actionLoading={actionLoading}
            handleUserAction={handleUserAction}
            contribForm={contribForm}
            setContribForm={setContribForm}
            contribSuccess={contribSuccess}
            setContribSuccess={setContribSuccess}
            contribError={contribError}
            contribUploadLoading={contribUploadLoading}
            uploadingContribFile={uploadingContribFile}
            uploadingContribPoster={uploadingContribPoster}
            handleContribFile={handleContribFile}
            handleContribSubmit={handleContribSubmit}
            genres={genres}
            emailCompose={emailCompose}
            setEmailCompose={setEmailCompose}
            emailSending={emailSending}
            emailSuccess={emailSuccess}
            setEmailSuccess={setEmailSuccess}
            openEmailCompose={openEmailCompose}
            sendEmail={sendEmail}
            onRemove={removeContributor}
            onSavePermissions={updateContributorPermissions}
          />
        )}

        {activeTab === "upload" && (
          <div>
            <div className="mb-6 flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl bg-[#7C3AED] flex items-center justify-center">
                <Upload size={17} />
              </div>
              <div>
                <h2 className="text-lg font-black">Owner Upload</h2>
                <p className="text-xs text-gray-400">
                  Your uploads are published instantly to the platform.
                </p>
              </div>
            </div>

            <OwnerUploadTab
              uploadSuccess={uploadSuccess}
              setUploadSuccess={setUploadSuccess}
              uploadError={uploadError}
              formData={formData}
              setFormData={setFormData}
              genres={genres}
              uploadLoading={uploadLoading}
              uploadingFile={uploadingFile}
              uploadingPoster={uploadingPoster}
              uploadingTrailer={uploadingTrailer}
              handleOwnerFile={handleOwnerFile}
              handleOwnerSubmit={handleOwnerSubmit}
            />
          </div>
        )}

        {activeTab === "paid" && (
          <div>
            <div className="mb-6 flex items-center gap-3">
              <div className="h-9 w-9 rounded-xl bg-green-600 flex items-center justify-center">
                <DollarSign size={17} />
              </div>
              <div>
                <h2 className="text-lg font-black">Payments & Revenue</h2>
                <p className="text-xs text-gray-400">
                  All purchases and subscriptions received.
                </p>
              </div>
            </div>
            <PaymentsTab />
          </div>
        )}

        {activeTab === "settings" && (
          <SettingsTab
            genres={genres}
            newGenre={newGenre}
            setNewGenre={setNewGenre}
            handleAddGenre={handleAddGenre}
            handleDeleteGenre={handleDeleteGenre}
            profile={profile}
            settings={settings}
            saveSetting={saveSetting}
            savingKeys={savingKeys}
            settingsLoading={settingsLoading}
            contentRequests={contentRequests}
            contributorRequests={contributorRequests}
            handleBulkContentAction={handleBulkContentAction}
          />
        )}
      </div>

      <style>{`
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
}
