"use client";
import { useState, useEffect } from "react";
import {
  Plus,
  Shield,
  Trash2,
  Save,
  Globe,
  Users,
  Film,
  Mail,
  Bell,
  Lock,
  Palette,
  AlertTriangle,
  CheckCircle,
  ToggleLeft,
  ToggleRight,
  Tag,
  BookOpen,
  DollarSign,
  Eye,
  Star,
  Megaphone,
  Wrench,
  BarChart2,
  ChevronDown,
  ChevronUp,
  X,
  RefreshCw,
} from "lucide-react";

function Toggle({ value, onChange, label, description, disabled }) {
  const on = value === "true" || value === true;
  return (
    <div className="flex items-start justify-between gap-4 py-3">
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold text-white">{label}</p>
        {description && (
          <p className="text-xs text-gray-500 mt-0.5 leading-relaxed">
            {description}
          </p>
        )}
      </div>
      <button
        onClick={() => !disabled && onChange(!on ? "true" : "false")}
        disabled={disabled}
        className={`flex-shrink-0 w-11 h-6 rounded-full transition-all duration-300 relative ${on ? "bg-[#7C3AED]" : "bg-white/10"} ${disabled ? "opacity-40 cursor-not-allowed" : "cursor-pointer"}`}
      >
        <span
          className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white transition-transform duration-300 shadow ${on ? "translate-x-5" : "translate-x-0"}`}
        />
      </button>
    </div>
  );
}

function Section({
  icon: Icon,
  title,
  color = "#7C3AED",
  children,
  defaultOpen = false,
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="rounded-2xl border border-white/5 bg-[#141420] overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between p-5 hover:bg-white/3 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div
            className="h-9 w-9 rounded-xl flex items-center justify-center"
            style={{ background: `${color}22` }}
          >
            <Icon size={16} style={{ color }} />
          </div>
          <span className="text-sm font-bold text-white">{title}</span>
        </div>
        {open ? (
          <ChevronUp size={16} className="text-gray-500" />
        ) : (
          <ChevronDown size={16} className="text-gray-500" />
        )}
      </button>
      {open && <div className="border-t border-white/5 p-5">{children}</div>}
    </div>
  );
}

function TextInput({
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  hint,
}) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
        {label}
      </label>
      <input
        type={type}
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
      />
      {hint && <p className="text-[11px] text-gray-600">{hint}</p>}
    </div>
  );
}

function TextArea({ label, value, onChange, placeholder, rows = 3, hint }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
        {label}
      </label>
      <textarea
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors resize-none"
      />
      {hint && <p className="text-[11px] text-gray-600">{hint}</p>}
    </div>
  );
}

function SelectInput({ label, value, onChange, options, hint }) {
  return (
    <div className="space-y-1.5">
      <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
        {label}
      </label>
      <select
        value={value || ""}
        onChange={(e) => onChange(e.target.value)}
        className="w-full bg-[#1e1e2e] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      {hint && <p className="text-[11px] text-gray-600">{hint}</p>}
    </div>
  );
}

export function SettingsTab({
  genres,
  newGenre,
  setNewGenre,
  handleAddGenre,
  handleDeleteGenre,
  profile,
  settings,
  saveSetting,
  savingKeys,
  settingsLoading,
  contentRequests,
  contributorRequests,
  handleBulkContentAction,
}) {
  const [saved, setSaved] = useState({});

  const set = (key) => (value) => {
    saveSetting(key, value);
    setSaved((p) => ({ ...p, [key]: true }));
    setTimeout(() => setSaved((p) => ({ ...p, [key]: false })), 2000);
  };

  const s = settings || {};

  // Stats
  const totalContent = (contentRequests || []).length;
  const approvedContent = (contentRequests || []).filter(
    (c) => c.status === "approved",
  ).length;
  const pendingContent = (contentRequests || []).filter(
    (c) => c.status === "pending",
  ).length;
  const rejectedContent = (contentRequests || []).filter(
    (c) => c.status === "rejected",
  ).length;
  const totalContributors = (contributorRequests || []).filter(
    (u) => u.status === "approved",
  ).length;
  const pendingContributors = (contributorRequests || []).filter(
    (u) => u.status === "pending",
  ).length;

  if (settingsLoading) {
    return (
      <div className="flex items-center justify-center h-40">
        <div
          className="h-8 w-8 rounded-full border-2 border-[#7C3AED] border-t-transparent"
          style={{ animation: "spin 1s linear infinite" }}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* ── PLATFORM STATS (always visible) ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-2">
        {[
          { label: "Total Content", value: totalContent, color: "#7C3AED" },
          { label: "Live", value: approvedContent, color: "#22c55e" },
          { label: "Pending", value: pendingContent, color: "#FBBF24" },
          { label: "Rejected", value: rejectedContent, color: "#ef4444" },
          { label: "Contributors", value: totalContributors, color: "#06b6d4" },
          { label: "Genres", value: genres.length, color: "#A78BFA" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-2xl border border-white/5 bg-[#141420] p-4 text-center"
          >
            <p className="text-2xl font-black" style={{ color: stat.color }}>
              {stat.value}
            </p>
            <p className="text-[10px] text-gray-500 mt-1 font-semibold uppercase tracking-wider">
              {stat.label}
            </p>
          </div>
        ))}
      </div>

      {/* ── 1. PLATFORM IDENTITY ── */}
      <Section
        icon={Globe}
        title="Platform Identity"
        color="#7C3AED"
        defaultOpen={true}
      >
        <div className="space-y-4">
          <TextInput
            label="Site Name"
            value={s.site_name}
            onChange={set("site_name")}
            placeholder="Intergalactic Dimensions"
            hint="Shown in the navbar and emails."
          />
          <TextInput
            label="Site Tagline"
            value={s.site_tagline}
            onChange={set("site_tagline")}
            placeholder="Stories from across the multiverse."
            hint="Shown on the homepage when there's no content."
          />
          <div className="pt-2 border-t border-white/5">
            <Toggle
              label="Announcement Banner"
              description="Show a top banner to all visitors."
              value={s.announcement_banner_enabled}
              onChange={set("announcement_banner_enabled")}
            />
            {s.announcement_banner_enabled === "true" && (
              <TextInput
                label="Banner Text"
                value={s.announcement_banner}
                onChange={set("announcement_banner")}
                placeholder="e.g. New season of Galaxy Chronicles is out now! 🚀"
              />
            )}
          </div>
          <div className="pt-2 border-t border-white/5">
            <Toggle
              label="Maintenance Mode"
              description="Blocks all visitors with a maintenance screen. You (owner) can still access everything."
              value={s.maintenance_mode}
              onChange={set("maintenance_mode")}
            />
            {s.maintenance_mode === "true" && (
              <TextArea
                label="Maintenance Message"
                value={s.maintenance_message}
                onChange={set("maintenance_message")}
                placeholder="We're upgrading the multiverse. Back soon!"
                rows={2}
              />
            )}
          </div>
        </div>
      </Section>

      {/* ── 2. GENRES ── */}
      <Section icon={Tag} title="Genres" color="#A78BFA">
        <div className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {genres.map((genre) => (
              <div
                key={genre.id}
                className="flex items-center gap-2 rounded-full border border-white/10 bg-white/5 pl-3 pr-2 py-1.5"
              >
                <span className="text-xs text-gray-300 font-medium">
                  {genre.name}
                </span>
                {handleDeleteGenre && (
                  <button
                    onClick={() => handleDeleteGenre(genre.id, genre.name)}
                    className="h-4 w-4 rounded-full bg-red-500/20 text-red-400 hover:bg-red-500/30 flex items-center justify-center transition-colors"
                  >
                    <X size={9} />
                  </button>
                )}
              </div>
            ))}
            {genres.length === 0 && (
              <p className="text-xs text-gray-600">
                No genres yet. Add one below.
              </p>
            )}
          </div>
          <div className="flex gap-3">
            <input
              type="text"
              value={newGenre}
              onChange={(e) => setNewGenre(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleAddGenre()}
              placeholder="Add new genre... e.g. Anime"
              className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
            />
            <button
              onClick={handleAddGenre}
              className="bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl px-5 py-2 text-sm font-semibold transition-colors flex items-center gap-1.5"
            >
              <Plus size={14} /> Add
            </button>
          </div>
        </div>
      </Section>

      {/* ── 3. CONTENT RULES ── */}
      <Section icon={Film} title="Content Rules" color="#06b6d4">
        <div className="space-y-1 divide-y divide-white/5">
          <Toggle
            label="Allow Contributor Requests"
            description="When ON, users can apply to become contributors during signup."
            value={s.allow_contributor_requests}
            onChange={set("allow_contributor_requests")}
          />
          <Toggle
            label="Auto-Approve Contributor Uploads"
            description="Skip review — contributor uploads go live instantly. Use with trusted contributors only."
            value={s.auto_approve_contributor_uploads}
            onChange={set("auto_approve_contributor_uploads")}
          />
          <Toggle
            label="Require Poster Image"
            description="Contributors must provide a cover/poster image for their upload."
            value={s.require_poster}
            onChange={set("require_poster")}
          />
          <Toggle
            label="Require Trailer"
            description="Contributors must include a trailer URL or file when uploading."
            value={s.require_trailer}
            onChange={set("require_trailer")}
          />
          <Toggle
            label="Show View Counts"
            description="Display view counts on content cards across the platform."
            value={s.show_view_counts}
            onChange={set("show_view_counts")}
          />
        </div>
        <div className="space-y-4 pt-4 mt-2 border-t border-white/5">
          <TextInput
            label="Max Content Per Contributor (0 = unlimited)"
            value={s.max_content_per_contributor}
            onChange={set("max_content_per_contributor")}
            type="number"
            placeholder="0"
            hint="Caps how many items each contributor can upload total."
          />
          <SelectInput
            label="Maximum Age Rating Allowed"
            value={s.max_age_rating}
            onChange={set("max_age_rating")}
            options={[
              { value: "G", label: "G — All ages" },
              { value: "PG", label: "PG — Parental guidance" },
              { value: "PG-13", label: "PG-13 — Parents strongly cautioned" },
              { value: "R", label: "R — Restricted" },
              { value: "NC-17", label: "NC-17 — Adults only" },
            ]}
            hint="Sets the maximum rating allowed on the platform."
          />
          <TextInput
            label="Minimum User Age to Register"
            value={s.minimum_age}
            onChange={set("minimum_age")}
            type="number"
            placeholder="13"
            hint="Users younger than this cannot sign up."
          />
        </div>
      </Section>

      {/* ── 4. MONETIZATION ── */}
      <Section icon={DollarSign} title="Monetization & Pricing" color="#FBBF24">
        <div className="space-y-4">
          <Toggle
            label="Default Content to Free"
            description="When contributors upload, content is free by default unless they set a price."
            value={s.default_content_free}
            onChange={set("default_content_free")}
          />
          <TextInput
            label="Default Price for Paid Content ($)"
            value={s.default_price}
            onChange={set("default_price")}
            type="number"
            placeholder="4.99"
            hint="Pre-filled price when a contributor marks content as paid."
          />
        </div>
      </Section>

      {/* ── 4b. SUBSCRIPTION PLANS ── */}
      <Section
        icon={DollarSign}
        title="Subscription Plans (Edit Prices)"
        color="#4ade80"
      >
        <div className="space-y-3">
          <p className="text-xs text-gray-500 mb-4">
            Edit the name and price of each subscription plan. Changes apply
            immediately on the Subscribe page.
          </p>
          {[
            {
              key: "monthly",
              labelKey: "sub_plan_monthly_label",
              priceKey: "sub_plan_monthly_price",
              defaultLabel: "Monthly",
              defaultPrice: "9.99",
            },
            {
              key: "2month",
              labelKey: "sub_plan_2month_label",
              priceKey: "sub_plan_2month_price",
              defaultLabel: "2 Months",
              defaultPrice: "17.99",
            },
            {
              key: "quarterly",
              labelKey: "sub_plan_quarterly_label",
              priceKey: "sub_plan_quarterly_price",
              defaultLabel: "3 Months",
              defaultPrice: "24.99",
            },
            {
              key: "biannual",
              labelKey: "sub_plan_biannual_label",
              priceKey: "sub_plan_biannual_price",
              defaultLabel: "6 Months",
              defaultPrice: "44.99",
            },
            {
              key: "yearly",
              labelKey: "sub_plan_yearly_label",
              priceKey: "sub_plan_yearly_price",
              defaultLabel: "1 Year",
              defaultPrice: "79.99",
            },
          ].map((plan) => (
            <div key={plan.key} className="flex gap-3 items-center">
              <div className="flex-1 space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                  Plan Name
                </label>
                <input
                  type="text"
                  defaultValue={s[plan.labelKey] || plan.defaultLabel}
                  onBlur={(e) => set(plan.labelKey)(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
                />
              </div>
              <div className="w-32 space-y-1">
                <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
                  Price ($)
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  defaultValue={s[plan.priceKey] || plan.defaultPrice}
                  onBlur={(e) => set(plan.priceKey)(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
                />
              </div>
            </div>
          ))}
          <p className="text-[11px] text-gray-600 mt-2">
            * Click outside a field to save it. The Subscribe page reads these
            prices in real-time.
          </p>
        </div>
      </Section>

      {/* ── 5. HOMEPAGE DISPLAY ── */}
      <Section icon={Star} title="Homepage & Display" color="#f59e0b">
        <div className="space-y-4">
          <TextInput
            label="Hero Carousel Count"
            value={s.homepage_hero_count}
            onChange={set("homepage_hero_count")}
            type="number"
            placeholder="6"
            hint="How many items show in the rotating hero at the top (max 10)."
          />
          <TextInput
            label="Pinned Featured Content IDs"
            value={s.featured_content_ids}
            onChange={set("featured_content_ids")}
            placeholder="e.g. 12, 5, 34"
            hint="Comma-separated content IDs to always show first in the hero."
          />
        </div>
      </Section>

      {/* ── 6. EMAIL & NOTIFICATIONS ── */}
      <Section icon={Mail} title="Email & Notifications" color="#10b981">
        <div className="space-y-1 divide-y divide-white/5 mb-4">
          <Toggle
            label="Send Welcome Email on Signup"
            description="New users get a welcome email when they create an account."
            value={s.welcome_email_enabled}
            onChange={set("welcome_email_enabled")}
          />
        </div>
        <div className="space-y-4 pt-2">
          <p className="text-xs font-bold text-gray-400 uppercase tracking-wider">
            Approval Email Template
          </p>
          <TextInput
            label="Approval Email Subject"
            value={s.approval_email_subject}
            onChange={set("approval_email_subject")}
            placeholder="You're approved!"
          />
          <TextArea
            label="Approval Email Intro Text"
            value={s.approval_email_intro}
            onChange={set("approval_email_intro")}
            placeholder="Your application has been approved..."
            rows={3}
          />
          <div className="border-t border-white/5 pt-4">
            <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">
              Rejection Email Template
            </p>
            <TextInput
              label="Rejection Email Subject"
              value={s.rejection_email_subject}
              onChange={set("rejection_email_subject")}
              placeholder="Update on your contributor request"
            />
            <div className="mt-3">
              <TextArea
                label="Rejection Email Intro Text"
                value={s.rejection_email_intro}
                onChange={set("rejection_email_intro")}
                placeholder="Thank you for applying..."
                rows={3}
              />
            </div>
          </div>
        </div>
      </Section>

      {/* ── 7. OWNER PROFILE ── */}
      <Section icon={Shield} title="Owner Profile" color="#ec4899">
        <div className="flex items-center gap-4 mb-5">
          <div className="h-16 w-16 rounded-full bg-gradient-to-br from-[#7C3AED] to-[#4C1D95] flex items-center justify-center text-2xl font-black border-2 border-[#7C3AED]/40">
            {profile?.username?.[0]?.toUpperCase()}
          </div>
          <div>
            <p className="font-black text-xl text-white">{profile?.username}</p>
            <div className="flex items-center gap-1.5 text-[#A78BFA] text-xs mt-1">
              <Shield size={11} /> Owner — Full Platform Access
            </div>
            {profile?.dob && (
              <p className="text-xs text-gray-500 mt-0.5">
                Member since birth: {new Date(profile.dob).toLocaleDateString()}
              </p>
            )}
          </div>
        </div>
        <div className="rounded-xl bg-white/3 border border-white/5 p-4">
          <p className="text-xs text-gray-500 leading-relaxed">
            Your owner account is tied to your email address. To change your
            username or date of birth, visit the onboarding page at{" "}
            <a href="/account/onboarding" className="text-[#A78BFA] underline">
              /account/onboarding
            </a>
            .
          </p>
        </div>
      </Section>

      {/* ── 8. DANGER ZONE ── */}
      <Section icon={AlertTriangle} title="Danger Zone" color="#ef4444">
        <div className="space-y-3">
          <p className="text-xs text-gray-500 mb-4">
            These actions are permanent. Be careful.
          </p>

          {handleBulkContentAction && (
            <>
              <div className="flex items-center justify-between p-4 rounded-xl bg-red-500/5 border border-red-500/10">
                <div>
                  <p className="text-sm font-bold text-white">
                    Delete All Rejected Content
                  </p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {rejectedContent} rejected item(s) will be permanently
                    removed.
                  </p>
                </div>
                <button
                  onClick={() => handleBulkContentAction("delete_rejected")}
                  disabled={rejectedContent === 0}
                  className="flex items-center gap-1.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-xl px-4 py-2 text-xs font-bold transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Trash2 size={13} /> Delete ({rejectedContent})
                </button>
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-yellow-500/5 border border-yellow-500/10">
                <div>
                  <p className="text-sm font-bold text-white">
                    Approve All Pending Content
                  </p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {pendingContent} pending item(s) will go live instantly.
                  </p>
                </div>
                <button
                  onClick={() => handleBulkContentAction("approve_all_pending")}
                  disabled={pendingContent === 0}
                  className="flex items-center gap-1.5 bg-green-500/10 hover:bg-green-500/20 text-green-400 border border-green-500/20 rounded-xl px-4 py-2 text-xs font-bold transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <CheckCircle size={13} /> Approve All ({pendingContent})
                </button>
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-blue-500/5 border border-blue-500/10">
                <div>
                  <p className="text-sm font-bold text-white">
                    Approve All Pending Contributors
                  </p>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {pendingContributors} pending contributor(s) will be
                    approved.
                  </p>
                </div>
                <button
                  onClick={() =>
                    handleBulkContentAction("approve_all_contributors")
                  }
                  disabled={pendingContributors === 0}
                  className="flex items-center gap-1.5 bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/20 rounded-xl px-4 py-2 text-xs font-bold transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Users size={13} /> Approve ({pendingContributors})
                </button>
              </div>
            </>
          )}
        </div>
      </Section>

      <style>{`
        @keyframes spin { to { transform: rotate(360deg); } }
        .bg-white\\/3 { background: rgba(255,255,255,0.03); }
      `}</style>
    </div>
  );
}
