import { Shield, ArrowLeft } from "lucide-react";

const LOGO_URL =
  "https://raw.createusercontent.com/83c42dc4-4b43-4e42-aded-b337415f50ea/";

export function Navigation() {
  return (
    <nav className="border-b border-white/5 px-4 sm:px-8 py-4 flex items-center justify-between">
      <a href="/" className="flex items-center gap-3">
        <img
          src={LOGO_URL}
          alt="Intergalactic Dimensions"
          className="h-9 w-auto object-contain"
        />
        <div className="hidden sm:block">
          <div className="text-[10px] font-bold tracking-[0.2em] text-[#A78BFA]">
            INTERGALACTIC
          </div>
          <div className="text-[10px] font-bold tracking-[0.2em] text-white">
            DIMENSIONS
          </div>
        </div>
      </a>
      <div className="flex items-center gap-3">
        <div className="hidden sm:flex items-center gap-1.5 bg-[#7C3AED]/20 text-[#A78BFA] rounded-full px-3 py-1 text-xs font-semibold">
          <Shield size={12} /> Owner Portal
        </div>
        <a
          href="/"
          className="flex items-center gap-1.5 text-gray-400 hover:text-white text-sm transition-colors"
        >
          <ArrowLeft size={15} /> Browse
        </a>
      </div>
    </nav>
  );
}
