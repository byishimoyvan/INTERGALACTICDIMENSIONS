export function TabNavigation({ tabs, activeTab, setActiveTab }) {
  return (
    <div className="mb-8 flex flex-wrap gap-1 bg-white/5 rounded-2xl p-1">
      {tabs.map((tab) => (
        <button
          key={tab.id}
          onClick={() => setActiveTab(tab.id)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${activeTab === tab.id ? "bg-[#7C3AED] text-white" : "text-gray-400 hover:text-white"}`}
        >
          <tab.icon size={15} />
          <span>{tab.label}</span>
          {tab.badge > 0 && (
            <span className="bg-red-500 text-white text-[10px] font-bold rounded-full px-1.5 py-0.5 leading-none">
              {tab.badge}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}
