"use client";
import { useState, useEffect } from "react";
import {
  DollarSign,
  CreditCard,
  TrendingUp,
  CheckCircle,
  Clock,
  AlertCircle,
} from "lucide-react";

const METHOD_ICONS = { mtn: "📱", airtel: "📲", stripe: "💳", paypal: "🅿️" };
const TYPE_COLORS = { subscription: "#A78BFA", purchase: "#4ade80" };

export function PaymentsTab() {
  const [data, setData] = useState({
    notifications: [],
    totalRevenue: 0,
    unreadCount: 0,
    pendingCount: 0,
  });
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [approving, setApproving] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const r = await fetch("/api/payment-notifications");
      if (!r.ok) throw new Error("Failed");
      const d = await r.json();
      setData(d);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const markRead = async () => {
    await fetch("/api/payment-notifications", { method: "PATCH" });
    setData((p) => ({
      ...p,
      notifications: p.notifications.map((n) => ({ ...n, is_read: true })),
      unreadCount: 0,
    }));
  };

  const approve = async (n) => {
    setApproving(n.id);
    try {
      const r = await fetch("/api/payment-notifications", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notificationId: n.id }),
      });
      if (!r.ok) throw new Error("Failed");
      await load();
    } catch (e) {
      console.error(e);
    } finally {
      setApproving(null);
    }
  };

  const filtered = data.notifications.filter((n) =>
    filter === "all"
      ? true
      : filter === "pending"
        ? n.status === "pending"
        : n.notify_type === filter,
  );

  const stats = [
    {
      label: "Total Revenue",
      value: `$${(data.totalRevenue || 0).toFixed(2)}`,
      icon: DollarSign,
      color: "#4ade80",
      bg: "rgba(74,222,128,.1)",
    },
    {
      label: "Total Payments",
      value: data.notifications.length,
      icon: CreditCard,
      color: "#A78BFA",
      bg: "rgba(167,139,250,.1)",
    },
    {
      label: "Pending Approval",
      value: data.pendingCount || 0,
      icon: Clock,
      color: "#FBBF24",
      bg: "rgba(251,191,36,.1)",
    },
    {
      label: "Subscriptions",
      value: data.notifications.filter(
        (n) => n.notify_type === "subscription" && n.status === "approved",
      ).length,
      icon: TrendingUp,
      color: "#60a5fa",
      bg: "rgba(96,165,250,.1)",
    },
  ];

  return (
    <div>
      {/* Stats row */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill,minmax(175px,1fr))",
          gap: 16,
          marginBottom: 28,
        }}
      >
        {stats.map((s) => (
          <div
            key={s.label}
            style={{
              background: "rgba(255,255,255,.03)",
              border: "1px solid rgba(255,255,255,.07)",
              borderRadius: 16,
              padding: "20px 18px",
            }}
          >
            <div
              style={{
                height: 36,
                width: 36,
                borderRadius: 10,
                background: s.bg,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                marginBottom: 10,
              }}
            >
              <s.icon size={17} style={{ color: s.color }} />
            </div>
            <p
              style={{
                fontSize: 22,
                fontWeight: 900,
                margin: 0,
                color: s.color,
              }}
            >
              {s.value}
            </p>
            <p style={{ fontSize: 11, color: "#6b7280", margin: "4px 0 0" }}>
              {s.label}
            </p>
          </div>
        ))}
      </div>

      {/* MTN/Airtel owner instructions */}
      <div
        style={{
          marginBottom: 24,
          padding: "16px 20px",
          borderRadius: 14,
          background: "rgba(251,191,36,.05)",
          border: "1px solid rgba(251,191,36,.2)",
        }}
      >
        <p
          style={{
            fontWeight: 900,
            fontSize: 13,
            color: "#FBBF24",
            margin: "0 0 8px",
            display: "flex",
            alignItems: "center",
            gap: 7,
          }}
        >
          <AlertCircle size={14} /> Manual Mobile Money — Your Numbers
        </p>
        <p
          style={{ fontSize: 12, color: "#9ca3af", margin: 0, lineHeight: 1.8 }}
        >
          Viewers send money to your numbers manually:
          <br />📱{" "}
          <strong style={{ color: "white" }}>MTN MoMo: 0799395838</strong>
          &nbsp;&nbsp;·&nbsp;&nbsp; 📲{" "}
          <strong style={{ color: "white" }}>Airtel Money: 0722461585</strong>
          <br />
          After you verify the transfer in your mobile money app, click{" "}
          <strong style={{ color: "#4ade80" }}>Approve & Grant Access</strong>{" "}
          below.
        </p>
      </div>

      {/* Filters */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          marginBottom: 16,
          flexWrap: "wrap",
          gap: 12,
        }}
      >
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {[
            ["all", "All"],
            ["pending", "⏳ Pending"],
            ["purchase", "Per-Title"],
            ["subscription", "Subscriptions"],
          ].map(([f, l]) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              style={{
                padding: "7px 16px",
                borderRadius: 20,
                fontSize: 12,
                fontWeight: 700,
                border: "1px solid",
                cursor: "pointer",
                background:
                  filter === f
                    ? "rgba(124,58,237,.25)"
                    : "rgba(255,255,255,.04)",
                borderColor: filter === f ? "#7C3AED" : "rgba(255,255,255,.08)",
                color: filter === f ? "#A78BFA" : "#6b7280",
              }}
            >
              {l}
            </button>
          ))}
        </div>
        {data.unreadCount > 0 && (
          <button
            onClick={markRead}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              padding: "7px 16px",
              borderRadius: 20,
              fontSize: 12,
              fontWeight: 700,
              border: "1px solid rgba(124,58,237,.3)",
              background: "rgba(124,58,237,.1)",
              color: "#A78BFA",
              cursor: "pointer",
            }}
          >
            <CheckCircle size={12} /> Mark all read
          </button>
        )}
      </div>

      {/* Payment list */}
      {loading ? (
        <div style={{ display: "flex", justifyContent: "center", padding: 60 }}>
          <div
            style={{
              height: 28,
              width: 28,
              borderRadius: "50%",
              border: "2px solid #7C3AED",
              borderTopColor: "transparent",
              animation: "spin 1s linear infinite",
            }}
          />
        </div>
      ) : filtered.length === 0 ? (
        <div style={{ textAlign: "center", padding: 60, color: "#4b5563" }}>
          <DollarSign
            size={40}
            strokeWidth={1}
            style={{ margin: "0 auto 12px", opacity: 0.3 }}
          />
          <p style={{ fontSize: 14 }}>
            {filter === "pending"
              ? "No pending payments 🎉"
              : "No payments yet."}
          </p>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {filtered.map((n) => {
            const isPending = n.status === "pending";
            const methodKey = (n.payment_method || "")
              .toLowerCase()
              .split(" ")[0];
            return (
              <div
                key={n.id}
                style={{
                  background: isPending
                    ? "rgba(251,191,36,.05)"
                    : n.is_read
                      ? "rgba(255,255,255,.03)"
                      : "rgba(124,58,237,.07)",
                  border: `1px solid ${isPending ? "rgba(251,191,36,.3)" : n.is_read ? "rgba(255,255,255,.07)" : "rgba(124,58,237,.25)"}`,
                  borderRadius: 14,
                  padding: "16px 20px",
                  display: "flex",
                  alignItems: "flex-start",
                  gap: 16,
                  flexWrap: "wrap",
                }}
              >
                {/* Provider icon */}
                <div style={{ fontSize: 24, flexShrink: 0 }}>
                  {METHOD_ICONS[methodKey] || "💰"}
                </div>

                {/* Info */}
                <div style={{ flex: 1, minWidth: 160 }}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      gap: 8,
                      marginBottom: 5,
                      flexWrap: "wrap",
                    }}
                  >
                    <span
                      style={{ fontWeight: 900, fontSize: 14, color: "white" }}
                    >
                      {n.username ||
                        n.user_email ||
                        `User ${String(n.user_id).slice(0, 6)}`}
                    </span>
                    <span
                      style={{
                        fontSize: 10,
                        padding: "2px 8px",
                        borderRadius: 10,
                        fontWeight: 700,
                        background:
                          (TYPE_COLORS[n.notify_type] || "#fff") + "22",
                        color: TYPE_COLORS[n.notify_type] || "#fff",
                      }}
                    >
                      {n.notify_type === "subscription"
                        ? "Subscription"
                        : "Purchase"}
                    </span>
                    {isPending && (
                      <span
                        style={{
                          fontSize: 9,
                          background: "#FBBF24",
                          color: "#030308",
                          padding: "2px 8px",
                          borderRadius: 10,
                          fontWeight: 900,
                        }}
                      >
                        PENDING APPROVAL
                      </span>
                    )}
                    {!isPending && !n.is_read && (
                      <span
                        style={{
                          fontSize: 9,
                          background: "#7C3AED",
                          color: "white",
                          padding: "2px 8px",
                          borderRadius: 10,
                          fontWeight: 700,
                        }}
                      >
                        NEW
                      </span>
                    )}
                  </div>
                  <p style={{ fontSize: 12, color: "#9ca3af", margin: 0 }}>
                    {n.content_title ? `"${n.content_title}"` : ""}
                    {n.subscription_plan || ""}
                    {n.user_email ? ` · ${n.user_email}` : ""}
                  </p>
                  {n.payment_reference && (
                    <p
                      style={{
                        fontSize: 10,
                        color: "#4b5563",
                        margin: "3px 0 0",
                        fontFamily: "monospace",
                        wordBreak: "break-all",
                      }}
                    >
                      {n.payment_reference}
                    </p>
                  )}
                </div>

                {/* Right side */}
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "flex-end",
                    gap: 8,
                    flexShrink: 0,
                  }}
                >
                  <p
                    style={{
                      fontSize: 20,
                      fontWeight: 900,
                      margin: 0,
                      color: isPending ? "#FBBF24" : "#4ade80",
                    }}
                  >
                    ${parseFloat(n.amount).toFixed(2)}
                  </p>
                  <p
                    style={{
                      fontSize: 11,
                      color: "#6b7280",
                      margin: 0,
                      textTransform: "uppercase",
                    }}
                  >
                    {methodKey}
                  </p>
                  <p style={{ fontSize: 10, color: "#4b5563", margin: 0 }}>
                    {new Date(n.created_at).toLocaleDateString()}
                  </p>

                  {isPending && (
                    <button
                      onClick={() => approve(n)}
                      disabled={approving === n.id}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "8px 16px",
                        borderRadius: 10,
                        background: "rgba(74,222,128,.12)",
                        border: "1px solid rgba(74,222,128,.4)",
                        color: "#4ade80",
                        fontWeight: 900,
                        fontSize: 12,
                        cursor: approving === n.id ? "default" : "pointer",
                      }}
                    >
                      {approving === n.id ? (
                        <>
                          <div
                            style={{
                              height: 11,
                              width: 11,
                              borderRadius: "50%",
                              border: "2px solid #4ade80",
                              borderTopColor: "transparent",
                              animation: "spin 1s linear infinite",
                            }}
                          />{" "}
                          Granting...
                        </>
                      ) : (
                        <>
                          <CheckCircle size={13} /> Approve & Grant Access
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
