import { Shield } from "lucide-react";

export function DashboardHeader({ username }) {
  return (
    <div className="mb-8">
      <div className="flex items-center gap-3 mb-2">
        <div className="h-10 w-10 rounded-xl bg-[#7C3AED] flex items-center justify-center">
          <Shield size={20} />
        </div>
        <div>
          <h1 className="text-2xl font-black">Owner Control Center</h1>
          <p className="text-sm text-gray-400">
            Welcome back, {username}. You have full control.
          </p>
        </div>
      </div>
    </div>
  );
}
