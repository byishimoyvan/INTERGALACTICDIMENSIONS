import { Upload, CheckCircle, ImageIcon, BookOpen, Film } from "lucide-react";

export function ContributorUploadForm({
  contribForm,
  setContribForm,
  contribSuccess,
  setContribSuccess,
  contribError,
  contribUploadLoading,
  uploadingContribFile,
  uploadingContribPoster,
  contribFileProgress,
  contribPosterProgress,
  handleContribFile,
  handleContribSubmit,
  genres,
}) {
  if (contribSuccess) {
    return (
      <div className="rounded-2xl border border-green-500/20 bg-green-500/10 p-8 text-center">
        <CheckCircle size={40} className="text-green-400 mx-auto mb-3" />
        <h3 className="text-lg font-bold mb-1">Content Submitted!</h3>
        <p className="text-sm text-gray-400 mb-5">
          It's now pending review in the Content Approval tab.
        </p>
        <button
          onClick={() => setContribSuccess(false)}
          className="bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl px-6 py-2.5 text-sm font-bold transition-colors"
        >
          Submit Another
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleContribSubmit} className="space-y-5">
      {contribError && (
        <div className="rounded-xl bg-red-500/10 border border-red-500/20 px-4 py-3 text-sm text-red-400">
          {contribError}
        </div>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Title *
          </label>
          <input
            required
            type="text"
            value={contribForm.title}
            onChange={(e) =>
              setContribForm({
                ...contribForm,
                title: e.target.value,
              })
            }
            placeholder="Enter title..."
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
          />
        </div>
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Type *
          </label>
          <select
            value={contribForm.type}
            onChange={(e) =>
              setContribForm({
                ...contribForm,
                type: e.target.value,
              })
            }
            className="w-full bg-[#0A0A0F] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
          >
            <option value="movie">Movie / Series</option>
            <option value="storybook">Story Book</option>
          </select>
        </div>
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
          Genre *
        </label>
        <div className="flex flex-wrap gap-2">
          {genres.map((g) => (
            <button
              key={g.id}
              type="button"
              onClick={() => setContribForm({ ...contribForm, genreId: g.id })}
              className={`rounded-full px-3 py-1 text-xs font-semibold border transition-colors ${contribForm.genreId === g.id ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"}`}
            >
              {g.name}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-1.5">
        <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
          Description
        </label>
        <textarea
          value={contribForm.description}
          onChange={(e) =>
            setContribForm({
              ...contribForm,
              description: e.target.value,
            })
          }
          rows={3}
          placeholder="Brief description..."
          className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors resize-none"
        />
      </div>

      {/* Pricing - just FREE or PAID toggle, no price input */}
      <div className="grid grid-cols-2 gap-3">
        <button
          type="button"
          onClick={() =>
            setContribForm({ ...contribForm, isFree: true, price: 0 })
          }
          className={`rounded-xl border p-3 text-left transition-all ${contribForm.isFree ? "border-green-500 bg-green-500/10" : "border-white/10 bg-white/5"}`}
        >
          <div className="text-green-400 font-bold text-sm mb-0.5">FREE</div>
          <p className="text-[10px] text-gray-400">
            Open to all signed-in users
          </p>
        </button>
        <button
          type="button"
          onClick={() =>
            setContribForm({ ...contribForm, isFree: false, price: 9.99 })
          }
          className={`rounded-xl border p-3 text-left transition-all ${!contribForm.isFree ? "border-[#FBBF24] bg-[#FBBF24]/10" : "border-white/10 bg-white/5"}`}
        >
          <div className="text-[#FBBF24] font-bold text-sm mb-0.5">PAID</div>
          <p className="text-[10px] text-gray-400">
            Viewers pay via subscription or purchase
          </p>
        </button>
      </div>
      {/* No price input — price is managed by the platform subscription system */}

      {/* File uploads */}
      <div className="grid grid-cols-2 gap-4">
        {/* Poster */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Poster
          </label>
          <div className="relative group">
            <div className="aspect-[2/3] rounded-xl border-2 border-dashed border-white/10 group-hover:border-[#7C3AED]/50 bg-white/5 overflow-hidden flex flex-col items-center justify-center transition-all">
              {contribForm.posterUrl ? (
                <img
                  src={contribForm.posterUrl}
                  alt="poster"
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="text-center p-3">
                  <ImageIcon size={26} className="text-gray-600 mx-auto mb-1" />
                  <p className="text-[10px] text-gray-500">Click to upload</p>
                </div>
              )}
              {uploadingContribPoster && (
                <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-4">
                  <div className="w-full">
                    <div className="flex justify-between text-xs text-white mb-1">
                      <span>Uploading...</span>
                      <span className="font-bold text-[#A78BFA]">
                        {contribPosterProgress ?? 0}%
                      </span>
                    </div>
                    <div className="w-full bg-white/20 rounded-full h-2">
                      <div
                        className="bg-[#7C3AED] h-2 rounded-full transition-all duration-300"
                        style={{ width: `${contribPosterProgress ?? 0}%` }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => handleContribFile(e, "poster")}
              className="absolute inset-0 cursor-pointer opacity-0"
            />
          </div>
        </div>
        {/* Content File */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Content File *
          </label>
          <div className="relative group">
            <div className="aspect-[2/3] rounded-xl border-2 border-dashed border-white/10 group-hover:border-[#7C3AED]/50 bg-white/5 overflow-hidden flex flex-col items-center justify-center transition-all">
              {contribForm.fileUrl ? (
                <div className="text-center p-3">
                  {contribForm.type === "storybook" ? (
                    <BookOpen
                      size={28}
                      className="text-[#7C3AED] mx-auto mb-1"
                    />
                  ) : (
                    <Film size={28} className="text-[#7C3AED] mx-auto mb-1" />
                  )}
                  <p className="text-[10px] text-green-400">Uploaded!</p>
                </div>
              ) : (
                <div className="text-center p-3">
                  <Upload size={26} className="text-gray-600 mx-auto mb-1" />
                  <p className="text-[10px] text-gray-500">
                    {contribForm.type === "storybook" ? "PDF" : "MP4 / Video"}
                  </p>
                </div>
              )}
              {uploadingContribFile && (
                <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-4">
                  <div className="w-full">
                    <div className="flex justify-between text-xs text-white mb-1">
                      <span>Uploading...</span>
                      <span className="font-bold text-[#A78BFA]">
                        {contribFileProgress ?? 0}%
                      </span>
                    </div>
                    <div className="w-full bg-white/20 rounded-full h-2.5">
                      <div
                        className="bg-gradient-to-r from-[#7C3AED] to-[#A78BFA] h-2.5 rounded-full transition-all duration-300"
                        style={{ width: `${contribFileProgress ?? 0}%` }}
                      />
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1.5 text-center">
                      Do not close this page
                    </p>
                  </div>
                </div>
              )}
            </div>
            <input
              type="file"
              accept={contribForm.type === "storybook" ? ".pdf" : "video/*"}
              onChange={(e) => handleContribFile(e, "content")}
              className="absolute inset-0 cursor-pointer opacity-0"
            />
          </div>
        </div>
      </div>

      <button
        type="submit"
        disabled={
          contribUploadLoading ||
          uploadingContribFile ||
          uploadingContribPoster ||
          !contribForm.fileUrl ||
          !contribForm.genreId
        }
        className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl py-3 text-sm font-bold transition-colors flex items-center justify-center gap-2"
      >
        {contribUploadLoading ? (
          <>
            <div
              className="h-4 w-4 rounded-full border-2 border-white border-t-transparent"
              style={{ animation: "spin 1s linear infinite" }}
            />{" "}
            Submitting...
          </>
        ) : (
          <>
            <Upload size={15} /> Submit for Review
          </>
        )}
      </button>
    </form>
  );
}
