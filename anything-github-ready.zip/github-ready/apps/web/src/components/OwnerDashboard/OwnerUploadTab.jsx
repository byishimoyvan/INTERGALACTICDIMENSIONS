import { useState } from "react";
import {
  Upload,
  CheckCircle,
  FileText,
  Star,
  DollarSign,
  Lock,
  FileVideo,
  ImageIcon,
  Film,
  BookOpen,
  Tv,
  Tag,
  Link,
} from "lucide-react";

export function OwnerUploadTab({
  uploadSuccess,
  setUploadSuccess,
  uploadError,
  formData,
  setFormData,
  genres,
  uploadLoading,
  uploadingFile,
  uploadingPoster,
  uploadingTrailer,
  fileProgress,
  posterProgress,
  trailerProgress,
  handleOwnerFile,
  handleOwnerSubmit,
}) {
  const [fileInputMode, setFileInputMode] = useState("upload"); // "upload" | "url"
  const [fileUrlInput, setFileUrlInput] = useState("");
  const [trailerInputMode, setTrailerInputMode] = useState("upload");
  const [trailerUrlInput, setTrailerUrlInput] = useState("");

  const handleUrlInput = (val) => {
    setFileUrlInput(val);
    setFormData({ ...formData, fileUrl: val.trim() });
  };

  const handleTrailerUrlInput = (val) => {
    setTrailerUrlInput(val);
    setFormData({ ...formData, trailerUrl: val.trim() });
  };

  if (uploadSuccess) {
    return (
      <div className="rounded-2xl border border-green-500/20 bg-green-500/10 p-10 text-center">
        <CheckCircle size={52} className="text-green-400 mx-auto mb-4" />
        <h3 className="text-xl font-black mb-2">
          Published to the Multiverse!
        </h3>
        <p className="text-gray-400 mb-6">
          Your content is now live on the platform.
        </p>
        <div className="flex gap-3 justify-center flex-wrap">
          <button
            onClick={() => setUploadSuccess(false)}
            className="bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl px-6 py-2.5 text-sm font-bold transition-colors"
          >
            Upload Another
          </button>
          <a
            href="/"
            className="border border-white/10 text-gray-300 hover:text-white rounded-xl px-6 py-2.5 text-sm font-bold transition-colors"
          >
            View on Site
          </a>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={handleOwnerSubmit} className="space-y-6">
      {uploadError && (
        <div className="rounded-xl bg-red-500/10 border border-red-500/20 px-4 py-3 text-sm text-red-400">
          {uploadError}
        </div>
      )}

      {/* Basic Info */}
      <div className="rounded-2xl border border-white/10 bg-[#141420] p-6 space-y-5">
        <div className="flex items-center gap-2 mb-1">
          <FileText size={15} className="text-[#A78BFA]" />
          <h3 className="text-sm font-bold text-[#A78BFA] uppercase tracking-widest">
            Basic Information
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Title *
            </label>
            <input
              required
              type="text"
              value={formData.title}
              onChange={(e) =>
                setFormData({ ...formData, title: e.target.value })
              }
              placeholder="Journey Beyond the Rift..."
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Content Type *
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { val: "movie", icon: Film, label: "Movie" },
                { val: "series", icon: Tv, label: "Series" },
                { val: "storybook", icon: BookOpen, label: "Book" },
              ].map(({ val, icon: Icon, label }) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setFormData({ ...formData, type: val })}
                  className={`flex flex-col items-center gap-1 rounded-xl border py-2.5 text-xs font-semibold transition-all ${formData.type === val ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"}`}
                >
                  <Icon size={16} />
                  {label}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Genre *
          </label>
          <div className="flex flex-wrap gap-2">
            {genres.map((g) => (
              <button
                key={g.id}
                type="button"
                onClick={() => setFormData({ ...formData, genreId: g.id })}
                className={`rounded-full px-4 py-1.5 text-xs font-semibold border transition-colors ${formData.genreId === g.id ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"}`}
              >
                {g.name}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
            Description *
          </label>
          <textarea
            required
            value={formData.description}
            onChange={(e) =>
              setFormData({
                ...formData,
                description: e.target.value,
              })
            }
            rows={4}
            placeholder="Tell viewers what this is about..."
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors resize-none"
          />
        </div>
      </div>

      {/* Production Details */}
      <div className="rounded-2xl border border-white/10 bg-[#141420] p-6 space-y-5">
        <div className="flex items-center gap-2 mb-1">
          <Star size={15} className="text-[#A78BFA]" />
          <h3 className="text-sm font-bold text-[#A78BFA] uppercase tracking-widest">
            Production Details
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Director / Author
            </label>
            <input
              type="text"
              value={formData.director}
              onChange={(e) =>
                setFormData({ ...formData, director: e.target.value })
              }
              placeholder="e.g. Christopher Nolan"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Cast / Characters
            </label>
            <input
              type="text"
              value={formData.cast}
              onChange={(e) =>
                setFormData({ ...formData, cast: e.target.value })
              }
              placeholder="e.g. John Doe, Jane Smith"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Release Year
            </label>
            <input
              type="number"
              min="1900"
              max="2099"
              value={formData.releaseYear}
              onChange={(e) =>
                setFormData({
                  ...formData,
                  releaseYear: parseInt(e.target.value),
                })
              }
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Duration
            </label>
            <input
              type="text"
              value={formData.duration}
              onChange={(e) =>
                setFormData({ ...formData, duration: e.target.value })
              }
              placeholder="e.g. 2h 30m or 300 pages"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Language
            </label>
            <select
              value={formData.language}
              onChange={(e) =>
                setFormData({ ...formData, language: e.target.value })
              }
              className="w-full bg-[#0A0A0F] border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
            >
              {[
                "English",
                "French",
                "Spanish",
                "Kinyarwanda",
                "Swahili",
                "Arabic",
                "Portuguese",
                "Mandarin",
                "Hindi",
                "Japanese",
                "German",
                "Other",
              ].map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Age Rating
            </label>
            <div className="flex gap-2 flex-wrap">
              {["G", "PG", "PG-13", "R", "18+"].map((rating) => (
                <button
                  key={rating}
                  type="button"
                  onClick={() =>
                    setFormData({ ...formData, ageRating: rating })
                  }
                  className={`rounded-full px-3 py-1 text-xs font-bold border transition-colors ${formData.ageRating === rating ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"}`}
                >
                  {rating}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider flex items-center gap-1">
            <Tag size={12} /> Tags (comma-separated)
          </label>
          <input
            type="text"
            value={formData.tags}
            onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
            placeholder="e.g. space, adventure, aliens, based-on-true-story"
            className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
          />
        </div>
      </div>

      {/* Access & Pricing */}
      <div className="rounded-2xl border border-white/10 bg-[#141420] p-6 space-y-5">
        <div className="flex items-center gap-2 mb-1">
          <DollarSign size={15} className="text-[#A78BFA]" />
          <h3 className="text-sm font-bold text-[#A78BFA] uppercase tracking-widest">
            Access
          </h3>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setFormData({ ...formData, isFree: true, price: 0 })}
            className={`rounded-xl border p-4 text-left transition-all ${formData.isFree ? "border-green-500 bg-green-500/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
          >
            <div className="text-green-400 font-bold text-sm mb-1">FREE</div>
            <p className="text-xs text-gray-400">
              Any signed-in user can watch
            </p>
          </button>
          <button
            type="button"
            onClick={() =>
              setFormData({ ...formData, isFree: false, price: 9.99 })
            }
            className={`rounded-xl border p-4 text-left transition-all ${!formData.isFree ? "border-[#FBBF24] bg-[#FBBF24]/10" : "border-white/10 bg-white/5 hover:border-white/20"}`}
          >
            <div className="text-[#FBBF24] font-bold text-sm mb-1">PAID</div>
            <p className="text-xs text-gray-400">
              Viewers pay via subscription or per-title purchase
            </p>
          </button>
        </div>

        {/* Private toggle */}
        <div className="flex items-center gap-3 p-4 rounded-xl bg-white/5 border border-white/10">
          <button
            type="button"
            onClick={() =>
              setFormData({ ...formData, isPrivate: !formData.isPrivate })
            }
            className={`relative w-11 h-6 rounded-full transition-colors flex-shrink-0 ${formData.isPrivate ? "bg-[#7C3AED]" : "bg-white/10"}`}
          >
            <div
              className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform ${formData.isPrivate ? "translate-x-5" : "translate-x-0.5"}`}
            />
          </button>
          <div>
            <div className="text-sm font-semibold flex items-center gap-1.5">
              <Lock size={13} className="text-[#A78BFA]" /> Private — Owner Only
            </div>
            <p className="text-xs text-gray-500 mt-0.5">
              Hidden from public. Only you can see this content.
            </p>
          </div>
        </div>
      </div>

      {/* File Uploads */}
      <div className="rounded-2xl border border-white/10 bg-[#141420] p-6 space-y-5">
        <div className="flex items-center gap-2 mb-1">
          <FileVideo size={15} className="text-[#A78BFA]" />
          <h3 className="text-sm font-bold text-[#A78BFA] uppercase tracking-widest">
            Upload Files
          </h3>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-3">
          {/* Poster */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
              Poster / Cover *
            </label>
            <div className="relative group">
              <div className="aspect-[2/3] rounded-xl border-2 border-dashed border-white/10 group-hover:border-[#7C3AED]/60 bg-white/5 overflow-hidden flex flex-col items-center justify-center transition-all">
                {formData.posterUrl ? (
                  <img
                    src={formData.posterUrl}
                    alt="poster"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="text-center p-4">
                    <ImageIcon
                      size={30}
                      className="text-gray-600 mx-auto mb-2"
                    />
                    <p className="text-xs text-gray-500">Click to upload</p>
                    <p className="text-[10px] text-gray-600 mt-1">
                      JPG, PNG, WEBP
                    </p>
                  </div>
                )}
                {uploadingPoster && (
                  <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-5">
                    <div className="w-full">
                      <div className="flex justify-between text-xs text-white mb-1.5">
                        <span>Uploading...</span>
                        <span className="font-bold text-[#A78BFA]">
                          {posterProgress ?? 0}%
                        </span>
                      </div>
                      <div className="w-full bg-white/20 rounded-full h-2">
                        <div
                          className="bg-[#7C3AED] h-2 rounded-full transition-all duration-300"
                          style={{ width: `${posterProgress ?? 0}%` }}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleOwnerFile(e, "poster")}
                className="absolute inset-0 cursor-pointer opacity-0"
              />
            </div>
            {formData.posterUrl && (
              <p className="text-[10px] text-green-400 flex items-center gap-1">
                <CheckCircle size={10} /> Poster ready
              </p>
            )}
          </div>

          {/* Content File */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                Main File *{" "}
                {formData.type === "storybook" ? "(PDF)" : "(Video)"}
              </label>
              {/* Toggle: Upload vs URL */}
              <div className="flex rounded-lg border border-white/10 overflow-hidden">
                <button
                  type="button"
                  onClick={() => {
                    setFileInputMode("upload");
                    setFileUrlInput("");
                    setFormData({ ...formData, fileUrl: "" });
                  }}
                  className={`px-2.5 py-1 text-[10px] font-bold flex items-center gap-1 transition-colors ${
                    fileInputMode === "upload"
                      ? "bg-[#7C3AED] text-white"
                      : "bg-white/5 text-gray-400 hover:text-white"
                  }`}
                >
                  <Upload size={9} /> File
                </button>
                <button
                  type="button"
                  onClick={() => setFileInputMode("url")}
                  className={`px-2.5 py-1 text-[10px] font-bold flex items-center gap-1 transition-colors ${
                    fileInputMode === "url"
                      ? "bg-[#7C3AED] text-white"
                      : "bg-white/5 text-gray-400 hover:text-white"
                  }`}
                >
                  <Link size={9} /> URL
                </button>
              </div>
            </div>

            {fileInputMode === "url" ? (
              <div className="rounded-xl border-2 border-dashed border-[#7C3AED]/40 bg-[#7C3AED]/5 p-4 space-y-3">
                <div className="flex items-start gap-2">
                  <Link
                    size={14}
                    className="text-[#A78BFA] mt-0.5 flex-shrink-0"
                  />
                  <p className="text-xs text-gray-400">
                    Paste a streaming link (Netfilm, MovieBox, YouTube, etc.) —
                    users will watch from this source.
                  </p>
                </div>
                <input
                  type="url"
                  value={fileUrlInput}
                  onChange={(e) => handleUrlInput(e.target.value)}
                  placeholder="https://netfilm.world/spa/videoPlayPage/..."
                  className="w-full bg-[#0A0A0F] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                />
                {formData.fileUrl && (
                  <p className="text-[10px] text-green-400 flex items-center gap-1">
                    <CheckCircle size={9} /> URL ready — content will stream
                    from this link
                  </p>
                )}
              </div>
            ) : (
              <div className="relative group">
                <div className="aspect-[2/3] rounded-xl border-2 border-dashed border-white/10 group-hover:border-[#7C3AED]/60 bg-white/5 overflow-hidden flex flex-col items-center justify-center transition-all">
                  {formData.fileUrl ? (
                    <div className="text-center p-4">
                      {formData.type === "storybook" ? (
                        <BookOpen
                          size={36}
                          className="text-[#7C3AED] mx-auto mb-2"
                        />
                      ) : (
                        <Film
                          size={36}
                          className="text-[#7C3AED] mx-auto mb-2"
                        />
                      )}
                      <p className="text-xs text-green-400 font-semibold">
                        Uploaded!
                      </p>
                    </div>
                  ) : (
                    <div className="text-center p-4">
                      <Upload
                        size={30}
                        className="text-gray-600 mx-auto mb-2"
                      />
                      <p className="text-xs text-gray-500">Click to upload</p>
                      <p className="text-[10px] text-gray-600 mt-1">
                        {formData.type === "storybook"
                          ? "PDF only"
                          : "MP4, MOV, AVI"}
                      </p>
                    </div>
                  )}
                  {uploadingFile && (
                    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-5">
                      <div className="w-full">
                        <div className="flex justify-between text-xs text-white mb-1.5">
                          <span>Uploading...</span>
                          <span className="font-bold text-[#A78BFA]">
                            {fileProgress ?? 0}%
                          </span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-2.5">
                          <div
                            className="bg-gradient-to-r from-[#7C3AED] to-[#A78BFA] h-2.5 rounded-full transition-all duration-300"
                            style={{ width: `${fileProgress ?? 0}%` }}
                          />
                        </div>
                        <p className="text-[10px] text-gray-400 mt-2 text-center">
                          Do not close this page
                        </p>
                      </div>
                    </div>
                  )}
                </div>
                <input
                  type="file"
                  accept={formData.type === "storybook" ? ".pdf" : "video/*"}
                  onChange={(e) => handleOwnerFile(e, "content")}
                  className="absolute inset-0 cursor-pointer opacity-0"
                />
              </div>
            )}

            {formData.fileUrl && (
              <p className="text-[10px] text-green-400 flex items-center gap-1">
                <CheckCircle size={10} /> Content{" "}
                {fileInputMode === "url" ? "URL" : "file"} ready
              </p>
            )}
          </div>

          {/* Trailer */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                Trailer (Optional)
              </label>
              <div className="flex rounded-lg border border-white/10 overflow-hidden">
                <button
                  type="button"
                  onClick={() => {
                    setTrailerInputMode("upload");
                    setTrailerUrlInput("");
                    setFormData({ ...formData, trailerUrl: "" });
                  }}
                  className={`px-2.5 py-1 text-[10px] font-bold flex items-center gap-1 transition-colors ${
                    trailerInputMode === "upload"
                      ? "bg-[#7C3AED] text-white"
                      : "bg-white/5 text-gray-400 hover:text-white"
                  }`}
                >
                  <Upload size={9} /> File
                </button>
                <button
                  type="button"
                  onClick={() => setTrailerInputMode("url")}
                  className={`px-2.5 py-1 text-[10px] font-bold flex items-center gap-1 transition-colors ${
                    trailerInputMode === "url"
                      ? "bg-[#7C3AED] text-white"
                      : "bg-white/5 text-gray-400 hover:text-white"
                  }`}
                >
                  <Link size={9} /> URL
                </button>
              </div>
            </div>

            {trailerInputMode === "url" ? (
              <div className="rounded-xl border-2 border-dashed border-[#7C3AED]/40 bg-[#7C3AED]/5 p-4 space-y-3">
                <div className="flex items-start gap-2">
                  <Link
                    size={14}
                    className="text-[#A78BFA] mt-0.5 flex-shrink-0"
                  />
                  <p className="text-xs text-gray-400">
                    Paste a trailer link (YouTube, Vimeo, etc.)
                  </p>
                </div>
                <input
                  type="url"
                  value={trailerUrlInput}
                  onChange={(e) => handleTrailerUrlInput(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  className="w-full bg-[#0A0A0F] border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                />
                {formData.trailerUrl && (
                  <p className="text-[10px] text-green-400 flex items-center gap-1">
                    <CheckCircle size={9} /> Trailer URL ready
                  </p>
                )}
              </div>
            ) : (
              <div className="relative group">
                <div className="aspect-[2/3] rounded-xl border-2 border-dashed border-white/10 group-hover:border-[#7C3AED]/60 bg-white/5 overflow-hidden flex flex-col items-center justify-center transition-all">
                  {formData.trailerUrl ? (
                    <div className="text-center p-4">
                      <FileVideo
                        size={36}
                        className="text-[#7C3AED] mx-auto mb-2"
                      />
                      <p className="text-xs text-green-400 font-semibold">
                        Trailer ready!
                      </p>
                    </div>
                  ) : (
                    <div className="text-center p-4">
                      <FileVideo
                        size={30}
                        className="text-gray-600 mx-auto mb-2"
                      />
                      <p className="text-xs text-gray-500">Click to upload</p>
                      <p className="text-[10px] text-gray-600 mt-1">
                        MP4 trailer
                      </p>
                    </div>
                  )}
                  {uploadingTrailer && (
                    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center p-5">
                      <div className="w-full">
                        <div className="flex justify-between text-xs text-white mb-1.5">
                          <span>Uploading trailer...</span>
                          <span className="font-bold text-[#A78BFA]">
                            {trailerProgress ?? 0}%
                          </span>
                        </div>
                        <div className="w-full bg-white/20 rounded-full h-2">
                          <div
                            className="bg-[#7C3AED] h-2 rounded-full transition-all duration-300"
                            style={{ width: `${trailerProgress ?? 0}%` }}
                          />
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <input
                  type="file"
                  accept="video/*"
                  onChange={(e) => handleOwnerFile(e, "trailer")}
                  className="absolute inset-0 cursor-pointer opacity-0"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Submit */}
      <button
        type="submit"
        disabled={
          uploadLoading ||
          uploadingFile ||
          uploadingPoster ||
          !formData.fileUrl ||
          !formData.genreId ||
          !formData.title
        }
        className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl py-4 text-sm font-black tracking-wide transition-colors flex items-center justify-center gap-2"
      >
        {uploadLoading ? (
          <>
            <div
              className="h-4 w-4 rounded-full border-2 border-white border-t-transparent"
              style={{ animation: "spin 1s linear infinite" }}
            />{" "}
            Publishing to the Multiverse...
          </>
        ) : (
          <>
            <Upload size={16} /> Publish Content Instantly
          </>
        )}
      </button>
      {!formData.fileUrl && (
        <p className="text-center text-xs text-gray-600">
          Upload your main content file to enable publishing
        </p>
      )}
    </form>
  );
}
