import { Clock, Users, Settings, Star } from "lucide-react";

export function StatsRow({ contentRequests, contributorRequests, genres }) {
  const pendingContribs = contributorRequests.filter(
    (u) => u.status === "pending",
  ).length;

  const approvedContribs = contributorRequests.filter(
    (u) => u.status === "approved",
  ).length;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-10">
      <div className="rounded-2xl bg-[#141420] border border-white/5 p-5">
        <div className="flex items-center gap-2 mb-1">
          <Clock size={14} className="text-[#FBBF24]" />
          <span className="text-xs text-gray-400 uppercase tracking-wider">
            Pending
          </span>
        </div>
        <p className="text-3xl font-black text-[#FBBF24]">
          {contentRequests.length}
        </p>
      </div>
      <div className="rounded-2xl bg-[#141420] border border-white/5 p-5">
        <div className="flex items-center gap-2 mb-1">
          <Users size={14} className="text-[#A78BFA]" />
          <span className="text-xs text-gray-400 uppercase tracking-wider">
            Contributors
          </span>
        </div>
        <p className="text-3xl font-black text-[#A78BFA]">{approvedContribs}</p>
      </div>
      <div className="rounded-2xl bg-[#141420] border border-white/5 p-5">
        <div className="flex items-center gap-2 mb-1">
          <Settings size={14} className="text-green-400" />
          <span className="text-xs text-gray-400 uppercase tracking-wider">
            Genres
          </span>
        </div>
        <p className="text-3xl font-black text-green-400">{genres.length}</p>
      </div>
      <div className="rounded-2xl bg-[#141420] border border-white/5 p-5">
        <div className="flex items-center gap-2 mb-1">
          <Star size={14} className="text-pink-400" />
          <span className="text-xs text-gray-400 uppercase tracking-wider">
            Awaiting
          </span>
        </div>
        <p className="text-3xl font-black text-pink-400">{pendingContribs}</p>
      </div>
    </div>
  );
}
