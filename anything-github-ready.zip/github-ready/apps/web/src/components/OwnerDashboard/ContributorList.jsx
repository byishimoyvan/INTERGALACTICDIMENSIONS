import { useState } from "react";
import {
  Check,
  X,
  Users,
  Mail,
  Trash2,
  Settings,
  Save,
  Tag,
  Film,
  BookOpen,
} from "lucide-react";

export function ContributorList({
  loading,
  contributorRequests,
  actionLoading,
  handleUserAction,
  onEmail,
  onRemove,
  onSavePermissions,
  genres,
}) {
  const [editingPerms, setEditingPerms] = useState(null); // { id, allowed_genres, allowed_tags }
  const [permSaving, setPermSaving] = useState(false);
  const [generatingImage, setGeneratingImage] = useState(null); // contributor id
  const [rejectionImages, setRejectionImages] = useState({}); // id -> imageUrl

  const handleReject = async (u) => {
    setGeneratingImage(u.id);
    try {
      // Generate rejection certificate image
      const params = new URLSearchParams({
        prompt: `elegant dark space themed rejection certificate scroll, cosmic purple and gold design, mystical intergalactic letter, "Application Not Approved" text, glowing stars background, cinematic, professional, digital art`,
        width: "512",
        height: "512",
      });
      const res = await fetch(
        `/integrations/stable-diffusion-v-3/?${params.toString()}`,
      );
      const data = await res.json();
      if (data?.data?.[0]) {
        setRejectionImages((prev) => ({ ...prev, [u.id]: data.data[0] }));
      }
    } catch (e) {
      console.error("Image generation failed", e);
    } finally {
      setGeneratingImage(null);
    }
    // Trigger the actual rejection
    handleUserAction(u.id, "rejected");
  };

  const handleSavePerms = async () => {
    if (!editingPerms || !onSavePermissions) return;
    setPermSaving(true);
    try {
      await onSavePermissions(
        editingPerms.id,
        editingPerms.allowed_genres,
        editingPerms.allowed_tags,
      );
      setEditingPerms(null);
    } finally {
      setPermSaving(false);
    }
  };

  const toggleGenre = (genreName) => {
    if (!editingPerms) return;
    const current = editingPerms.allowed_genres
      ? editingPerms.allowed_genres
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean)
      : [];
    const idx = current.indexOf(genreName);
    let next;
    if (idx === -1) next = [...current, genreName];
    else {
      next = [...current];
      next.splice(idx, 1);
    }
    setEditingPerms({ ...editingPerms, allowed_genres: next.join(", ") });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div
          className="h-8 w-8 rounded-full border-2 border-[#7C3AED] border-t-transparent"
          style={{ animation: "spin 1s linear infinite" }}
        />
      </div>
    );
  }

  if (contributorRequests.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-32 rounded-2xl border border-dashed border-white/10">
        <Users size={32} className="text-gray-600 mb-2" />
        <p className="text-gray-400 text-sm">No contributors yet.</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Permissions edit modal */}
      {editingPerms && (
        <div className="fixed inset-0 z-[400] flex items-center justify-center px-4 bg-black/85 backdrop-blur-sm">
          <div
            className="bg-[#141420] border border-[#7C3AED]/30 rounded-2xl p-6 max-w-lg w-full relative"
            style={{ maxHeight: "85vh", overflowY: "auto" }}
          >
            <button
              onClick={() => setEditingPerms(null)}
              className="absolute top-4 right-4 text-gray-500 hover:text-white"
            >
              <X size={20} />
            </button>
            <div className="flex items-center gap-3 mb-5">
              <div className="h-9 w-9 rounded-xl bg-[#7C3AED]/20 flex items-center justify-center">
                <Settings size={15} className="text-[#A78BFA]" />
              </div>
              <div>
                <h2 className="text-base font-black">Upload Permissions</h2>
                <p className="text-xs text-gray-500">
                  Control what {editingPerms.username} can upload
                </p>
              </div>
            </div>

            <div className="space-y-5">
              {/* Allowed genres */}
              {genres && genres.length > 0 && (
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Film size={11} /> Allowed Genres
                  </label>
                  <p className="text-[11px] text-gray-600">
                    If none selected, contributor can upload to ALL genres.
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {genres.map((g) => {
                      const allowed = editingPerms.allowed_genres
                        ? editingPerms.allowed_genres
                            .split(",")
                            .map((s) => s.trim())
                            .filter(Boolean)
                        : [];
                      const active = allowed.includes(g.name);
                      return (
                        <button
                          key={g.id}
                          type="button"
                          onClick={() => toggleGenre(g.name)}
                          className={`rounded-full px-3 py-1 text-xs font-semibold border transition-colors ${active ? "bg-[#7C3AED] border-[#7C3AED] text-white" : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"}`}
                        >
                          {g.name}
                        </button>
                      );
                    })}
                  </div>
                  {editingPerms.allowed_genres && (
                    <button
                      onClick={() =>
                        setEditingPerms({ ...editingPerms, allowed_genres: "" })
                      }
                      className="text-[10px] text-red-400 hover:text-red-300"
                    >
                      Clear genre restrictions (allow all)
                    </button>
                  )}
                </div>
              )}

              {/* Allowed tags / content types */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Tag size={11} /> Allowed Content Tags / Keywords
                </label>
                <p className="text-[11px] text-gray-600">
                  Comma-separated. Leave blank for no restrictions. e.g. anime,
                  action, comedy
                </p>
                <input
                  value={editingPerms.allowed_tags || ""}
                  onChange={(e) =>
                    setEditingPerms({
                      ...editingPerms,
                      allowed_tags: e.target.value,
                    })
                  }
                  placeholder="e.g. anime, action, documentary"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                />
              </div>

              {/* Content types */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                  <BookOpen size={11} /> Notes for Contributor
                </label>
                <p className="text-[11px] text-gray-600">
                  Restrictions are informational — enforced by content review.
                  Mismatched uploads can be rejected.
                </p>
              </div>

              <button
                onClick={handleSavePerms}
                disabled={permSaving}
                className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-50 text-white rounded-xl py-3 font-black text-sm transition-colors flex items-center justify-center gap-2"
              >
                {permSaving ? (
                  <>
                    <div
                      className="h-4 w-4 rounded-full border-2 border-white border-t-transparent"
                      style={{ animation: "spin 1s linear infinite" }}
                    />{" "}
                    Saving...
                  </>
                ) : (
                  <>
                    <Save size={14} /> Save Permissions
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {contributorRequests.map((u) => (
        <div
          key={u.id}
          className="rounded-2xl border border-white/5 bg-[#141420] overflow-hidden"
        >
          <div className="flex items-center gap-4 p-4">
            <div className="h-10 w-10 rounded-full bg-gradient-to-br from-[#7C3AED] to-[#4C1D95] flex items-center justify-center text-sm font-bold flex-shrink-0">
              {u.username?.[0]?.toUpperCase() || "U"}
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-sm font-bold text-white">{u.username}</h3>
              <div className="flex items-center gap-2 mt-0.5 flex-wrap">
                <span className="text-xs text-gray-500">{u.email}</span>
                {u.dob && (
                  <span className="text-[10px] text-gray-600">
                    • Born {new Date(u.dob).toLocaleDateString()}
                  </span>
                )}
                {u.allowed_genres && (
                  <span className="text-[10px] text-[#A78BFA] bg-[#7C3AED]/10 px-2 py-0.5 rounded-full">
                    Genres: {u.allowed_genres}
                  </span>
                )}
                {u.allowed_tags && (
                  <span className="text-[10px] text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full">
                    Tags: {u.allowed_tags}
                  </span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2 flex-shrink-0">
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  u.status === "approved"
                    ? "bg-green-500/10 text-green-400"
                    : u.status === "rejected"
                      ? "bg-red-500/10 text-red-400"
                      : "bg-[#FBBF24]/10 text-[#FBBF24]"
                }`}
              >
                {u.status?.toUpperCase()}
              </span>

              {/* Email */}
              {onEmail && u.email && (
                <button
                  onClick={() => onEmail(u)}
                  title="Send email"
                  className="h-9 w-9 flex items-center justify-center rounded-xl bg-[#7C3AED]/10 text-[#A78BFA] hover:bg-[#7C3AED]/20 transition-colors"
                >
                  <Mail size={15} />
                </button>
              )}

              {/* Permissions edit (only for approved contributors) */}
              {u.status === "approved" && onSavePermissions && (
                <button
                  onClick={() =>
                    setEditingPerms({
                      id: u.id,
                      username: u.username,
                      allowed_genres: u.allowed_genres || "",
                      allowed_tags: u.allowed_tags || "",
                    })
                  }
                  title="Edit permissions"
                  className="h-9 w-9 flex items-center justify-center rounded-xl bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors"
                >
                  <Settings size={15} />
                </button>
              )}

              {/* Approve / Reject for pending */}
              {u.status === "pending" && (
                <>
                  <button
                    onClick={() => handleUserAction(u.id, "approved")}
                    disabled={actionLoading === u.id + "approved"}
                    className="h-9 w-9 flex items-center justify-center rounded-xl bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors disabled:opacity-50"
                  >
                    <Check size={16} />
                  </button>
                  <button
                    onClick={() => handleReject(u)}
                    disabled={
                      actionLoading === u.id + "rejected" ||
                      generatingImage === u.id
                    }
                    className="h-9 w-9 flex items-center justify-center rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-50"
                  >
                    {generatingImage === u.id ? (
                      <div
                        className="h-4 w-4 rounded-full border-2 border-red-400 border-t-transparent"
                        style={{ animation: "spin 1s linear infinite" }}
                      />
                    ) : (
                      <X size={16} />
                    )}
                  </button>
                </>
              )}

              {/* Remove contributor */}
              {u.status === "approved" && onRemove && (
                <button
                  onClick={() => onRemove(u.id, u.username)}
                  title="Remove contributor"
                  className="h-9 w-9 flex items-center justify-center rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-colors"
                >
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </div>

          {/* Rejection certificate image */}
          {rejectionImages[u.id] && (
            <div className="border-t border-white/5 p-4 flex items-center gap-4 bg-red-500/5">
              <img
                src={rejectionImages[u.id]}
                alt="Rejection certificate"
                className="h-20 w-20 rounded-xl object-cover flex-shrink-0"
              />
              <div className="flex-1">
                <p className="text-xs font-bold text-red-400 mb-1">
                  Rejection Certificate Generated
                </p>
                <p className="text-[11px] text-gray-500 mb-2">
                  A rejection image has been created. You can email it to the
                  contributor.
                </p>
                <div className="flex gap-2">
                  {onEmail && u.email && (
                    <button
                      onClick={() => onEmail(u)}
                      className="text-[11px] bg-[#7C3AED]/20 text-[#A78BFA] rounded-lg px-3 py-1.5 font-bold hover:bg-[#7C3AED]/30 transition-colors"
                    >
                      Send Email
                    </button>
                  )}
                  <a
                    href={rejectionImages[u.id]}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[11px] bg-white/5 text-gray-400 rounded-lg px-3 py-1.5 font-bold hover:bg-white/10 transition-colors"
                  >
                    View Image
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
