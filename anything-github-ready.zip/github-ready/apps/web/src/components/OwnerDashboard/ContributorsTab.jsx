import { useState } from "react";
import { Users, Upload, X, Mail, Send, CheckCircle } from "lucide-react";
import { ContributorList } from "./ContributorList";
import { ContributorUploadForm } from "./ContributorUploadForm";

export function ContributorsTab({
  loading,
  contributorRequests,
  actionLoading,
  handleUserAction,
  contribForm,
  setContribForm,
  contribSuccess,
  setContribSuccess,
  contribError,
  contribUploadLoading,
  uploadingContribFile,
  uploadingContribPoster,
  contribFileProgress,
  contribPosterProgress,
  handleContribFile,
  handleContribSubmit,
  genres,
  emailCompose,
  setEmailCompose,
  emailSending,
  emailSuccess,
  sendEmail,
  openEmailCompose,
  onRemove,
  onSavePermissions,
}) {
  return (
    <div className="space-y-8">
      {/* Email Compose Modal */}
      {emailCompose && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center px-4 bg-black/80 backdrop-blur-sm">
          <div className="bg-[#141420] border border-white/10 rounded-2xl p-6 max-w-lg w-full relative">
            <button
              onClick={() => {
                setEmailCompose(null);
              }}
              className="absolute top-4 right-4 text-gray-500 hover:text-white"
            >
              <X size={20} />
            </button>

            {emailSuccess ? (
              <div className="text-center py-8">
                <CheckCircle
                  size={52}
                  className="text-green-400 mx-auto mb-4"
                />
                <h3 className="text-xl font-black text-white mb-2">
                  Email Sent!
                </h3>
                <p className="text-gray-400 text-sm">
                  Your message was delivered to {emailCompose.contributor.email}
                </p>
                <button
                  onClick={() => setEmailCompose(null)}
                  className="mt-6 bg-[#7C3AED] hover:bg-[#6D28D9] text-white rounded-xl px-6 py-2.5 text-sm font-bold transition-colors"
                >
                  Done
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-3 mb-5">
                  <div className="h-9 w-9 rounded-xl bg-[#7C3AED]/20 flex items-center justify-center">
                    <Mail size={17} className="text-[#A78BFA]" />
                  </div>
                  <div>
                    <h2 className="text-base font-black text-white">
                      Send Email
                    </h2>
                    <p className="text-xs text-gray-500">
                      To: {emailCompose.contributor.username} (
                      {emailCompose.contributor.email})
                    </p>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={emailCompose.subject}
                      onChange={(e) =>
                        setEmailCompose({
                          ...emailCompose,
                          subject: e.target.value,
                        })
                      }
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                      Message
                    </label>
                    <textarea
                      value={emailCompose.body}
                      onChange={(e) =>
                        setEmailCompose({
                          ...emailCompose,
                          body: e.target.value,
                        })
                      }
                      rows={8}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors resize-none font-mono leading-relaxed"
                    />
                    <p className="text-[10px] text-gray-600">
                      You can edit the message above before sending. Sent from
                      byishimoyvande@gmail.com
                    </p>
                  </div>

                  <button
                    onClick={sendEmail}
                    disabled={emailSending}
                    className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-50 text-white rounded-xl py-3 font-black text-sm transition-colors flex items-center justify-center gap-2"
                  >
                    {emailSending ? (
                      <>
                        <div
                          className="h-4 w-4 rounded-full border-2 border-white border-t-transparent"
                          style={{ animation: "spin 1s linear infinite" }}
                        />{" "}
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send size={15} /> Send Email
                      </>
                    )}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Contributor list */}
      <div>
        <h2 className="text-base font-bold mb-4 flex items-center gap-2">
          <Users size={18} className="text-[#A78BFA]" /> Contributor Accounts
        </h2>
        <ContributorList
          loading={loading}
          contributorRequests={contributorRequests}
          actionLoading={actionLoading}
          handleUserAction={handleUserAction}
          onEmail={openEmailCompose}
          onRemove={onRemove}
          onSavePermissions={onSavePermissions}
          genres={genres}
        />
      </div>

      {/* Contributor Upload Form */}
      <div className="rounded-2xl border border-[#7C3AED]/30 bg-[#141420]">
        <div className="p-6 border-b border-white/5 flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-[#7C3AED]/20 flex items-center justify-center">
            <Upload size={17} className="text-[#A78BFA]" />
          </div>
          <div>
            <h2 className="text-base font-bold">
              Upload on Behalf of Contributor
            </h2>
            <p className="text-xs text-gray-400 mt-0.5">
              Submit content that gets queued for review on the main platform.
            </p>
          </div>
        </div>
        <div className="p-6">
          <ContributorUploadForm
            contribForm={contribForm}
            setContribForm={setContribForm}
            contribSuccess={contribSuccess}
            setContribSuccess={setContribSuccess}
            contribError={contribError}
            contribUploadLoading={contribUploadLoading}
            uploadingContribFile={uploadingContribFile}
            uploadingContribPoster={uploadingContribPoster}
            contribFileProgress={contribFileProgress}
            contribPosterProgress={contribPosterProgress}
            handleContribFile={handleContribFile}
            handleContribSubmit={handleContribSubmit}
            genres={genres}
          />
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
