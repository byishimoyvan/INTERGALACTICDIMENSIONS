import { useState } from "react";
import {
  Check,
  X,
  Eye,
  EyeOff,
  Film,
  BookOpen,
  Globe,
  Clock,
  AlertCircle,
  Pencil,
  Trash2,
  Save,
} from "lucide-react";

function StatusBadge({ status }) {
  if (status === "approved")
    return (
      <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-green-500/10 text-green-400">
        <Globe size={9} /> LIVE
      </span>
    );
  if (status === "pending")
    return (
      <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#FBBF24]/10 text-[#FBBF24]">
        <Clock size={9} /> PENDING
      </span>
    );
  return (
    <span className="flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-500/10 text-red-400">
      <AlertCircle size={9} /> REJECTED
    </span>
  );
}

export function ContentApprovalTab({
  loading,
  contentRequests,
  actionLoading,
  handleContentAction,
  deleteContent,
  toggleVisibility,
  startEdit,
  cancelEdit,
  saveEdit,
  editingItem,
  setEditingItem,
  editSaving,
  genres,
}) {
  if (loading) {
    return (
      <div className="flex items-center justify-center h-48">
        <div
          className="h-8 w-8 rounded-full border-2 border-[#7C3AED] border-t-transparent"
          style={{ animation: "spin 1s linear infinite" }}
        />
      </div>
    );
  }

  if (contentRequests.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-48 rounded-2xl border border-dashed border-white/10">
        <Film size={40} className="text-gray-600 mb-3 opacity-50" />
        <p className="text-gray-400">No content uploaded yet.</p>
      </div>
    );
  }

  const pending = contentRequests.filter((c) => c.status === "pending");
  const approved = contentRequests.filter((c) => c.status === "approved");
  const rejected = contentRequests.filter((c) => c.status === "rejected");

  const renderItem = (item) => (
    <div
      key={item.id}
      className="flex items-center gap-4 rounded-2xl border border-white/5 bg-[#141420] p-4"
    >
      <div className="h-16 w-12 rounded-lg overflow-hidden bg-white/5 flex-shrink-0">
        {item.poster_url ? (
          <img
            src={item.poster_url}
            alt={item.title}
            className="h-full w-full object-cover"
          />
        ) : (
          <div className="h-full w-full flex items-center justify-center">
            {item.type === "storybook" ? (
              <BookOpen size={20} className="text-gray-600" />
            ) : (
              <Film size={20} className="text-gray-600" />
            )}
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="text-sm font-bold text-white truncate">
            {item.title}
          </h3>
          {item.is_private && (
            <span className="text-[9px] font-bold text-gray-500 bg-white/5 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
              <EyeOff size={8} /> Hidden
            </span>
          )}
        </div>
        <div className="flex items-center flex-wrap gap-2 mt-1">
          <span className="text-[10px] font-medium text-gray-500 uppercase bg-white/5 rounded-full px-2 py-0.5">
            {item.type === "storybook"
              ? "Story Book"
              : item.type === "series"
                ? "Series"
                : "Movie"}
          </span>
          {item.genre_name && (
            <span className="text-[10px] text-[#A78BFA] bg-[#7C3AED]/10 rounded-full px-2 py-0.5">
              {item.genre_name}
            </span>
          )}
          {item.owner_name && (
            <span className="text-[10px] text-gray-500">
              by {item.owner_name}
            </span>
          )}
          {item.is_free ? (
            <span className="text-[10px] text-green-400 font-bold bg-green-500/10 rounded-full px-2 py-0.5">
              FREE
            </span>
          ) : (
            <span className="text-[10px] text-[#FBBF24] font-bold bg-[#FBBF24]/10 rounded-full px-2 py-0.5">
              ${item.price}
            </span>
          )}
          <StatusBadge status={item.status} />
        </div>
        {item.description && (
          <p className="text-xs text-gray-500 mt-1 line-clamp-1">
            {item.description}
          </p>
        )}
      </div>
      <div className="flex items-center gap-1.5 flex-shrink-0 flex-wrap justify-end">
        {/* Visibility toggle */}
        {toggleVisibility && (
          <button
            onClick={() => toggleVisibility(item.id, item.is_private)}
            title={item.is_private ? "Make Public" : "Make Private"}
            className={`h-8 w-8 flex items-center justify-center rounded-xl transition-colors ${item.is_private ? "bg-gray-500/20 text-gray-400 hover:bg-gray-500/30" : "bg-blue-500/10 text-blue-400 hover:bg-blue-500/20"}`}
          >
            {item.is_private ? <Eye size={14} /> : <EyeOff size={14} />}
          </button>
        )}
        {/* Edit button */}
        {startEdit && (
          <button
            onClick={() => startEdit(item)}
            title="Edit"
            className="h-8 w-8 flex items-center justify-center rounded-xl bg-[#7C3AED]/10 text-[#A78BFA] hover:bg-[#7C3AED]/20 transition-colors"
          >
            <Pencil size={13} />
          </button>
        )}
        {/* View file */}
        {item.file_url && (
          <a
            href={item.file_url}
            target="_blank"
            rel="noopener noreferrer"
            className="h-8 w-8 flex items-center justify-center rounded-xl bg-white/5 text-gray-400 hover:text-white transition-colors"
          >
            <Eye size={14} />
          </a>
        )}
        {/* Approve/Reject for pending */}
        {item.status === "pending" && (
          <>
            <button
              onClick={() => handleContentAction(item.id, "approved")}
              disabled={actionLoading === item.id + "approved"}
              className="h-8 w-8 flex items-center justify-center rounded-xl bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors disabled:opacity-50"
            >
              <Check size={14} />
            </button>
            <button
              onClick={() => handleContentAction(item.id, "rejected")}
              disabled={actionLoading === item.id + "rejected"}
              className="h-8 w-8 flex items-center justify-center rounded-xl bg-red-500/10 text-red-400 hover:bg-red-500/20 transition-colors disabled:opacity-50"
            >
              <X size={14} />
            </button>
          </>
        )}
        {/* Delete */}
        {deleteContent && (
          <button
            onClick={() => deleteContent(item.id)}
            title="Delete"
            className="h-8 w-8 flex items-center justify-center rounded-xl bg-red-500/10 text-red-500 hover:bg-red-500/20 transition-colors"
          >
            <Trash2 size={13} />
          </button>
        )}
      </div>
    </div>
  );

  return (
    <div className="space-y-8">
      {/* ── EDIT MODAL ── */}
      {editingItem && (
        <div className="fixed inset-0 z-[300] flex items-center justify-center px-4 bg-black/80 backdrop-blur-sm">
          <div
            className="bg-[#141420] border border-white/10 rounded-2xl p-6 max-w-lg w-full relative"
            style={{ maxHeight: "90vh", overflowY: "auto" }}
          >
            <button
              onClick={cancelEdit}
              className="absolute top-4 right-4 text-gray-500 hover:text-white"
            >
              <X size={20} />
            </button>
            <div className="flex items-center gap-3 mb-5">
              <div className="h-9 w-9 rounded-xl bg-[#7C3AED]/20 flex items-center justify-center">
                <Pencil size={15} className="text-[#A78BFA]" />
              </div>
              <div>
                <h2 className="text-base font-black">Edit Content</h2>
                <p className="text-xs text-gray-500">ID #{editingItem.id}</p>
              </div>
            </div>
            <div className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Title
                </label>
                <input
                  value={editingItem.title}
                  onChange={(e) =>
                    setEditingItem({ ...editingItem, title: e.target.value })
                  }
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors"
                />
              </div>

              {/* Genre */}
              {genres && genres.length > 0 && (
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                    Genre
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {genres.map((g) => (
                      <button
                        key={g.id}
                        type="button"
                        onClick={() =>
                          setEditingItem({ ...editingItem, genre_id: g.id })
                        }
                        className={`rounded-full px-3 py-1 text-xs font-semibold border transition-colors ${
                          editingItem.genre_id === g.id
                            ? "bg-[#7C3AED] border-[#7C3AED] text-white"
                            : "bg-white/5 border-white/10 text-gray-400 hover:border-[#7C3AED]"
                        }`}
                      >
                        {g.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Description
                </label>
                <textarea
                  value={editingItem.description}
                  onChange={(e) =>
                    setEditingItem({
                      ...editingItem,
                      description: e.target.value,
                    })
                  }
                  rows={3}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white outline-none focus:border-[#7C3AED] transition-colors resize-none"
                />
              </div>

              {/* Tags */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Tags (comma-separated)
                </label>
                <input
                  value={editingItem.tags || ""}
                  onChange={(e) =>
                    setEditingItem({ ...editingItem, tags: e.target.value })
                  }
                  placeholder="e.g. action, sci-fi, adventure"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Content URL (video / PDF / stream link)
                </label>
                <input
                  value={editingItem.file_url}
                  onChange={(e) =>
                    setEditingItem({ ...editingItem, file_url: e.target.value })
                  }
                  placeholder="https://..."
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                />
              </div>
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider">
                  Poster / Cover URL
                </label>
                <div className="flex gap-3">
                  <input
                    value={editingItem.poster_url}
                    onChange={(e) =>
                      setEditingItem({
                        ...editingItem,
                        poster_url: e.target.value,
                      })
                    }
                    placeholder="https://..."
                    className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-gray-600 outline-none focus:border-[#7C3AED] transition-colors"
                  />
                  {editingItem.poster_url && (
                    <img
                      src={editingItem.poster_url}
                      alt="preview"
                      className="h-12 w-8 rounded-lg object-cover object-top flex-shrink-0"
                    />
                  )}
                </div>
              </div>
              <button
                onClick={saveEdit}
                disabled={editSaving}
                className="w-full bg-[#7C3AED] hover:bg-[#6D28D9] disabled:opacity-50 text-white rounded-xl py-3 font-black text-sm transition-colors flex items-center justify-center gap-2"
              >
                {editSaving ? (
                  <>
                    <div
                      className="h-4 w-4 rounded-full border-2 border-white border-t-transparent"
                      style={{ animation: "spin 1s linear infinite" }}
                    />{" "}
                    Saving...
                  </>
                ) : (
                  <>
                    <Save size={14} /> Save Changes
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {pending.length > 0 && (
        <div>
          <h3 className="text-xs font-bold text-[#FBBF24] uppercase tracking-widest mb-3 flex items-center gap-2">
            <Clock size={11} /> Pending Review ({pending.length})
          </h3>
          <div className="space-y-3">{pending.map(renderItem)}</div>
        </div>
      )}
      {approved.length > 0 && (
        <div>
          <h3 className="text-xs font-bold text-green-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <Globe size={11} /> Live on Platform ({approved.length})
          </h3>
          <div className="space-y-3">{approved.map(renderItem)}</div>
        </div>
      )}
      {rejected.length > 0 && (
        <div>
          <h3 className="text-xs font-bold text-red-400 uppercase tracking-widest mb-3 flex items-center gap-2">
            <AlertCircle size={11} /> Rejected ({rejected.length})
          </h3>
          <div className="space-y-3">{rejected.map(renderItem)}</div>
        </div>
      )}
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
