import { useState, useCallback } from "react";

/**
 * Upload hook with progress percentage support using XMLHttpRequest.
 * Returns [upload, { loading, progress }]
 * progress is 0-100 (null when not uploading)
 */
function useUploadWithProgress() {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(null);

  const upload = useCallback(async (input) => {
    return new Promise((resolve) => {
      setLoading(true);
      setProgress(0);

      const xhr = new XMLHttpRequest();

      xhr.upload.addEventListener("progress", (event) => {
        if (event.lengthComputable) {
          const pct = Math.round((event.loaded / event.total) * 100);
          setProgress(pct);
        }
      });

      xhr.addEventListener("load", () => {
        setLoading(false);
        setProgress(null);
        if (xhr.status === 413) {
          resolve({ error: "File too large (max 4.5 MB)." });
          return;
        }
        if (xhr.status < 200 || xhr.status >= 300) {
          resolve({ error: `Upload failed (${xhr.status})` });
          return;
        }
        try {
          const data = JSON.parse(xhr.responseText);
          resolve({ url: data.url, mimeType: data.mimeType || null });
        } catch {
          resolve({ error: "Upload failed: bad response." });
        }
      });

      xhr.addEventListener("error", () => {
        setLoading(false);
        setProgress(null);
        resolve({ error: "Network error during upload." });
      });

      xhr.addEventListener("abort", () => {
        setLoading(false);
        setProgress(null);
        resolve({ error: "Upload cancelled." });
      });

      xhr.open("POST", "/_create/api/upload/");

      if ("file" in input && input.file) {
        const formData = new FormData();
        formData.append("file", input.file);
        xhr.send(formData);
      } else if ("url" in input) {
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(JSON.stringify({ url: input.url }));
      } else if ("base64" in input) {
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.send(JSON.stringify({ base64: input.base64 }));
      } else if ("buffer" in input) {
        xhr.setRequestHeader("Content-Type", "application/octet-stream");
        xhr.send(input.buffer);
      } else {
        setLoading(false);
        setProgress(null);
        resolve({ error: "No valid input provided." });
      }
    });
  }, []);

  return [upload, { loading, progress }];
}

export default useUploadWithProgress;
export { useUploadWithProgress };
