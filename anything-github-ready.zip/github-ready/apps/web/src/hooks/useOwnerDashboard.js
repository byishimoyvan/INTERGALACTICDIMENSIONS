import { useState, useEffect } from "react";

const emptyForm = {
  title: "",
  description: "",
  type: "movie",
  genreId: "",
  fileUrl: "",
  posterUrl: "",
  trailerUrl: "",
  price: 0,
  isFree: true,
  isPrivate: false,
  cast: "",
  director: "",
  releaseYear: new Date().getFullYear(),
  duration: "",
  language: "English",
  tags: "",
  ageRating: "PG",
};

export function useOwnerDashboard(user) {
  const [profile, setProfile] = useState(null);
  const [contentRequests, setContentRequests] = useState([]);
  const [contributorRequests, setContributorRequests] = useState([]);
  const [genres, setGenres] = useState([]);
  const [newGenre, setNewGenre] = useState("");
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("content");
  const [actionLoading, setActionLoading] = useState(null);

  // Upload form state
  const [formData, setFormData] = useState({ ...emptyForm });
  const [uploadLoading, setUploadLoading] = useState(false);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [uploadError, setUploadError] = useState(null);

  // Contributor uploader state
  const [contribForm, setContribForm] = useState({
    title: "",
    description: "",
    type: "movie",
    genreId: "",
    fileUrl: "",
    posterUrl: "",
    price: 0,
    isFree: true,
  });
  const [contribUploadLoading, setContribUploadLoading] = useState(false);
  const [contribSuccess, setContribSuccess] = useState(false);
  const [contribError, setContribError] = useState(null);

  const [emailCompose, setEmailCompose] = useState(null); // { contributor: {id, username, email}, subject, body }
  const [emailSending, setEmailSending] = useState(false);
  const [emailSuccess, setEmailSuccess] = useState(false);

  const [editingItem, setEditingItem] = useState(null); // { id, title, description, file_url, poster_url }
  const [editSaving, setEditSaving] = useState(false);

  const [settings, setSettings] = useState({});
  const [settingsLoading, setSettingsLoading] = useState(true);
  const [savingKeys, setSavingKeys] = useState({});

  useEffect(() => {
    if (user) {
      fetchProfile();
      fetchRequests();
      fetchGenres();
      fetchSettings();
    }
  }, [user]);

  useEffect(() => {
    if (genres.length > 0) {
      setFormData((prev) => ({
        ...prev,
        genreId: prev.genreId || genres[0].id,
      }));
      setContribForm((prev) => ({
        ...prev,
        genreId: prev.genreId || genres[0].id,
      }));
    }
  }, [genres]);

  const fetchProfile = async () => {
    try {
      const res = await fetch("/api/profile");
      const data = await res.json();
      if (data.user?.role !== "owner") window.location.href = "/";
      setProfile(data.user);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const [pendingRes, approvedRes, usersRes] = await Promise.all([
        fetch("/api/content?status=pending"),
        fetch("/api/content?status=approved"),
        fetch("/api/users"),
      ]);
      const pendingData = await pendingRes.json();
      const approvedData = await approvedRes.json();
      const usersData = await usersRes.json();
      // Merge all content — pending first
      const allContent = [
        ...(pendingData.content || []),
        ...(approvedData.content || []),
      ];
      setContentRequests(allContent);
      setContributorRequests(
        (usersData.users || []).filter(
          (u) => u.role === "contributor" || u.status === "pending",
        ),
      );
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const fetchGenres = async () => {
    try {
      const res = await fetch("/api/genres");
      const data = await res.json();
      setGenres(data.genres || []);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchSettings = async () => {
    setSettingsLoading(true);
    try {
      const res = await fetch("/api/settings");
      if (!res.ok) throw new Error("Failed to fetch settings");
      const data = await res.json();
      setSettings(data.settings || {});
    } catch (err) {
      console.error(err);
    } finally {
      setSettingsLoading(false);
    }
  };

  const saveSetting = async (key, value) => {
    setSavingKeys((prev) => ({ ...prev, [key]: true }));
    try {
      setSettings((prev) => ({ ...prev, [key]: value }));
      await fetch("/api/settings", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [key]: value }),
      });
    } catch (err) {
      console.error("saveSetting error", err);
    } finally {
      setSavingKeys((prev) => ({ ...prev, [key]: false }));
    }
  };

  const handleContentAction = async (id, action) => {
    setActionLoading(id + action);
    try {
      await fetch("/api/content", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: action }),
      });
      // Update status in-place so it moves to the correct section
      setContentRequests((prev) =>
        prev.map((c) => (c.id === id ? { ...c, status: action } : c)),
      );
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleUserAction = async (id, action) => {
    setActionLoading(id + action);
    try {
      await fetch("/api/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status: action }),
      });
      await fetchRequests();
    } catch (err) {
      console.error(err);
    } finally {
      setActionLoading(null);
    }
  };

  const handleAddGenre = async () => {
    if (!newGenre.trim()) return;
    try {
      await fetch("/api/genres", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newGenre.trim() }),
      });
      setNewGenre("");
      fetchGenres();
    } catch (err) {
      console.error(err);
    }
  };

  const handleOwnerSubmit = async (e) => {
    e.preventDefault();
    setUploadLoading(true);
    setUploadError(null);
    try {
      const res = await fetch("/api/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "Upload failed");
      }
      setUploadSuccess(true);
      setFormData({ ...emptyForm, genreId: genres[0]?.id || "" });
    } catch (err) {
      console.error(err);
      setUploadError(err.message);
    } finally {
      setUploadLoading(false);
    }
  };

  const handleContribSubmit = async (e) => {
    e.preventDefault();
    setContribUploadLoading(true);
    setContribError(null);
    try {
      const res = await fetch("/api/content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...contribForm, isPrivate: false }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "Upload failed");
      }
      setContribSuccess(true);
      setContribForm({
        title: "",
        description: "",
        type: "movie",
        genreId: genres[0]?.id || "",
        fileUrl: "",
        posterUrl: "",
        price: 0,
        isFree: true,
      });
    } catch (err) {
      console.error(err);
      setContribError(err.message);
    } finally {
      setContribUploadLoading(false);
    }
  };

  const openEmailCompose = (contributor) => {
    setEmailCompose({
      contributor,
      subject: `Update from Intergalactic Dimensions`,
      body: `Hi ${contributor.username},\n\nThank you for being part of the Intergalactic Dimensions community.\n\n[Add your message here]\n\nBest regards,\nIntergalactic Dimensions Team`,
    });
    setEmailSuccess(false);
  };

  const sendEmail = async () => {
    if (!emailCompose) return;
    setEmailSending(true);
    try {
      const res = await fetch("/api/users/send-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          to: emailCompose.contributor.email,
          subject: emailCompose.subject,
          body: emailCompose.body,
        }),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || "Failed to send");
      }
      setEmailSuccess(true);
    } catch (err) {
      console.error(err);
      alert("Email failed: " + err.message);
    } finally {
      setEmailSending(false);
    }
  };

  const deleteContent = async (id) => {
    if (!window.confirm("Delete this content? This cannot be undone.")) return;
    try {
      const res = await fetch(`/api/content/${id}`, { method: "DELETE" });
      if (!res.ok) throw new Error("Delete failed");
      setContentRequests((prev) => prev.filter((c) => c.id !== id));
    } catch (err) {
      console.error(err);
      alert("Failed to delete: " + err.message);
    }
  };

  const toggleVisibility = async (id, currentlyPrivate) => {
    try {
      await fetch(`/api/content/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ is_private: !currentlyPrivate }),
      });
      setContentRequests((prev) =>
        prev.map((c) =>
          c.id === id ? { ...c, is_private: !currentlyPrivate } : c,
        ),
      );
    } catch (err) {
      console.error(err);
    }
  };

  const startEdit = (item) => {
    setEditingItem({
      id: item.id,
      title: item.title,
      description: item.description || "",
      file_url: item.file_url || "",
      poster_url: item.poster_url || "",
      genre_id: item.genre_id || (genres[0]?.id ?? null),
      tags: item.tags || "",
    });
  };

  const cancelEdit = () => setEditingItem(null);

  const saveEdit = async () => {
    if (!editingItem) return;
    setEditSaving(true);
    try {
      const res = await fetch(`/api/content/${editingItem.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: editingItem.title,
          description: editingItem.description,
          file_url: editingItem.file_url,
          poster_url: editingItem.poster_url,
          genre_id: editingItem.genre_id,
          tags: editingItem.tags,
        }),
      });
      if (!res.ok) throw new Error("Save failed");
      // Find genre name to update display
      const genreName = genres.find((g) => g.id === editingItem.genre_id)?.name;
      setContentRequests((prev) =>
        prev.map((c) =>
          c.id === editingItem.id
            ? { ...c, ...editingItem, genre_name: genreName || c.genre_name }
            : c,
        ),
      );
      setEditingItem(null);
    } catch (err) {
      alert("Failed to save: " + err.message);
    } finally {
      setEditSaving(false);
    }
  };

  const removeContributor = async (id, username) => {
    if (
      !window.confirm(
        `Remove ${username} as contributor? They will become a regular user.`,
      )
    )
      return;
    try {
      const res = await fetch("/api/users", {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (!res.ok) throw new Error("Remove failed");
      setContributorRequests((prev) => prev.filter((u) => u.id !== id));
    } catch (err) {
      console.error(err);
      alert("Failed to remove contributor: " + err.message);
    }
  };

  const updateContributorPermissions = async (
    id,
    allowedGenres,
    allowedTags,
  ) => {
    try {
      const res = await fetch("/api/users", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          id,
          allowed_genres: allowedGenres,
          allowed_tags: allowedTags,
        }),
      });
      if (!res.ok) throw new Error("Update failed");
      setContributorRequests((prev) =>
        prev.map((u) =>
          u.id === id
            ? { ...u, allowed_genres: allowedGenres, allowed_tags: allowedTags }
            : u,
        ),
      );
    } catch (err) {
      console.error(err);
      alert("Failed to update permissions: " + err.message);
    }
  };

  const handleDeleteGenre = async (id, name) => {
    if (!window.confirm(`Delete genre "${name}"? This cannot be undone.`))
      return;
    try {
      const res = await fetch(`/api/genres/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Delete failed");
      setGenres((prev) => prev.filter((g) => g.id !== id));
    } catch (err) {
      console.error(err);
      alert(err.message);
    }
  };

  const handleBulkContentAction = async (action) => {
    if (action === "delete_rejected") {
      if (
        !window.confirm(
          "Permanently delete ALL rejected content? This cannot be undone.",
        )
      )
        return;
      try {
        const rejected = contentRequests.filter((c) => c.status === "rejected");
        await Promise.all(
          rejected.map((c) =>
            fetch(`/api/content/${c.id}`, { method: "DELETE" }),
          ),
        );
        setContentRequests((prev) =>
          prev.filter((c) => c.status !== "rejected"),
        );
      } catch (err) {
        console.error(err);
        alert("Bulk delete failed: " + err.message);
      }
    } else if (action === "approve_all_pending") {
      if (!window.confirm("Approve ALL pending content and make it live?"))
        return;
      try {
        const pending = contentRequests.filter((c) => c.status === "pending");
        await Promise.all(
          pending.map((c) =>
            fetch("/api/content", {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id: c.id, status: "approved" }),
            }),
          ),
        );
        setContentRequests((prev) =>
          prev.map((c) =>
            c.status === "pending" ? { ...c, status: "approved" } : c,
          ),
        );
      } catch (err) {
        console.error(err);
        alert("Bulk approve failed: " + err.message);
      }
    } else if (action === "approve_all_contributors") {
      if (!window.confirm("Approve ALL pending contributor requests?")) return;
      try {
        const pending = contributorRequests.filter(
          (u) => u.status === "pending",
        );
        await Promise.all(
          pending.map((u) =>
            fetch("/api/users", {
              method: "PATCH",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ id: u.id, status: "approved" }),
            }),
          ),
        );
        await fetchRequests();
      } catch (err) {
        console.error(err);
        alert("Bulk approve failed: " + err.message);
      }
    }
  };

  return {
    profile,
    contentRequests,
    contributorRequests,
    genres,
    newGenre,
    setNewGenre,
    loading,
    activeTab,
    setActiveTab,
    actionLoading,
    formData,
    setFormData,
    uploadLoading,
    uploadSuccess,
    setUploadSuccess,
    uploadError,
    setUploadError,
    contribForm,
    setContribForm,
    contribUploadLoading,
    contribSuccess,
    setContribSuccess,
    contribError,
    setContribError,
    handleContentAction,
    handleUserAction,
    handleAddGenre,
    handleOwnerSubmit,
    handleContribSubmit,
    emailCompose,
    setEmailCompose,
    emailSending,
    emailSuccess,
    setEmailSuccess,
    openEmailCompose,
    sendEmail,
    editingItem,
    setEditingItem,
    editSaving,
    deleteContent,
    toggleVisibility,
    startEdit,
    cancelEdit,
    saveEdit,
    removeContributor,
    updateContributorPermissions,
    settings,
    settingsLoading,
    savingKeys,
    saveSetting,
    handleDeleteGenre,
    handleBulkContentAction,
  };
}
