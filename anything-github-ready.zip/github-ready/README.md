# Anything — Video Streaming Platform

A full-stack video streaming platform with a **React web app** and **React Native mobile app** (Expo). Supports content upload, subscriptions, mobile money payments, and contributor workflows.

## Project Structure

```
apps/
  web/      # React Router v7 web app (Vite + Tailwind + shadcn/ui)
  mobile/   # Expo React Native app (iOS & Android)
```

## Features

- 🎬 Video content browsing by genre
- 🔐 Auth (sign up, sign in, forgot/reset password)
- 💳 Subscriptions + mobile money payments
- 📤 Content upload by contributors
- 🛡️ Owner dashboard (approvals, payments, settings, stats)
- 📱 Mobile app with in-app purchases (IAP)

## Getting Started

### Web App

```bash
cd apps/web
cp .env.example .env   # fill in your values
npm install
npm run dev
```

### Mobile App

```bash
cd apps/mobile
cp .env.example .env   # fill in your values
npm install
npx expo start
```

## Environment Variables

See `.env.example` in each app directory for required variables. **Never commit `.env` files.**

## Tech Stack

| Layer | Web | Mobile |
|-------|-----|--------|
| Framework | React Router v7 | Expo (React Native) |
| Styling | Tailwind CSS + shadcn/ui | Tailwind |
| Auth | Custom JWT | Expo + WebView |
| Payments | Stripe + Mobile Money | IAP |
| Upload | Uploadcare | Uploadcare |
